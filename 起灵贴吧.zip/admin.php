<?php
/**
 * 管理后台入口
 */
define('IN_APP', true);
require __DIR__ . '/includes/functions.php';

if (!is_installed()) { header('Location: install.php'); exit; }
start_session();

$user = current_user();

/* ===== 未登录 / 非管理员（含站长）：显示独立的后台登录页 ===== */
if (!$user || !in_array($user['role'], ['admin','super_admin'])) {
    $loginError = '';
    // 当前已登录但非管理员时，在登录页给出提示
    $currentLoginName = $user ? ($user['nickname'] ?: $user['username']) : '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($username === '' || $password === '') {
            $loginError = '请输入管理员账号和密码';
        } else {
            $stmt = db()->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $adminUser = $stmt->fetch();

            if (!$adminUser) {
                $loginError = '管理员账号不存在，请确认后重试';
            } elseif ((int)$adminUser['status'] !== 1) {
                $loginError = '该管理员账号已被禁用，请联系其他管理员';
            } elseif (!in_array($adminUser['role'], ['admin','super_admin'])) {
                $loginError = '该账号不是管理员，无法登录后台';
            } elseif (!verify_password($password, $adminUser['password'])) {
                $loginError = '管理员密码错误，请重新输入';
            } else {
                // 切换为管理员会话，并重新生成会话ID防止会话固定攻击
                session_regenerate_id(true);
                $_SESSION['uid'] = $adminUser['id'];
                db()->exec("UPDATE users SET last_login = NOW() WHERE id = {$adminUser['id']}");
                header('Location: admin.php');
                exit;
            }
        }
    }

    $settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch() ?: ['site_name' => '起灵贴吧'];
    include __DIR__ . '/admin/login.php';
    exit;
}

$page = $_GET['page'] ?? 'dashboard';
$allowed = ['dashboard','users','posts','tiebas','comments','categories','settings'];
if (!in_array($page, $allowed)) $page = 'dashboard';

$settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch() ?: ['site_name' => '起灵贴吧'];

include __DIR__ . '/admin/' . $page . '.php';
