<?php
/**
 * 管理后台入口
 */
define('IN_APP', true);
require __DIR__ . '/includes/functions.php';

if (!is_installed()) { header('Location: install.php'); exit; }
start_session();

$user = current_user();
if (!$user || $user['role'] !== 'admin') {
    header('Location: index.php?page=login');
    exit;
}

$page = $_GET['page'] ?? 'dashboard';
$allowed = ['dashboard','users','posts','tiebas','comments','categories','settings'];
if (!in_array($page, $allowed)) $page = 'dashboard';

$settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch() ?: ['site_name' => '起灵贴吧'];

include __DIR__ . '/admin/' . $page . '.php';
