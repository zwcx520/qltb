        </div>
    </main>
</div>
<script src="assets/js/app.js"></script>
<script>
/* ===== 手机端侧边抽屉导航 ===== */
(function(){
    var btn  = document.getElementById('adminDrawerBtn');
    var sb   = document.getElementById('adminSidebar');
    var mask = document.getElementById('adminDrawerMask');
    if (!btn || !sb || !mask) return;

    function openDrawer(){ document.body.classList.add('drawer-open'); }
    function closeDrawer(){ document.body.classList.remove('drawer-open'); }

    btn.addEventListener('click', openDrawer);
    mask.addEventListener('click', closeDrawer);
    // 点击抽屉内任意链接后自动收起
    sb.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', closeDrawer); });
})();
</script>
</body>
</html>
