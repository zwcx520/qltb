<?php
/**
 * 后台公共头部
 */
$adminPage = $adminPage ?? 'dashboard';
$menus = [
    'dashboard'  => ['控制台', 'tachometer'],
    'users'      => ['用户管理', 'users'],
    'posts'      => ['帖子管理', 'file-text'],
    'tiebas'     => ['贴吧管理', 'tree'],
    'comments'   => ['评论管理', 'comments'],
    'categories' => ['分类管理', 'tags'],
    'settings'   => ['系统设置', 'cog'],
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - <?= e($settings['site_name']) ?></title>
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/v4-shims.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin.css?v=<?= @filemtime(__DIR__ . '/../assets/css/admin.css') ?: '1' ?>">
</head>
<body>
<div class="admin-layout">
    <!-- 侧边栏（手机端变为左侧滑出抽屉） -->
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-logo">
            <i class="fa fa-tree"></i>
            <span>起灵管理</span>
        </div>
        <nav class="admin-menu">
            <?php foreach ($menus as $k => $v): ?>
                <a href="admin.php?page=<?= $k ?>" class="menu-item <?= $adminPage===$k?'active':'' ?>">
                    <i class="fa fa-<?= $v[1] ?>"></i>
                    <span><?= $v[0] ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="admin-sidebar-footer">
            <a href="index.php" class="menu-item"><i class="fa fa-home"></i><span>返回前台</span></a>
        </div>
    </aside>

    <!-- 手机端抽屉遮罩 -->
    <div class="admin-drawer-mask" id="adminDrawerMask"></div>

    <!-- 主内容区 -->
    <main class="admin-main">
        <header class="admin-topbar">
            <div class="admin-topbar-left">
                <button type="button" class="admin-drawer-btn" id="adminDrawerBtn" aria-label="打开导航菜单">
                    <i class="fa fa-bars"></i>
                </button>
                <div class="admin-topbar-title"><?= $menus[$adminPage][0] ?></div>
            </div>
            <div class="admin-topbar-right">
                <span class="admin-user">
                    <img src="<?= e(avatar($user)) ?>" class="avatar-sm">
                    <span class="admin-user-name"><?= e($user['nickname'] ?: $user['username']) ?></span>
                </span>
                <a href="api/logout.php?redirect=admin.php" class="admin-logout" title="退出登录"><i class="fa fa-sign-out"></i></a>
            </div>
        </header>
        <div class="admin-content">
