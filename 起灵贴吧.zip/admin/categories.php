<?php
/**
 * 分类管理
 */
$adminPage = 'categories';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $act === 'save') {
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $icon = trim($_POST['icon'] ?? 'star');
    $sort = intval($_POST['sort'] ?? 0);

    if ($id) {
        db()->prepare("UPDATE categories SET name=?, icon=?, sort=? WHERE id=?")->execute([$name, $icon, $sort, $id]);
    } else {
        db()->prepare("INSERT INTO categories (name, icon, sort) VALUES (?, ?, ?)")->execute([$name, $icon, $sort]);
    }
    header('Location: admin.php?page=categories');
    exit;
}

if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    db()->exec("DELETE FROM categories WHERE id = {$id}");
    header('Location: admin.php?page=categories');
    exit;
}

$edit = null;
if ($act === 'edit') {
    $id = intval($_GET['id'] ?? 0);
    $edit = db()->query("SELECT * FROM categories WHERE id = {$id}")->fetch();
}

$categories = db()->query("SELECT * FROM categories ORDER BY sort ASC, id DESC")->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <h3 style="font-size:16px;font-weight:600;flex:1;"><i class="fa fa-tags text-primary"></i> 分类管理</h3>
        <button class="btn btn-primary" onclick="document.getElementById('cat-form').style.display='block'">
            <i class="fa fa-plus"></i> 新建分类
        </button>
    </div>

    <div id="cat-form" style="display:<?= $edit ? 'block' : 'none' ?>;background:var(--bg);padding:20px;border-radius:12px;margin-bottom:20px;">
        <h4 style="margin-bottom:16px;font-weight:600;"><?= $edit ? '编辑分类' : '新建分类' ?></h4>
        <form method="post" action="admin.php?page=categories&act=save">
            <input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;">
                <div class="form-group">
                    <label class="form-label">分类名称 *</label>
                    <input name="name" class="form-input" required value="<?= e($edit['name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">选择图标</label>
                    <?= icon_select('icon', $edit['icon'] ?? 'star') ?>
                </div>
                <div class="form-group">
                    <label class="form-label">排序</label>
                    <input name="sort" type="number" class="form-input" value="<?= $edit['sort'] ?? 0 ?>">
                </div>
            </div>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-primary"><i class="fa fa-save"></i> 保存</button>
                <a href="admin.php?page=categories" class="btn btn-warning">取消</a>
            </div>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr><th>ID</th><th>图标</th><th>名称</th><th>排序</th><th>操作</th></tr>
        </thead>
        <tbody>
            <?php foreach ($categories as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td>
                    <span style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#ec4899,#a855f7);color:white;display:inline-flex;align-items:center;justify-content:center;">
                        <i class="fa fa-<?= e($c['icon']) ?>"></i>
                    </span>
                </td>
                <td><strong><?= e($c['name']) ?></strong></td>
                <td><?= $c['sort'] ?></td>
                <td>
                    <a href="admin.php?page=categories&act=edit&id=<?= $c['id'] ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>
                    <a href="admin.php?page=categories&act=delete&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除？')"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($categories)): ?>
        <div class="empty"><i class="fa fa-tags"></i><p>暂无分类</p></div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
