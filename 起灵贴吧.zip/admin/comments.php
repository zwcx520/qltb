<?php
/**
 * 评论管理
 */
$adminPage = 'comments';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';
if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    $c = db()->query("SELECT post_id FROM comments WHERE id = {$id}")->fetch();
    db()->exec("DELETE FROM comments WHERE id = {$id}");
    if ($c) db()->exec("UPDATE posts SET comments = comments - 1 WHERE id = {$c['post_id']}");
    header('Location: admin.php?page=comments');
    exit;
}

$kw = trim($_GET['kw'] ?? '');
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 20;
$offset = ($pageNum - 1) * $perPage;

$where = '1=1';
if ($kw) $where .= " AND c.content LIKE '%{$kw}%'";

$total = db()->query("SELECT COUNT(*) FROM comments c WHERE {$where}")->fetchColumn();
$stmt = db()->prepare("
    SELECT c.*, u.nickname, u.username, p.title as post_title, p.id as post_id
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    LEFT JOIN posts p ON c.post_id = p.id
    WHERE {$where}
    ORDER BY c.id DESC
    LIMIT {$offset}, {$perPage}
");
$stmt->execute();
$comments = $stmt->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <form method="get" style="display:flex;gap:8px;">
            <input type="hidden" name="page" value="comments">
            <input name="kw" class="form-input" placeholder="搜索评论内容" value="<?= e($kw) ?>">
            <button class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr><th>ID</th><th>用户</th><th>评论内容</th><th>所属帖子</th><th>点赞</th><th>时间</th><th>操作</th></tr>
        </thead>
        <tbody>
            <?php foreach ($comments as $c): ?>
            <tr>
                <td><?= $c['id'] ?></td>
                <td><?= e($c['nickname'] ?: $c['username']) ?></td>
                <td style="max-width:300px;"><?= e(mb_substr($c['content'], 0, 50)) ?><?= mb_strlen($c['content'])>50?'...':'' ?></td>
                <td>
                    <?php if ($c['post_id']): ?>
                        <a href="index.php?page=post&id=<?= $c['post_id'] ?>" target="_blank" style="color:var(--primary);">
                            <?= e(mb_substr($c['post_title'], 0, 15)) ?>
                        </a>
                    <?php else: ?>
                        <span class="text-light">帖子已删除</span>
                    <?php endif; ?>
                </td>
                <td><?= $c['likes'] ?></td>
                <td class="text-light"><?= $c['created_at'] ?></td>
                <td>
                    <a href="admin.php?page=comments&act=delete&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该评论？')">
                        <i class="fa fa-trash"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($comments)): ?>
        <div class="empty"><i class="fa fa-comments-o"></i><p>暂无评论</p></div>
    <?php endif; ?>

    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div class="pagination">
        <?php if ($pageNum > 1): ?>
            <a href="admin.php?page=comments&kw=<?= urlencode($kw) ?>&p=<?= $pageNum-1 ?>"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="active"><?= $pageNum ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="admin.php?page=comments&kw=<?= urlencode($kw) ?>&p=<?= $pageNum+1 ?>"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
