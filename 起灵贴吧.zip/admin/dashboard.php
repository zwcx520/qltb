<?php
/**
 * 控制台
 */
$adminPage = 'dashboard';
include __DIR__ . '/admin_header.php';

// 统计数据
$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM users) as users,
    (SELECT COUNT(*) FROM posts) as posts,
    (SELECT COUNT(*) FROM tiebas) as tiebas,
    (SELECT COUNT(*) FROM comments) as comments
")->fetch();

// 最近注册用户
$recentUsers = db()->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();

// 最近帖子
$recentPosts = db()->query("
    SELECT p.*, u.nickname, t.name as tieba_name
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    ORDER BY p.created_at DESC LIMIT 5
")->fetchAll();

// 热门贴吧
$hotTiebas = db()->query("SELECT * FROM tiebas ORDER BY members DESC LIMIT 5")->fetchAll();
?>

<!-- 统计卡片 -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#ec4899,#f472b6);"><i class="fa fa-users"></i></div>
        <div class="stat-info">
            <div class="stat-value"><?= $stats['users'] ?></div>
            <div class="stat-label">用户总数</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#a855f7,#c084fc);"><i class="fa fa-file-text"></i></div>
        <div class="stat-info">
            <div class="stat-value"><?= $stats['posts'] ?></div>
            <div class="stat-label">帖子总数</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#f59e0b,#fbbf24);"><i class="fa fa-tree"></i></div>
        <div class="stat-info">
            <div class="stat-value"><?= $stats['tiebas'] ?></div>
            <div class="stat-label">贴吧总数</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:linear-gradient(135deg,#10b981,#34d399);"><i class="fa fa-comments"></i></div>
        <div class="stat-info">
            <div class="stat-value"><?= $stats['comments'] ?></div>
            <div class="stat-label">评论总数</div>
        </div>
    </div>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">
    <!-- 最近帖子 -->
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
            <h3 style="font-size:16px;font-weight:600;"><i class="fa fa-clock-o text-primary"></i> 最近发布</h3>
            <a href="admin.php?page=posts" style="font-size:13px;color:var(--text-soft);">查看全部 <i class="fa fa-angle-right"></i></a>
        </div>
        <?php if (empty($recentPosts)): ?>
            <div class="empty"><i class="fa fa-file-o"></i><p>暂无帖子</p></div>
        <?php else: ?>
            <table class="admin-table">
                <thead>
                    <tr><th>标题</th><th>作者</th><th>贴吧</th><th>时间</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($recentPosts as $p): ?>
                    <tr>
                        <td><a href="index.php?page=post&id=<?= $p['id'] ?>" target="_blank"><?= e(mb_substr($p['title'] ?: $p['content'], 0, 20)) ?></a></td>
                        <td><?= e($p['nickname']) ?></td>
                        <td><span class="tag tag-info"><?= e($p['tieba_name']) ?></span></td>
                        <td class="text-light"><?= time_ago($p['created_at']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- 热门贴吧 -->
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
            <h3 style="font-size:16px;font-weight:600;"><i class="fa fa-fire text-primary"></i> 热门贴吧</h3>
            <a href="admin.php?page=tiebas" style="font-size:13px;color:var(--text-soft);">管理</a>
        </div>
        <?php foreach ($hotTiebas as $t): ?>
            <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border);">
                <div style="width:36px;height:36px;border-radius:10px;background:<?= cover($t) ?>;display:flex;align-items:center;justify-content:center;color:white;">
                    <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
                </div>
                <div style="flex:1;">
                    <div style="font-weight:500;font-size:14px;"><?= e($t['name']) ?></div>
                    <div style="font-size:12px;color:var(--text-light);"><?= $t['members'] ?> 成员 · <?= $t['posts'] ?> 帖子</div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- 最近注册用户 -->
<div class="card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <h3 style="font-size:16px;font-weight:600;"><i class="fa fa-user-plus text-primary"></i> 最近注册</h3>
        <a href="admin.php?page=users" style="font-size:13px;color:var(--text-soft);">查看全部</a>
    </div>
    <table class="admin-table">
        <thead>
            <tr><th>头像</th><th>用户名</th><th>昵称</th><th>角色</th><th>注册时间</th><th>状态</th></tr>
        </thead>
        <tbody>
            <?php foreach ($recentUsers as $u): ?>
            <tr>
                <td><img src="<?= e(avatar($u)) ?>" class="avatar-sm"></td>
                <td><?= e($u['username']) ?></td>
                <td><?= e($u['nickname']) ?></td>
                <td><span class="tag <?= $u['role']==='admin'?'tag-warning':'tag-info' ?>"><?= $u['role']==='admin'?'管理员':'用户' ?></span></td>
                <td class="text-light"><?= $u['created_at'] ?></td>
                <td><span class="tag <?= $u['status']?'tag-success':'tag-danger' ?>"><?= $u['status']?'正常':'禁用' ?></span></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
