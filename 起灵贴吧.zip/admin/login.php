<?php
/**
 * 后台独立登录页（由 admin.php 引入，不可直接访问）
 * 全屏网络随机占位图作为 body 背景；电脑端左右分栏：左栏透明透出背景+标语，右栏毛玻璃登录框；
 * 手机端仅显示居中玻璃登录框（实时获取头像）
 * 变量：$loginError(错误提示)、$currentLoginName(当前已登录的非管理员账号)、$settings
 */
if (!defined('IN_APP')) { http_response_code(403); exit('禁止直接访问'); }

$cssVer = @filemtime(__DIR__ . '/../assets/css/admin.css') ?: '1';
// 全屏背景图：网络随机占位图（Lorem Picsum 横版真实摄影），每次刷新随机数不同，保证不重复
$imgSeed = time() . random_int(1000, 9999);
$bgImg   = 'https://picsum.photos/1920/1080?random=' . $imgSeed;
$bgImgFB = 'https://loremflickr.com/1920/1080/all?lock=' . random_int(1, 99999);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录 - <?= e($settings['site_name']) ?></title>
    <link href="assets/lib/fontawesome/css/all.min.css" rel="stylesheet">
    <link href="assets/lib/fontawesome/css/v4-shims.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/admin.css?v=<?= $cssVer ?>">
</head>
<body class="admin-login-body"
      data-bg="<?= e($bgImg) ?>" data-bgfb="<?= e($bgImgFB) ?>">

<!-- 背景图上的柔光遮罩：保证文字清晰 -->
<div class="login-mask"></div>

<div class="login-wrap">
  <div class="login-split">

    <!-- ========== 左栏：透明（直接透出背景图）+ 标语，仅电脑端显示 ========== -->
    <aside class="login-aside">
        <span class="aside-badge"><img src="https://picsum.photos/100/100?random=4" style="width:14px;height:14px;border-radius:4px;object-fit:cover;" onerror="this.style.display='none'"> <?= e($settings['site_name']) ?> · 管理中心</span>
        <h2 class="aside-title">用心守护<br>每一次相遇的瞬间</h2>
        <p class="aside-desc">内容管理 · 用户管理 · 站点设置，一切尽在掌握</p>
    </aside>

    <!-- ========== 右栏：毛玻璃登录框 ========== -->
    <section class="login-panel">
      <div class="login-inner">

        <!-- 头像圈：输入用户名时实时获取，和前台登录页一致 -->
        <div class="login-avatar-box" id="adminAvatarBox">
            <img id="adminAvatarDefault" src="https://picsum.photos/100/100?random=5" style="display:block;width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'">
            <img id="adminAvatarImg" src="" alt="">
        </div>
        <h1 class="login-title">起灵管理后台</h1>
        <p class="login-subtitle" id="adminAvatarTip">欢迎回来，管理员请登录 </p>

        <!-- 当前已登录但非管理员的提示 -->
        <?php if ($currentLoginName): ?>
        <div class="login-notice">
            <i class="fa fa-info-circle"></i>
            当前登录账号「<strong><?= e($currentLoginName) ?></strong>」没有管理权限，请使用管理员账号登录
        </div>
        <?php endif; ?>

        <!-- 错误提示 -->
        <?php if ($loginError): ?>
        <div class="login-alert">
            <i class="fa fa-exclamation-circle"></i> <?= e($loginError) ?>
        </div>
        <?php endif; ?>

        <!-- 登录表单 -->
        <form method="post" class="login-form" autocomplete="off">
            <div class="login-field">
                <label><i class="fa fa-user"></i> 管理员用户名</label>
                <input type="text" name="username" id="adminUsername"
                       placeholder="请输入管理员用户名"
                       value="<?= e($_POST['username'] ?? '') ?>" required autofocus>
            </div>
            <div class="login-field">
                <label><i class="fa fa-lock"></i> 管理员密码</label>
                <input type="password" name="password" placeholder="请输入管理员密码" required>
            </div>
            <button type="submit" class="login-btn">
                <i class="fa fa-sign-in"></i> 进入管理后台
            </button>
        </form>

        <a href="index.php" class="login-back"><i class="fa fa-home"></i> 返回前台首页</a>
      </div>
    </section>

  </div>
</div>

<script>
/* ===== 背景图：预加载成功后铺满 body，失败自动切换备用网络图源 ===== */
(function(){
    var body = document.body;
    var bg   = body.getAttribute('data-bg');
    var fb   = body.getAttribute('data-bgfb');

    function setBg(url){
        body.style.backgroundImage = 'url("' + url + '")';
        body.classList.add('bg-ready');
    }
    function probe(url, onOk, onFail){
        var im = new Image();
        im.onload = onOk;
        im.onerror = onFail;
        im.src = url;
    }
    probe(bg, function(){ setBg(bg); }, function(){
        probe(fb, function(){ setBg(fb); }, function(){ /* 两个源都失败：保留深紫渐变底 */ });
    });
})();

/* ===== 输入用户名实时获取头像（与前台登录页同款逻辑） ===== */
(function(){
    var usernameInput = document.getElementById('adminUsername');
    var avatarBox     = document.getElementById('adminAvatarBox');
    var avatarDefault = document.getElementById('adminAvatarDefault');
    var avatarImg     = document.getElementById('adminAvatarImg');
    var avatarTip     = document.getElementById('adminAvatarTip');
    var lastQuery = '';

    function showDefaultAvatar() {
        avatarImg.style.display = 'none';
        avatarDefault.style.display = 'block';
        avatarBox.style.background = 'linear-gradient(135deg,#ec4899,#a855f7)';
        avatarTip.textContent = '欢迎回来，管理员请登录 ';
    }

    function fetchAvatar(username) {
        if (!username || username === lastQuery) return;
        lastQuery = username;
        avatarDefault.style.display = 'none';
        avatarImg.style.display = 'none';
        avatarBox.style.background = 'linear-gradient(135deg,#f3f4f6,#e5e7eb)';
        avatarTip.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 正在查找用户...';

        fetch('api/get_avatar.php?username=' + encodeURIComponent(username))
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (username !== lastQuery) return;
            if (d.code === 0) {
                avatarImg.src = d.avatar;
                avatarImg.style.display = 'block';
                avatarBox.style.background = 'linear-gradient(135deg,#ec4899,#a855f7)';
                avatarTip.innerHTML = '<i class="fa fa-check-circle" style="color:#6ee7b7;"></i> 欢迎回来：' + d.nickname;
            } else {
                showDefaultAvatar();
                avatarTip.innerHTML = '<i class="fa fa-question-circle" style="color:rgba(255,255,255,.75);"></i> 平台没有该用户';
            }
        })
        .catch(function(){
            if (username === lastQuery) showDefaultAvatar();
        });
    }

    var timer = null;
    usernameInput.addEventListener('input', function(){
        var val = this.value.trim();
        if (!val) { lastQuery = ''; showDefaultAvatar(); return; }
        clearTimeout(timer);
        timer = setTimeout(function(){ fetchAvatar(val); }, 400);
    });
    usernameInput.addEventListener('blur', function(){
        var val = this.value.trim();
        if (val) fetchAvatar(val);
    });

    // 页面载入时若已回填用户名，立即查询头像
    var initVal = usernameInput.value.trim();
    if (initVal) fetchAvatar(initVal);
})();
</script>

</body>
</html>
