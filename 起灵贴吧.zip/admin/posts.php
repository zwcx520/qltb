<?php
/**
 * 帖子管理
 */
$adminPage = 'posts';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';
if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    // 查询帖子以获取图片和视频路径
    $stmt = db()->prepare("SELECT * FROM posts WHERE id = ?");
    $stmt->execute([$id]);
    $post = $stmt->fetch();
    if ($post) {
        // 删除图片文件
        if (!empty($post['images'])) {
            $imgs = json_decode($post['images'], true);
            if (is_array($imgs)) {
                foreach ($imgs as $img) delete_uploaded_file($img);
            }
        }
        // 删除视频文件
        if (!empty($post['video'])) {
            delete_uploaded_file($post['video']);
        }
        // 删除关联数据
        db()->prepare("DELETE FROM comments WHERE post_id = ?")->execute([$id]);
        db()->prepare("DELETE FROM post_likes WHERE post_id = ?")->execute([$id]);
        db()->prepare("DELETE FROM post_favorites WHERE post_id = ?")->execute([$id]);
        db()->prepare("DELETE FROM messages WHERE post_id = ?")->execute([$id]);
        // 更新计数
        db()->exec("UPDATE tiebas SET posts = GREATEST(posts - 1, 0) WHERE id = {$post['tieba_id']}");
        db()->exec("UPDATE users SET posts = GREATEST(posts - 1, 0) WHERE id = {$post['user_id']}");
    }
    db()->exec("DELETE FROM posts WHERE id = {$id}");
    header('Location: admin.php?page=posts');
    exit;
} elseif ($act === 'top') {
    $id = intval($_GET['id'] ?? 0);
    db()->exec("UPDATE posts SET is_top = 1 - is_top WHERE id = {$id}");
    header('Location: admin.php?page=posts');
    exit;
} elseif ($act === 'hot') {
    $id = intval($_GET['id'] ?? 0);
    db()->exec("UPDATE posts SET is_hot = 1 - is_hot WHERE id = {$id}");
    header('Location: admin.php?page=posts');
    exit;
}

$kw = trim($_GET['kw'] ?? '');
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 20;
$offset = ($pageNum - 1) * $perPage;

$where = '1=1';
if ($kw) $where .= " AND (p.title LIKE '%{$kw}%' OR p.content LIKE '%{$kw}%')";

$total = db()->query("SELECT COUNT(*) FROM posts p WHERE {$where}")->fetchColumn();
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.username, t.name as tieba_name
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE {$where}
    ORDER BY p.id DESC
    LIMIT {$offset}, {$perPage}
");
$stmt->execute();
$posts = $stmt->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <form method="get" style="display:flex;gap:8px;">
            <input type="hidden" name="page" value="posts">
            <input name="kw" class="form-input" placeholder="搜索帖子标题/内容" value="<?= e($kw) ?>">
            <button class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th><th>标题</th><th>作者</th><th>贴吧</th><th>类型</th>
                <th>浏览</th><th>点赞</th><th>评论</th><th>状态</th><th>发布时间</th><th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td>
                    <a href="index.php?page=post&id=<?= $p['id'] ?>" target="_blank" style="color:var(--primary);">
                        <?= e(mb_substr($p['title'] ?: $p['content'], 0, 25)) ?>
                    </a>
                    <?php if ($p['is_top']): ?><span class="tag tag-warning">置顶</span><?php endif; ?>
                    <?php if ($p['is_hot']): ?><span class="tag tag-danger">热门</span><?php endif; ?>
                </td>
                <td><?= e($p['nickname'] ?: $p['username']) ?></td>
                <td><span class="tag tag-info"><?= e($p['tieba_name']) ?></span></td>
                <td>
                    <?php
                        $typeMap = ['text'=>'<i class="fa fa-font"></i> 图文','image'=>'<i class="fa fa-image"></i> 图片','video'=>'<i class="fa fa-video-camera"></i> 视频','vote'=>'<i class="fa fa-check-square-o"></i> 投票'];
                        echo $typeMap[$p['type']] ?? $p['type'];
                    ?>
                </td>
                <td><?= $p['views'] ?></td>
                <td><?= $p['likes'] ?></td>
                <td><?= $p['comments'] ?></td>
                <td><span class="tag <?= $p['status']?'tag-success':'tag-danger' ?>"><?= $p['status']?'正常':'隐藏' ?></span></td>
                <td class="text-light"><?= $p['created_at'] ?></td>
                <td style="white-space:nowrap;">
                    <a href="admin.php?page=posts&act=top&id=<?= $p['id'] ?>" class="btn btn-warning btn-sm" title="置顶">
                        <i class="fa fa-flag"></i>
                    </a>
                    <a href="admin.php?page=posts&act=hot&id=<?= $p['id'] ?>" class="btn btn-success btn-sm" title="热门">
                        <i class="fa fa-fire"></i>
                    </a>
                    <a href="index.php?page=post&id=<?= $p['id'] ?>" target="_blank" class="btn btn-primary btn-sm" title="查看">
                        <i class="fa fa-eye"></i>
                    </a>
                    <a href="admin.php?page=posts&act=delete&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该帖子？')" title="删除">
                        <i class="fa fa-trash"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($posts)): ?>
        <div class="empty"><i class="fa fa-file-text-o"></i><p>暂无帖子</p></div>
    <?php endif; ?>

    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div class="pagination">
        <?php if ($pageNum > 1): ?>
            <a href="admin.php?page=posts&kw=<?= urlencode($kw) ?>&p=<?= $pageNum-1 ?>"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="active"><?= $pageNum ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="admin.php?page=posts&kw=<?= urlencode($kw) ?>&p=<?= $pageNum+1 ?>"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
