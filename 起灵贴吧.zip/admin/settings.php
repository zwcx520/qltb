<?php
/**
 * 系统设置
 */
$adminPage = 'settings';
include __DIR__ . '/admin_header.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = trim($_POST['site_name'] ?? '');
    $siteDesc = trim($_POST['site_desc'] ?? '');
    $siteKeywords = trim($_POST['site_keywords'] ?? '');
    $siteLogo = trim($_POST['site_logo'] ?? '');
    $icp = trim($_POST['icp'] ?? '');
    $allowRegister = intval($_POST['allow_register'] ?? 0);
    $postAudit = intval($_POST['post_audit'] ?? 0);
    $announcement = trim($_POST['announcement'] ?? '');
    $bannerImage = trim($_POST['banner_image'] ?? '');

    // 处理首页Banner背景图上传
    if (!empty($_FILES['banner_image_file']['name'])) {
        $r = handle_upload($_FILES['banner_image_file'], ['jpg','jpeg','png','gif','webp'], 5242880);
        if ($r['ok']) {
            // 删除旧图
            if (!empty($settings['banner_image'])) {
                delete_uploaded_file($settings['banner_image']);
            }
            $bannerImage = $r['url'];
        } else {
            $msg = 'Banner上传失败：' . $r['msg'];
        }
    }

    $exists = db()->query("SELECT id FROM settings LIMIT 1")->fetch();
    if ($exists) {
        db()->prepare("UPDATE settings SET site_name=?, site_desc=?, site_keywords=?, site_logo=?, icp=?, allow_register=?, post_audit=?, announcement=?, banner_image=? WHERE id=?")
            ->execute([$siteName, $siteDesc, $siteKeywords, $siteLogo, $icp, $allowRegister, $postAudit, $announcement, $bannerImage, $exists['id']]);
    } else {
        db()->prepare("INSERT INTO settings (site_name, site_desc, site_keywords, site_logo, icp, allow_register, post_audit, announcement, banner_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$siteName, $siteDesc, $siteKeywords, $siteLogo, $icp, $allowRegister, $postAudit, $announcement, $bannerImage]);
    }
    $settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch();
    $msg = '保存成功';
}

// 重置安装锁
if (isset($_GET['reset'])) {
    @unlink(__DIR__ . '/../config/installed.lock');
    header('Location: install.php');
    exit;
}
?>

<?php if ($msg): ?>
    <div style="background:#dcfce7;color:#166534;padding:12px 20px;border-radius:10px;margin-bottom:16px;">
        <i class="fa fa-check-circle"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<div class="card">
    <h3 style="font-size:16px;font-weight:600;margin-bottom:20px;"><i class="fa fa-cog text-primary"></i> 站点设置</h3>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label class="form-label">站点名称</label>
            <input name="site_name" class="form-input" value="<?= e($settings['site_name'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label class="form-label">站点描述</label>
            <textarea name="site_desc" class="form-textarea"><?= e($settings['site_desc'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label class="form-label">站点关键词</label>
            <input name="site_keywords" class="form-input" value="<?= e($settings['site_keywords'] ?? '') ?>" placeholder="多个关键词用逗号分隔">
        </div>
        <div class="form-group">
            <label class="form-label">站点Logo URL（可选）</label>
            <input name="site_logo" class="form-input" value="<?= e($settings['site_logo'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label class="form-label">ICP备案号</label>
            <input name="icp" class="form-input" value="<?= e($settings['icp'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label class="form-label">首页公告内容（跑马灯滚动显示）</label>
            <textarea name="announcement" class="form-textarea" rows="3" placeholder="请输入社区公告内容，例如：请遵守社区规范，禁止发布违法违规、色情暴力、人身攻击等不良信息..."><?= e($settings['announcement'] ?? '') ?></textarea>
            <small style="color:var(--text-soft);font-size:12px;">留空则不显示公告栏。建议内容简洁，告知用户遵守法律法规和社区规范。</small>
        </div>
        <div class="form-group">
            <label class="form-label">首页Banner背景图（可选，不上传用默认渐变）</label>
            <input type="file" name="banner_image_file" id="banner-image-input" accept="image/*" style="font-size:13px;">
            <input type="hidden" name="banner_image" value="<?= e($settings['banner_image'] ?? '') ?>">
            <?php if (!empty($settings['banner_image'])): ?>
                <div style="margin-top:6px;font-size:12px;color:var(--text-soft);">当前Banner：</div>
            <?php endif; ?>
            <div id="banner-preview-box" style="margin-top:8px;display:<?= !empty($settings['banner_image'])?'block':'none' ?>;">
                <img id="banner-preview" src="<?= e($settings['banner_image'] ?? '') ?>" style="max-width:100%;max-height:160px;border-radius:10px;display:block;">
            </div>
            <small style="color:var(--text-soft);font-size:12px;">建议尺寸 1200×500，支持 jpg/png/gif/webp，最大 5MB。</small>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0;">
            <div style="background:var(--bg);padding:16px;border-radius:12px;">
                <label class="form-label" style="font-size:14px;font-weight:600;color:var(--text);">允许新用户注册</label>
                <div style="display:flex;gap:16px;margin-top:8px;">
                    <label style="cursor:pointer;"><input type="radio" name="allow_register" value="1" <?= ($settings['allow_register'] ?? 1)?'checked':'' ?>> 开启</label>
                    <label style="cursor:pointer;"><input type="radio" name="allow_register" value="0" <?= !($settings['allow_register'] ?? 1)?'checked':'' ?>> 关闭</label>
                </div>
            </div>
            <div style="background:var(--bg);padding:16px;border-radius:12px;">
                <label class="form-label" style="font-size:14px;font-weight:600;color:var(--text);">帖子发布审核</label>
                <div style="display:flex;gap:16px;margin-top:8px;">
                    <label style="cursor:pointer;"><input type="radio" name="post_audit" value="0" <?= !($settings['post_audit'] ?? 0)?'checked':'' ?>> 免审核</label>
                    <label style="cursor:pointer;"><input type="radio" name="post_audit" value="1" <?= ($settings['post_audit'] ?? 0)?'checked':'' ?>> 需审核</label>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> 保存设置</button>
    </form>
</div>

<div class="card">
    <h3 style="font-size:16px;font-weight:600;margin-bottom:12px;"><i class="fa fa-database text-primary"></i> 系统信息</h3>
    <table class="admin-table">
        <tr><td style="width:200px;color:var(--text-soft);">PHP版本</td><td><?= PHP_VERSION ?></td></tr>
        <tr><td style="color:var(--text-soft);">数据库引擎</td><td>MySQL (PDO)</td></tr>
        <tr><td style="color:var(--text-soft);">系统版本</td><td>起灵贴吧 v1.0.0</td></tr>
        <tr><td style="color:var(--text-soft);">上传目录</td><td>assets/uploads/</td></tr>
    </table>

    <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--border);">
        <h4 style="font-weight:600;margin-bottom:10px;color:var(--danger);"><i class="fa fa-exclamation-triangle"></i> 危险操作</h4>
        <a href="admin.php?page=settings&reset=1" class="btn btn-danger" onclick="return confirm('确定要重置安装锁吗？这将允许重新运行安装程序！')">
            <i class="fa fa-refresh"></i> 重置安装锁（重新安装）
        </a>
    </div>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
<script>
var bannerInput = document.getElementById('banner-image-input');
var bannerPreviewBox = document.getElementById('banner-preview-box');
var bannerPreview = document.getElementById('banner-preview');
if (bannerInput && bannerPreview) {
    bannerInput.addEventListener('change', function(){
        if (this.files && this.files[0]) {
            bannerPreview.src = URL.createObjectURL(this.files[0]);
            bannerPreviewBox.style.display = 'block';
        }
    });
}
</script>
