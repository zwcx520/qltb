<?php
/**
 * 贴吧管理
 */
$adminPage = 'tiebas';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';

// 保存（新增/编辑）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($act === 'save')) {
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? 'tree');
    $category = trim($_POST['category'] ?? '');
    $cover = trim($_POST['cover'] ?? '');

    // 处理封面图上传
    if (!empty($_FILES['cover_file']['name'])) {
        $r = handle_upload($_FILES['cover_file'], ['jpg','jpeg','png','gif','webp'], 5242880);
        if ($r['ok']) {
            // 删除旧封面
            if ($id) {
                $old = db()->query("SELECT cover FROM tiebas WHERE id = {$id}")->fetch();
                if ($old && !empty($old['cover'])) delete_uploaded_file($old['cover']);
            }
            $cover = $r['url'];
        }
    }

    if ($id) {
        $stmt = db()->prepare("UPDATE tiebas SET name=?, description=?, icon=?, category=?, cover=? WHERE id=?");
        $stmt->execute([$name, $description, $icon, $category, $cover, $id]);
    } else {
        $stmt = db()->prepare("INSERT INTO tiebas (name, description, icon, category, cover, members, posts, created_at) VALUES (?, ?, ?, ?, ?, 0, 0, NOW())");
        $stmt->execute([$name, $description, $icon, $category, $cover]);
    }
    header('Location: admin.php?page=tiebas');
    exit;
}

if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    // 查询贴吧信息
    $tieba = db()->query("SELECT * FROM tiebas WHERE id = {$id}")->fetch();
    if ($tieba) {
        // 删除封面图片
        if (!empty($tieba['cover'])) delete_uploaded_file($tieba['cover']);
        // 查询该贴吧所有帖子，删除图片和视频
        $posts = db()->query("SELECT images, video FROM posts WHERE tieba_id = {$id}")->fetchAll();
        foreach ($posts as $p) {
            if (!empty($p['images'])) {
                $imgs = json_decode($p['images'], true);
                if (is_array($imgs)) foreach ($imgs as $img) delete_uploaded_file($img);
            }
            if (!empty($p['video'])) delete_uploaded_file($p['video']);
        }
        // 获取帖子ID列表，用于删除关联数据
        $postIds = db()->query("SELECT id FROM posts WHERE tieba_id = {$id}")->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($postIds)) {
            $ids = implode(',', $postIds);
            db()->exec("DELETE FROM comments WHERE post_id IN ({$ids})");
            db()->exec("DELETE FROM post_likes WHERE post_id IN ({$ids})");
            db()->exec("DELETE FROM post_favorites WHERE post_id IN ({$ids})");
            db()->exec("DELETE FROM messages WHERE post_id IN ({$ids})");
        }
        // 删除帖子、关注、贴吧
        db()->exec("DELETE FROM posts WHERE tieba_id = {$id}");
        db()->exec("DELETE FROM tieba_follows WHERE tieba_id = {$id}");
        db()->exec("DELETE FROM tiebas WHERE id = {$id}");
    }
    header('Location: admin.php?page=tiebas');
    exit;
}

// 编辑时获取数据
$edit = null;
if ($act === 'edit') {
    $id = intval($_GET['id'] ?? 0);
    $edit = db()->query("SELECT * FROM tiebas WHERE id = {$id}")->fetch();
}

$tiebas = db()->query("SELECT * FROM tiebas ORDER BY id DESC")->fetchAll();
$cats = db()->query("SELECT * FROM categories ORDER BY sort ASC")->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <h3 style="font-size:16px;font-weight:600;flex:1;">
            <i class="fa fa-tree text-primary"></i> 贴吧管理
            <span class="text-light" style="font-weight:normal;font-size:13px;">（共 <?= count($tiebas) ?> 个）</span>
        </h3>
        <button class="btn btn-primary" onclick="document.getElementById('tieba-form').style.display='block'">
            <i class="fa fa-plus"></i> 新建贴吧
        </button>
    </div>

    <!-- 新增/编辑表单 -->
    <div id="tieba-form" style="display:<?= $edit ? 'block' : 'none' ?>;background:var(--bg);padding:20px;border-radius:12px;margin-bottom:20px;">
        <h4 style="margin-bottom:16px;font-weight:600;"><?= $edit ? '编辑贴吧' : '新建贴吧' ?></h4>
        <form method="post" action="admin.php?page=tiebas&act=save" enctype="multipart/form-data" id="admin-tieba-form">
            <input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div class="form-group">
                    <label class="form-label">贴吧名称 *</label>
                    <input name="name" class="form-input" required value="<?= e($edit['name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">选择图标</label>
                    <?= icon_select('icon', $edit['icon'] ?? 'tree') ?>
                </div>
                <div class="form-group">
                    <label class="form-label">分类</label>
                    <select name="category" class="form-select">
                        <option value="">无分类</option>
                        <?php foreach ($cats as $c): ?>
                            <option value="<?= e($c['name']) ?>" <?= ($edit['category'] ?? '')===$c['name']?'selected':'' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">封面图（可选，不上传用默认图标）</label>
                    <input type="file" name="cover_file" id="admin-cover-input" accept="image/*" style="font-size:13px;">
                    <input type="hidden" name="cover" value="<?= e($edit['cover'] ?? '') ?>">
                    <?php if (!empty($edit['cover'])): ?>
                    <div style="margin-top:6px;font-size:12px;color:var(--text-soft);">当前封面：</div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group" id="admin-cover-preview-box" style="display:<?= !empty($edit['cover'])?'block':'none' ?>;">
                <img id="admin-cover-preview" src="<?= e($edit['cover'] ?? '') ?>" style="max-height:120px;border-radius:8px;display:block;">
            </div>
            <div class="form-group">
                <label class="form-label">贴吧简介</label>
                <textarea name="description" class="form-textarea"><?= e($edit['description'] ?? '') ?></textarea>
            </div>
            <div style="display:flex;gap:8px;">
                <button class="btn btn-primary"><i class="fa fa-save"></i> 保存</button>
                <a href="admin.php?page=tiebas" class="btn btn-warning">取消</a>
            </div>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr><th>ID</th><th>封面</th><th>名称</th><th>简介</th><th>成员</th><th>帖子</th><th>分类</th><th>创建时间</th><th>操作</th></tr>
        </thead>
        <tbody>
            <?php foreach ($tiebas as $t): ?>
            <tr>
                <td><?= $t['id'] ?></td>
                <td>
                    <?php if ($t['cover']): ?>
                        <img src="<?= e($t['cover']) ?>" class="thumb">
                    <?php else: ?>
                        <div class="thumb" style="background:<?= cover($t) ?>;display:flex;align-items:center;justify-content:center;color:white;"><i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i></div>
                    <?php endif; ?>
                </td>
                <td><strong><?= e($t['name']) ?></strong></td>
                <td class="text-soft" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($t['description']) ?></td>
                <td><?= $t['members'] ?></td>
                <td><?= $t['posts'] ?></td>
                <td><span class="tag tag-info"><?= e($t['category'] ?: '-') ?></span></td>
                <td class="text-light"><?= $t['created_at'] ?></td>
                <td>
                    <a href="admin.php?page=tiebas&act=edit&id=<?= $t['id'] ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>
                    <a href="admin.php?page=tiebas&act=delete&id=<?= $t['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该贴吧？贴吧封面、所有帖子及帖子图片/视频将被一并删除，且不可恢复！')"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($tiebas)): ?>
        <div class="empty"><i class="fa fa-tree"></i><p>暂无贴吧</p></div>
    <?php endif; ?>
</div>

<script>
// 后台封面图预览
var coverInput = document.getElementById('admin-cover-input');
var coverPreviewBox = document.getElementById('admin-cover-preview-box');
var coverPreview = document.getElementById('admin-cover-preview');
if (coverInput && coverPreview) {
    coverInput.addEventListener('change', function(){
        if (this.files && this.files[0]) {
            coverPreview.src = URL.createObjectURL(this.files[0]);
            coverPreviewBox.style.display = 'block';
        }
    });
}
</script>

<?php include __DIR__ . '/admin_footer.php'; ?>
