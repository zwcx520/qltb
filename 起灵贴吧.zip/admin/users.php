<?php
/**
 * 用户管理
 * 权限隔离：站长(super_admin)可管理所有人；管理员(admin)不能操作站长和其他管理员
 */
$adminPage = 'users';
include __DIR__ . '/admin_header.php';

$myRole = $user['role']; // 当前操作者角色：super_admin 或 admin

// 判断当前操作者能否操作目标用户
function can_manage($myRole, $targetUser) {
    if (!$targetUser) return false;
    if ($myRole === 'super_admin') return true;             // 站长可管理所有人
    // 管理员只能操作普通用户
    return $targetUser['role'] === 'user';
}

// 操作
$act = $_GET['act'] ?? '';
if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    if ($id != $user['id']) {
        $target = db()->query("SELECT role FROM users WHERE id={$id}")->fetch();
        if (can_manage($myRole, $target)) {
            db()->exec("DELETE FROM users WHERE id = {$id}");
        }
    }
    header('Location: admin.php?page=users');
    exit;
} elseif ($act === 'toggle') {
    $id = intval($_GET['id'] ?? 0);
    $target = db()->query("SELECT role FROM users WHERE id={$id}")->fetch();
    if (can_manage($myRole, $target)) {
        db()->exec("UPDATE users SET status = 1 - status WHERE id = {$id}");
    }
    header('Location: admin.php?page=users');
    exit;
} elseif ($act === 'role') {
    $id = intval($_GET['id'] ?? 0);
    $target = db()->query("SELECT role FROM users WHERE id={$id}")->fetch();
    if (can_manage($myRole, $target)) {
        // 站长可升降级（user↔admin）；管理员无权改角色（被 can_manage 拦截，因为目标只能是 user，但管理员也不应能改角色）
        if ($myRole === 'super_admin') {
            $role = $_GET['role'] === 'admin' ? 'admin' : 'user';
            db()->exec("UPDATE users SET role = '{$role}' WHERE id = {$id}");
        }
    }
    header('Location: admin.php?page=users');
    exit;
} elseif ($act === 'reset_pwd') {
    // 重置密码
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = intval($_POST['id'] ?? 0);
        $newPwd = trim($_POST['password'] ?? '');
        $target = db()->query("SELECT role FROM users WHERE id={$id}")->fetch();
        if ($id && $id != $user['id'] && can_manage($myRole, $target)) {
            if (empty($newPwd)) $newPwd = '123456'; // 默认密码
            $hash = password_hash($newPwd, PASSWORD_DEFAULT);
            db()->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $id]);
        }
        header('Location: admin.php?page=users&pwd_ok=1');
        exit;
    }
}

$kw = trim($_GET['kw'] ?? '');
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 20;
$offset = ($pageNum - 1) * $perPage;

$where = '1=1';
if ($kw) $where .= " AND (username LIKE '%{$kw}%' OR nickname LIKE '%{$kw}%' OR email LIKE '%{$kw}%')";

$total = db()->query("SELECT COUNT(*) FROM users WHERE {$where}")->fetchColumn();
$stmt = db()->prepare("SELECT * FROM users WHERE {$where} ORDER BY role ASC, id DESC LIMIT {$offset}, {$perPage}");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<div class="card">
    <?php if (isset($_GET['pwd_ok'])): ?>
    <div style="padding:10px 16px;background:#dcfce7;color:#166534;border-radius:8px;margin-bottom:12px;font-size:13px;">
        <i class="fa fa-check-circle"></i> 密码重置成功
    </div>
    <?php endif; ?>

    <div class="toolbar">
        <form method="get" style="display:flex;gap:8px;">
            <input type="hidden" name="page" value="users">
            <input name="kw" class="form-input" placeholder="搜索用户名/昵称/邮箱" value="<?= e($kw) ?>">
            <button class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
        </form>
        <a href="admin.php?page=users" class="btn btn-warning">重置</a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th><th>头像</th><th>用户名</th><th>昵称</th><th>邮箱</th>
                <th>帖子</th><th>角色/等级</th><th>状态</th><th>注册时间</th><th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><img src="<?= e(avatar($u)) ?>" class="avatar-sm"></td>
                <td><?= e($u['username']) ?></td>
                <td><?= e($u['nickname']) ?></td>
                <td class="text-light"><?= e($u['email']) ?></td>
                <td><?= $u['posts'] ?></td>
                <td>
                    <?php
                        $canEdit = can_manage($myRole, $u) && $u['id'] != $user['id'];
                        if ($u['role'] === 'super_admin'):
                    ?>
                        <span class="tag" style="background:linear-gradient(135deg,#fbbf24,#f59e0b);color:white;"><i class="fa fa-star"></i> 站长</span>
                    <?php elseif ($u['role'] === 'admin'): ?>
                        <span class="tag tag-warning"><i class="fa fa-shield"></i> 管理员</span>
                        <?php if ($canEdit && $myRole === 'super_admin'): ?>
                            <a href="admin.php?page=users&act=role&id=<?= $u['id'] ?>&role=user" class="tag tag-info" style="margin-left:4px;font-size:11px;" onclick="return confirm('确定将该管理员降级为普通用户吗？')">
                                <i class="fa fa-arrow-down"></i> 降级
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="tag tag-info">Lv.<?= user_level($u) ?></span>
                        <?php if ($canEdit && $myRole === 'super_admin'): ?>
                            <a href="admin.php?page=users&act=role&id=<?= $u['id'] ?>&role=admin" class="tag tag-warning" style="margin-left:4px;font-size:11px;" onclick="return confirm('确定将该用户升级为管理员吗？')">
                                <i class="fa fa-arrow-up"></i> 升级
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($canEdit): ?>
                        <a href="admin.php?page=users&act=toggle&id=<?= $u['id'] ?>" class="tag <?= $u['status']?'tag-success':'tag-danger' ?>">
                            <?= $u['status']?'正常':'禁用' ?>
                        </a>
                    <?php else: ?>
                        <span class="tag <?= $u['status']?'tag-success':'tag-danger' ?>"><?= $u['status']?'正常':'禁用' ?></span>
                    <?php endif; ?>
                </td>
                <td class="text-light"><?= $u['created_at'] ?></td>
                <td>
                    <?php if ($canEdit): ?>
                        <button class="btn btn-info btn-sm" onclick="openResetPwd(<?= $u['id'] ?>, '<?= e($u['nickname'] ?: $u['username']) ?>')" title="重置密码">
                            <i class="fa fa-key"></i>
                        </button>
                        <a href="admin.php?page=users&act=delete&id=<?= $u['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该用户？所有关联数据将被清除！')">
                            <i class="fa fa-trash"></i>
                        </a>
                    <?php else: ?>
                        <span style="font-size:12px;color:var(--text-light);">无权操作</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($users)): ?>
        <div class="empty"><i class="fa fa-users"></i><p>暂无用户</p></div>
    <?php endif; ?>

    <!-- 分页 -->
    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div class="pagination">
        <?php if ($pageNum > 1): ?>
            <a href="admin.php?page=users&kw=<?= urlencode($kw) ?>&p=<?= $pageNum-1 ?>"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="active"><?= $pageNum ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="admin.php?page=users&kw=<?= urlencode($kw) ?>&p=<?= $pageNum+1 ?>"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- 重置密码模态框 -->
<div id="resetPwdModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;padding:20px;">
    <div style="background:white;border-radius:16px;padding:24px;width:100%;max-width:360px;box-shadow:0 10px 40px rgba(0,0,0,0.2);">
        <h3 style="font-size:16px;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
            <i class="fa fa-key" style="color:var(--primary);"></i> 重置密码
        </h3>
        <p style="font-size:13px;color:var(--text-soft);margin-bottom:12px;">
            正在为用户 <strong id="resetUserName" style="color:var(--primary);"></strong> 重置密码
        </p>
        <form method="post" action="admin.php?page=users&act=reset_pwd" id="resetPwdForm">
            <input type="hidden" name="id" id="resetUserId">
            <div style="margin-bottom:12px;">
                <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">新密码</label>
                <input type="text" name="password" class="form-input" placeholder="留空则重置为默认密码 123456" style="width:100%;">
            </div>
            <div style="display:flex;gap:8px;">
                <button type="button" class="btn btn-ghost" style="flex:1;" onclick="closeResetPwd()">取消</button>
                <button type="submit" class="btn btn-primary" style="flex:1;"><i class="fa fa-check"></i> 确认重置</button>
            </div>
        </form>
    </div>
</div>

<script>
function openResetPwd(id, name) {
    document.getElementById('resetUserId').value = id;
    document.getElementById('resetUserName').textContent = name;
    const modal = document.getElementById('resetPwdModal');
    modal.style.display = 'flex';
}
function closeResetPwd() {
    document.getElementById('resetPwdModal').style.display = 'none';
    document.getElementById('resetPwdForm').reset();
}
// 点击遮罩关闭
document.getElementById('resetPwdModal').addEventListener('click', function(e){
    if (e.target === this) closeResetPwd();
});
</script>

<?php include __DIR__ . '/admin_footer.php'; ?>
