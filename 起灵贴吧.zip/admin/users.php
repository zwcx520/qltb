<?php
/**
 * 用户管理
 */
$adminPage = 'users';
include __DIR__ . '/admin_header.php';

// 操作
$act = $_GET['act'] ?? '';
if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    if ($id != $user['id']) {
        db()->exec("DELETE FROM users WHERE id = {$id}");
        header('Location: admin.php?page=users');
        exit;
    }
} elseif ($act === 'toggle') {
    $id = intval($_GET['id'] ?? 0);
    db()->exec("UPDATE users SET status = 1 - status WHERE id = {$id}");
    header('Location: admin.php?page=users');
    exit;
} elseif ($act === 'role') {
    $id = intval($_GET['id'] ?? 0);
    $role = $_GET['role'] === 'admin' ? 'admin' : 'user';
    // 不能降级自己
    if ($id != $user['id']) {
        db()->exec("UPDATE users SET role = '{$role}' WHERE id = {$id}");
    }
    header('Location: admin.php?page=users');
    exit;
} elseif ($act === 'reset_pwd') {
    // 重置密码
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = intval($_POST['id'] ?? 0);
        $newPwd = trim($_POST['password'] ?? '');
        if ($id && $id != $user['id']) {
            if (empty($newPwd)) $newPwd = '123456'; // 默认密码
            $hash = password_hash($newPwd, PASSWORD_DEFAULT);
            db()->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $id]);
        }
        header('Location: admin.php?page=users&pwd_ok=1');
        exit;
    }
}

$kw = trim($_GET['kw'] ?? '');
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 20;
$offset = ($pageNum - 1) * $perPage;

$where = '1=1';
if ($kw) $where .= " AND (username LIKE '%{$kw}%' OR nickname LIKE '%{$kw}%' OR email LIKE '%{$kw}%')";

$total = db()->query("SELECT COUNT(*) FROM users WHERE {$where}")->fetchColumn();
$stmt = db()->prepare("SELECT * FROM users WHERE {$where} ORDER BY id DESC LIMIT {$offset}, {$perPage}");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<div class="card">
    <?php if (isset($_GET['pwd_ok'])): ?>
    <div style="padding:10px 16px;background:#dcfce7;color:#166534;border-radius:8px;margin-bottom:12px;font-size:13px;">
        <i class="fa fa-check-circle"></i> 密码重置成功
    </div>
    <?php endif; ?>

    <div class="toolbar">
        <form method="get" style="display:flex;gap:8px;">
            <input type="hidden" name="page" value="users">
            <input name="kw" class="form-input" placeholder="搜索用户名/昵称/邮箱" value="<?= e($kw) ?>">
            <button class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
        </form>
        <a href="admin.php?page=users" class="btn btn-warning">重置</a>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th><th>头像</th><th>用户名</th><th>昵称</th><th>邮箱</th>
                <th>帖子</th><th>角色</th><th>状态</th><th>注册时间</th><th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><img src="<?= e(avatar($u)) ?>" class="avatar-sm"></td>
                <td><?= e($u['username']) ?></td>
                <td><?= e($u['nickname']) ?></td>
                <td class="text-light"><?= e($u['email']) ?></td>
                <td><?= $u['posts'] ?></td>
                <td>
                    <?php if ($u['id'] != $user['id']): ?>
                        <a href="admin.php?page=users&act=role&id=<?= $u['id'] ?>&role=<?= $u['role']==='admin'?'user':'admin' ?>"
                           class="tag <?= $u['role']==='admin'?'tag-warning':'tag-info' ?>"
                           onclick="return confirm('确定要将该用户<?= $u['role']==='admin'?'降级为普通用户':'升级为管理员' ?>吗？')">
                            <i class="fa fa-<?= $u['role']==='admin'?'arrow-down':'arrow-up' ?>"></i>
                            <?= $u['role']==='admin'?'管理员':'用户' ?>
                        </a>
                    <?php else: ?>
                        <span class="tag tag-warning"><i class="fa fa-star"></i> 超级管理员</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($u['id'] != $user['id']): ?>
                        <a href="admin.php?page=users&act=toggle&id=<?= $u['id'] ?>" class="tag <?= $u['status']?'tag-success':'tag-danger' ?>">
                            <?= $u['status']?'正常':'禁用' ?>
                        </a>
                    <?php else: ?>
                        <span class="tag tag-success">正常</span>
                    <?php endif; ?>
                </td>
                <td class="text-light"><?= $u['created_at'] ?></td>
                <td>
                    <?php if ($u['id'] != $user['id']): ?>
                        <button class="btn btn-info btn-sm" onclick="openResetPwd(<?= $u['id'] ?>, '<?= e($u['nickname'] ?: $u['username']) ?>')" title="重置密码">
                            <i class="fa fa-key"></i>
                        </button>
                        <a href="admin.php?page=users&act=delete&id=<?= $u['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该用户？所有关联数据将被清除！')">
                            <i class="fa fa-trash"></i>
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($users)): ?>
        <div class="empty"><i class="fa fa-users"></i><p>暂无用户</p></div>
    <?php endif; ?>

    <!-- 分页 -->
    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div class="pagination">
        <?php if ($pageNum > 1): ?>
            <a href="admin.php?page=users&kw=<?= urlencode($kw) ?>&p=<?= $pageNum-1 ?>"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="active"><?= $pageNum ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="admin.php?page=users&kw=<?= urlencode($kw) ?>&p=<?= $pageNum+1 ?>"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<!-- 重置密码模态框 -->
<div id="resetPwdModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;padding:20px;">
    <div style="background:white;border-radius:16px;padding:24px;width:100%;max-width:360px;box-shadow:0 10px 40px rgba(0,0,0,0.2);">
        <h3 style="font-size:16px;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
            <i class="fa fa-key" style="color:var(--primary);"></i> 重置密码
        </h3>
        <p style="font-size:13px;color:var(--text-soft);margin-bottom:12px;">
            正在为用户 <strong id="resetUserName" style="color:var(--primary);"></strong> 重置密码
        </p>
        <form method="post" action="admin.php?page=users&act=reset_pwd" id="resetPwdForm">
            <input type="hidden" name="id" id="resetUserId">
            <div style="margin-bottom:12px;">
                <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">新密码</label>
                <input type="text" name="password" class="form-input" placeholder="留空则重置为默认密码 123456" style="width:100%;">
            </div>
            <div style="display:flex;gap:8px;">
                <button type="button" class="btn btn-ghost" style="flex:1;" onclick="closeResetPwd()">取消</button>
                <button type="submit" class="btn btn-primary" style="flex:1;"><i class="fa fa-check"></i> 确认重置</button>
            </div>
        </form>
    </div>
</div>

<script>
function openResetPwd(id, name) {
    document.getElementById('resetUserId').value = id;
    document.getElementById('resetUserName').textContent = name;
    const modal = document.getElementById('resetPwdModal');
    modal.style.display = 'flex';
}
function closeResetPwd() {
    document.getElementById('resetPwdModal').style.display = 'none';
    document.getElementById('resetPwdForm').reset();
}
// 点击遮罩关闭
document.getElementById('resetPwdModal').addEventListener('click', function(e){
    if (e.target === this) closeResetPwd();
});
</script>

<?php include __DIR__ . '/admin_footer.php'; ?>
