<?php
/**
 * 评论接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
$content = trim($_POST['content'] ?? '');
$parentId = intval($_POST['parent_id'] ?? 0);

if (!$postId || !$content) json_response(null, 1, '参数错误');

$stmt = db()->prepare("INSERT INTO comments (post_id, user_id, parent_id, content, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->execute([$postId, $user['id'], $parentId, $content]);

db()->exec("UPDATE posts SET comments = comments + 1 WHERE id = {$postId}");

// 发送消息给帖子作者
$post = db()->query("SELECT user_id FROM posts WHERE id = {$postId}")->fetch();
if ($post && $post['user_id'] != $user['id']) {
    db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'comment', ?, ?, NOW())")
        ->execute([$user['id'], $post['user_id'], '评论了你的帖子', $postId]);
}

json_response(['id' => db()->lastInsertId()]);
