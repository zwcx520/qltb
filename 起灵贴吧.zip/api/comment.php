<?php
/**
 * 评论接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
$content = trim($_POST['content'] ?? '');
$parentId = intval($_POST['parent_id'] ?? 0);

if (!$postId || !$content) json_response(null, 1, '参数错误');

// 私密帖：仅作者本人和管理员可评论，其他用户（含伪造请求）一律拒绝
$post = db()->prepare("SELECT user_id, visibility FROM posts WHERE id = ?");
$post->execute([$postId]);
$postRow = $post->fetch();
if (!$postRow) json_response(null, 1, '帖子不存在或已被删除');
if (($postRow['visibility'] ?? 'public') === 'private' && $postRow['user_id'] != $user['id'] && !in_array($user['role'], ['admin','super_admin'])) {
    json_response(null, 1, '无权评论该帖子');
}

$stmt = db()->prepare("INSERT INTO comments (post_id, user_id, parent_id, content, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->execute([$postId, $user['id'], $parentId, $content]);

db()->exec("UPDATE posts SET comments = comments + 1 WHERE id = {$postId}");

// 发送消息给帖子作者
if ($postRow['user_id'] != $user['id']) {
    db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'comment', ?, ?, NOW())")
        ->execute([$user['id'], $postRow['user_id'], '评论了你的帖子', $postId]);
}

json_response(['id' => db()->lastInsertId()]);
