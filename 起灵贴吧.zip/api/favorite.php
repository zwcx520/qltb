<?php
/**
 * 收藏接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
if (!$postId) json_response(null, 1, '参数错误');

$favorited = is_favorited($postId);
if ($favorited) {
    db()->prepare("DELETE FROM post_favorites WHERE user_id = ? AND post_id = ?")->execute([$user['id'], $postId]);
    db()->exec("UPDATE posts SET favorites = GREATEST(favorites - 1, 0) WHERE id = {$postId}");
    $newFav = false;
} else {
    db()->prepare("INSERT INTO post_favorites (post_id, user_id, created_at) VALUES (?, ?, NOW())")
        ->execute([$postId, $user['id']]);
    db()->exec("UPDATE posts SET favorites = favorites + 1 WHERE id = {$postId}");
    $newFav = true;
}

$favorites = db()->query("SELECT favorites FROM posts WHERE id = {$postId}")->fetchColumn();
json_response(['favorited' => $newFav, 'favorites' => (int)$favorites]);
