<?php
/**
 * 关注贴吧接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$tiebaId = intval($_POST['tieba_id'] ?? 0);
if (!$tiebaId) json_response(null, 1, '参数错误');

$followed = is_followed($tiebaId);
if ($followed) {
    db()->prepare("DELETE FROM tieba_follows WHERE user_id = ? AND tieba_id = ?")->execute([$user['id'], $tiebaId]);
    db()->exec("UPDATE tiebas SET members = members - 1 WHERE id = {$tiebaId}");
    json_response(['following' => false]);
} else {
    db()->prepare("INSERT INTO tieba_follows (user_id, tieba_id, created_at) VALUES (?, ?, NOW())")->execute([$user['id'], $tiebaId]);
    db()->exec("UPDATE tiebas SET members = members + 1 WHERE id = {$tiebaId}");
    json_response(['following' => true]);
}
