<?php
/**
 * 关注用户接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$userId = intval($_POST['user_id'] ?? 0);
if (!$userId || $userId == $user['id']) json_response(null, 1, '参数错误');

$stmt = db()->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
$stmt->execute([$user['id'], $userId]);
$followed = (bool)$stmt->fetch();

if ($followed) {
    db()->prepare("DELETE FROM user_follows WHERE follower_id = ? AND following_id = ?")->execute([$user['id'], $userId]);
    db()->exec("UPDATE users SET following = following - 1 WHERE id = {$user['id']}");
    db()->exec("UPDATE users SET followers = followers - 1 WHERE id = {$userId}");
    json_response(['following' => false]);
} else {
    db()->prepare("INSERT INTO user_follows (follower_id, following_id, created_at) VALUES (?, ?, NOW())")->execute([$user['id'], $userId]);
    db()->exec("UPDATE users SET following = following + 1 WHERE id = {$user['id']}");
    db()->exec("UPDATE users SET followers = followers + 1 WHERE id = {$userId}");
    // 发送消息
    db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, created_at) VALUES (?, ?, 'follow', '关注了你', NOW())")
        ->execute([$user['id'], $userId]);
    json_response(['following' => true]);
}
