<?php
/**
 * 根据用户名获取头像
 */
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json; charset=utf-8');

$username = trim($_GET['username'] ?? '');
if (empty($username)) {
    echo json_encode(['code' => 1, 'msg' => '参数错误']);
    exit;
}

$stmt = db()->prepare("SELECT id, username, nickname, avatar FROM users WHERE username = ?");
$stmt->execute([$username]);
$u = $stmt->fetch();

if ($u) {
    echo json_encode([
        'code' => 0,
        'avatar' => avatar($u),
        'nickname' => $u['nickname'] ?: $u['username']
    ]);
} else {
    echo json_encode(['code' => 1, 'msg' => '用户不存在']);
}
