<?php
/**
 * 点赞接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
if (!$postId) json_response(null, 1, '参数错误');

// 私密帖：仅作者本人和管理员可点赞，其他用户（含伪造请求）一律拒绝
$chk = db()->prepare("SELECT user_id, visibility FROM posts WHERE id = ?");
$chk->execute([$postId]);
$postRow = $chk->fetch();
if (!$postRow) json_response(null, 1, '帖子不存在或已被删除');
if (($postRow['visibility'] ?? 'public') === 'private' && $postRow['user_id'] != $user['id'] && !in_array($user['role'], ['admin','super_admin'])) {
    json_response(null, 1, '无权操作该帖子');
}

$liked = is_liked($postId);
if ($liked) {
    db()->prepare("DELETE FROM post_likes WHERE user_id = ? AND post_id = ?")->execute([$user['id'], $postId]);
    db()->exec("UPDATE posts SET likes = likes - 1 WHERE id = {$postId}");
    $newLiked = false;
} else {
    db()->prepare("INSERT INTO post_likes (post_id, user_id, created_at) VALUES (?, ?, NOW())")->execute([$postId, $user['id']]);
    db()->exec("UPDATE posts SET likes = likes + 1 WHERE id = {$postId}");
    $newLiked = true;
    // 发送消息
    if ($postRow['user_id'] != $user['id']) {
        db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'like', ?, ?, NOW())")
            ->execute([$user['id'], $postRow['user_id'], '赞了你的帖子', $postId]);
    }
}

$likes = db()->query("SELECT likes FROM posts WHERE id = {$postId}")->fetchColumn();
json_response(['liked' => $newLiked, 'likes' => (int)$likes]);
