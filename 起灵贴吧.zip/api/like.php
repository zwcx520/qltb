<?php
/**
 * 点赞接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
if (!$postId) json_response(null, 1, '参数错误');

$liked = is_liked($postId);
if ($liked) {
    db()->prepare("DELETE FROM post_likes WHERE user_id = ? AND post_id = ?")->execute([$user['id'], $postId]);
    db()->exec("UPDATE posts SET likes = likes - 1 WHERE id = {$postId}");
    $newLiked = false;
} else {
    db()->prepare("INSERT INTO post_likes (post_id, user_id, created_at) VALUES (?, ?, NOW())")->execute([$postId, $user['id']]);
    db()->exec("UPDATE posts SET likes = likes + 1 WHERE id = {$postId}");
    $newLiked = true;
    // 发送消息
    $post = db()->query("SELECT user_id FROM posts WHERE id = {$postId}")->fetch();
    if ($post && $post['user_id'] != $user['id']) {
        db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'like', ?, ?, NOW())")
            ->execute([$user['id'], $post['user_id'], '赞了你的帖子', $postId]);
    }
}

$likes = db()->query("SELECT likes FROM posts WHERE id = {$postId}")->fetchColumn();
json_response(['liked' => $newLiked, 'likes' => (int)$likes]);
