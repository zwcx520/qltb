<?php
/**
 * 登出接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();
session_destroy();
json_response(['ok' => true]);
