<?php
/**
 * 登出接口
 * - 普通浏览器跳转（如后台退出）：可带安全的站内 redirect 参数，退出后直接跳转
 * - AJAX 请求：返回 JSON
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

// 仅允许站内文件名形式的跳转目标（如 admin.php），拒绝 URL/协议相对地址，防止开放重定向
$redirect = trim($_GET['redirect'] ?? '');
$safeRedirect = ($redirect !== '' && preg_match('/^[a-zA-Z0-9_\-]+\.php(\?[a-zA-Z0-9_\.\=&%\-]*)?$/', $redirect)) ? $redirect : '';

session_destroy();

if ($safeRedirect) {
    // 本接口位于 /api/ 目录，相对重定向会被浏览器解析成 /api/admin.php 导致404，
    // 因此基于站点根目录拼出绝对路径（兼容子目录部署，如 /起灵贴吧/admin.php）
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/api/logout.php');
    $rootBase = rtrim(dirname(dirname($scriptPath)), '/'); // /api/logout.php -> 站点根
    header('Location: ' . $rootBase . '/' . ltrim($safeRedirect, '/'));
    exit;
}

json_response(['ok' => true]);
