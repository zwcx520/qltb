/* ===== 起灵贴吧前端交互 ===== */

// 统一的 fetch 封装，确保携带 session cookie
function postApi(url, data) {
    const body = new URLSearchParams(data).toString();
    return fetch(url, {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        credentials: 'same-origin',
        body: body
    }).then(r => r.json());
}

// Toast提示
function toast(msg, duration = 2000) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), duration);
}

// 点赞
function likePost(postId, btn) {
    postApi('api/like.php', {post_id: postId})
    .then(d => {
        if (d.code === 0) {
            btn.classList.toggle('liked');
            const cnt = btn.querySelector('.count');
            cnt.textContent = d.data.likes;
            if (btn.classList.contains('liked')) btn.querySelector('i').className = 'fa fa-heart';
            else btn.querySelector('i').className = 'fa fa-heart-o';
        } else {
            toast(d.msg);
        }
    })
    .catch(() => toast('网络错误，请重试'));
}

// 关注贴吧
function followTieba(tiebaId, btn) {
    postApi('api/follow.php', {tieba_id: tiebaId})
    .then(d => {
        if (d.code === 0) {
            // 直接用后端返回的状态，不依赖 toggle
            const following = d.data.following;
            btn.className = 'btn ' + (following ? 'btn-ghost' : 'btn-primary');
            btn.innerHTML = following
                ? '<i class="fa fa-check"></i> 已关注'
                : '<i class="fa fa-plus"></i> 关注';
            // 触发切换动画
            btn.classList.remove('btn-pop');
            void btn.offsetWidth;
            btn.classList.add('btn-pop');
        } else toast(d.msg);
    })
    .catch(() => toast('网络错误，请重试'));
}

// 关注用户
function followUser(userId, btn) {
    postApi('api/follow_user.php', {user_id: userId})
    .then(d => {
        if (d.code === 0) {
            btn.textContent = d.data.following ? '已关注' : '关注';
            btn.className = d.data.following ? 'btn btn-ghost' : 'btn btn-primary';
            // 触发切换动画
            btn.classList.remove('btn-pop');
            void btn.offsetWidth;
            btn.classList.add('btn-pop');
        } else toast(d.msg);
    })
    .catch(() => toast('网络错误，请重试'));
}

// 收藏帖子
function favoritePost(postId, btn) {
    postApi('api/favorite.php', {post_id: postId})
    .then(d => {
        if (d.code === 0) {
            btn.classList.toggle('favorited');
            const cnt = btn.querySelector('.count');
            if (cnt) cnt.textContent = d.data.favorites;
            if (btn.classList.contains('favorited')) btn.querySelector('i').className = 'fa fa-bookmark';
            else btn.querySelector('i').className = 'fa fa-bookmark-o';
        } else toast(d.msg);
    })
    .catch(() => toast('网络错误，请重试'));
}

// 图片预览
function previewImage(src) {
    const mask = document.createElement('div');
    mask.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.9);z-index:2000;display:flex;align-items:center;justify-content:center;padding:20px;';
    mask.innerHTML = `<img src="${src}" style="max-width:100%;max-height:100%;border-radius:12px;">`;
    mask.onclick = () => mask.remove();
    document.body.appendChild(mask);
}

// 多图上传预览（支持删除单张、数量提示）
function setupImageUpload(inputId, previewId, max = 9) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    if (!input || !preview) return;
    const addBtn = preview.querySelector('.upload-add-btn');
    if (!addBtn) return;

    // 用数组保存已选文件（因为 FileList 不可变）
    let selectedFiles = [];

    // 计数提示
    let counter = preview.querySelector('.upload-count');
    if (!counter) {
        counter = document.createElement('div');
        counter.className = 'upload-count';
        counter.style.cssText = 'grid-column:1/-1;font-size:12px;color:var(--text-light);text-align:right;margin-bottom:4px;';
        preview.insertBefore(counter, addBtn);
    }

    function updateCount() {
        const count = selectedFiles.length;
        counter.textContent = `已选 ${count}/${max} 张`;
        addBtn.style.display = count >= max ? 'none' : 'flex';
    }

    function syncInput() {
        // 用 DataTransfer 重建 FileList
        const dt = new DataTransfer();
        selectedFiles.forEach(f => dt.items.add(f));
        input.files = dt.files;
    }

    function renderAll() {
        // 清除旧预览并释放旧 URL
        preview.querySelectorAll('.img-preview-item').forEach(el => {
            const img = el.querySelector('img');
            if (img && img.src.startsWith('blob:')) URL.revokeObjectURL(img.src);
            el.remove();
        });
        selectedFiles.forEach((f, idx) => {
            const url = URL.createObjectURL(f);
            const div = document.createElement('div');
            div.className = 'img-preview-item';
            div.dataset.idx = idx;
            div.style.cssText = 'position:relative;aspect-ratio:1;border-radius:12px;overflow:hidden;background:#f3e8ff;';
            div.innerHTML = `
                <img src="${url}" style="width:100%;height:100%;object-fit:cover;display:block;">
                <button type="button" class="img-del-btn" data-idx="${idx}" style="position:absolute;top:4px;right:4px;width:22px;height:22px;border-radius:50%;background:rgba(0,0,0,0.6);color:white;border:none;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;line-height:1;padding:0;">×</button>
            `;
            const delBtn = div.querySelector('.img-del-btn');
            delBtn.onclick = (ev) => {
                ev.preventDefault();
                ev.stopPropagation();
                const i = parseInt(delBtn.dataset.idx);
                URL.revokeObjectURL(url);
                selectedFiles.splice(i, 1);
                syncInput();
                renderAll();
                updateCount();
            };
            preview.insertBefore(div, addBtn);
        });
        updateCount();
    }

    input.addEventListener('change', () => {
        // 追加新文件，去重
        Array.from(input.files).forEach(f => {
            if (selectedFiles.length >= max) return;
            if (!selectedFiles.some(s => s.name === f.name && s.size === f.size && s.lastModified === f.lastModified)) {
                selectedFiles.push(f);
            }
        });
        syncInput();
        renderAll();
    });

    updateCount();
}

// 时间格式化
function timeAgo(t) {
    const d = new Date(t.replace(/-/g,'/'));
    const diff = (Date.now() - d.getTime()) / 1000;
    if (diff < 60) return '刚刚';
    if (diff < 3600) return Math.floor(diff/60) + '分钟前';
    if (diff < 86400) return Math.floor(diff/3600) + '小时前';
    return d.toLocaleDateString();
}

// 评论提交
function submitComment(postId) {
    const input = document.getElementById('comment-input');
    const content = input.value.trim();
    if (!content) { toast('说点什么吧~'); return; }
    postApi('api/comment.php', {post_id: postId, content: content})
    .then(d => {
        if (d.code === 0) {
            location.reload();
        } else toast(d.msg);
    })
    .catch(() => toast('网络错误，请重试'));
}

// 退出登录
function logout() {
    if (confirm('确定要退出登录吗？')) {
        fetch('api/logout.php', {credentials: 'same-origin'}).then(() => location.href = 'index.php');
    }
}

// 删除帖子
function deletePost(postId, redirectUrl) {
    if (!confirm('确定要删除这条帖子吗？删除后图片、视频和评论将一并清除，且不可恢复。')) return;
    postApi('api/delete_post.php', {post_id: postId})
    .then(d => {
        if (d.code === 0) {
            toast('删除成功');
            setTimeout(() => {
                location.href = redirectUrl || 'index.php';
            }, 600);
        } else {
            toast(d.msg);
        }
    })
    .catch(() => toast('网络错误，请重试'));
}

// 视频播放控制
document.addEventListener('click', e => {
    if (e.target.closest('.video-play')) {
        const v = e.target.closest('.post-video').querySelector('video');
        v.play();
        e.target.closest('.video-play').style.display = 'none';
        v.controls = true;
    }
});
