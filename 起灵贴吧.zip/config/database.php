<?php
/**
 * 数据库配置文件
 * 安装时会自动写入此文件
 */

return [
    'host'     => '127.0.0.1',
    'port'     => '3306',
    'dbname'   => 'qiling_tieba',
    'username' => 'root',
    'password' => '',
    'charset'  => 'utf8mb4',
];
