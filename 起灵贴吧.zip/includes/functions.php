<?php
/**
 * 公共函数库
 */

// 防止直接访问
defined('IN_APP') || define('IN_APP', true);

/**
 * 获取数据库连接
 */
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $config = require __DIR__ . '/../config/database.php';
        $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['dbname']};charset={$config['charset']}";
        try {
            $pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('数据库连接失败: ' . $e->getMessage());
        }
    }
    return $pdo;
}

/**
 * 检查系统是否已安装
 */
function is_installed() {
    return file_exists(__DIR__ . '/../config/installed.lock');
}

/**
 * 安全输出
 */
function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * 启动会话（确保 cookie 在整个站点共享）
 */
function start_session() {
    if (session_status() === PHP_SESSION_NONE) {
        // 设置 session cookie 参数，确保整个站点共享
        $params = session_get_cookie_params();
        session_set_cookie_params([
            'lifetime' => $params['lifetime'] ?: 86400 * 7, // 7天
            'path'     => '/',
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

/**
 * 获取当前登录用户
 */
function current_user() {
    start_session();
    if (empty($_SESSION['uid'])) return null;
    $stmt = db()->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['uid']]);
    return $stmt->fetch() ?: null;
}

/**
 * 检查是否为管理员（含站长）
 */
function is_admin() {
    $u = current_user();
    return $u && ($u['role'] === 'admin' || $u['role'] === 'super_admin');
}

/**
 * 检查是否为站长（超级管理员）
 */
function is_super_admin() {
    $u = current_user();
    return $u && $u['role'] === 'super_admin';
}

/**
 * 计算普通用户成长等级（1~100）
 * 每发 20 帖升 1 级，到 100 级（2000 帖）自动升级为管理员
 */
function user_level($user) {
    if (!$user || $user['role'] !== 'user') return 0;
    return min(100, floor(intval($user['posts']) / 20)) + 1;
}

/**
 * 用户标签 HTML（站长/管理员/Lv.x）
 */
function user_label($user) {
    if (!$user) return '';
    if ($user['role'] === 'super_admin') {
        return '<span class="ulabel ulabel-super"><i class="fa fa-star"></i> 站长</span>';
    }
    if ($user['role'] === 'admin') {
        return '<span class="ulabel ulabel-admin"><i class="fa fa-shield"></i> 管理员</span>';
    }
    return '<span class="ulabel ulabel-user">Lv.' . user_level($user) . '</span>';
}

/**
 * 发布帖子后检查是否达到 100 级，自动升级为管理员
 */
function check_level_up($userId) {
    $stmt = db()->prepare("SELECT posts, role FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if (!$row) return;
    if ($row['role'] === 'user' && intval($row['posts']) >= 2000) {
        db()->exec("UPDATE users SET role='admin' WHERE id=" . intval($userId));
    }
}

/**
 * 生成随机字符串
 */
function str_random($len = 32) {
    return bin2hex(random_bytes($len / 2));
}

/**
 * 密码哈希
 */
function hash_password($pwd) {
    return password_hash($pwd, PASSWORD_DEFAULT);
}

/**
 * 密码验证
 */
function verify_password($pwd, $hash) {
    return password_verify($pwd, $hash);
}

/**
 * JSON响应
 */
function json_response($data, $code = 0, $msg = 'ok') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 格式化时间
 */
function time_ago($time) {
    $t = is_string($time) ? strtotime($time) : $time;
    $diff = time() - $t;
    if ($diff < 60) return '刚刚';
    if ($diff < 3600) return floor($diff / 60) . '分钟前';
    if ($diff < 86400) return floor($diff / 3600) . '小时前';
    if ($diff < 604800) return floor($diff / 86400) . '天前';
    return date('Y-m-d', $t);
}

/**
 * 处理图片/视频上传
 */
function handle_upload($file, $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'], $maxSize = 10485760) {
    // 检查文件是否上传
    if (!isset($file) || !is_array($file)) {
        return ['ok' => false, 'msg' => '未选择文件'];
    }
    // 检查上传错误
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE   => '文件超过服务器限制(' . ini_get('upload_max_filesize') . ')',
            UPLOAD_ERR_FORM_SIZE  => '文件超过表单限制',
            UPLOAD_ERR_PARTIAL    => '文件上传不完整',
            UPLOAD_ERR_NO_FILE    => '未选择文件',
            UPLOAD_ERR_NO_TMP_DIR => '服务器临时目录不存在',
            UPLOAD_ERR_CANT_WRITE => '服务器写入失败',
            UPLOAD_ERR_EXTENSION  => '上传被扩展阻止',
        ];
        $msg = $errors[$file['error']] ?? '上传失败(错误码:' . $file['error'] . ')';
        return ['ok' => false, 'msg' => $msg];
    }
    // 检查大小
    if ($file['size'] > $maxSize) {
        return ['ok' => false, 'msg' => '文件过大，最大允许 ' . round($maxSize/1048576, 1) . 'MB'];
    }
    if ($file['size'] === 0) {
        return ['ok' => false, 'msg' => '文件为空'];
    }
    // 检查扩展名
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        return ['ok' => false, 'msg' => '不支持的文件类型: ' . $ext . '（支持: ' . implode(',', $allowed) . '）'];
    }
    // 检查临时文件
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'msg' => '非法上传'];
    }
    // 创建上传目录
    $uploadRoot = __DIR__ . '/../assets/uploads';
    if (!is_dir($uploadRoot)) {
        if (!mkdir($uploadRoot, 0777, true)) {
            return ['ok' => false, 'msg' => '上传目录创建失败，请检查 assets/uploads 权限'];
        }
    }
    $dir = $uploadRoot . '/' . date('Ym');
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0777, true)) {
            return ['ok' => false, 'msg' => '月份目录创建失败'];
        }
    }
    // 生成文件名
    $name = date('YmdHis') . '_' . substr(md5(uniqid(mt_rand(), true)), 0, 10) . '.' . $ext;
    $path = $dir . '/' . $name;
    if (move_uploaded_file($file['tmp_name'], $path)) {
        // 修正路径分隔符为正斜杠
        $url = 'assets/uploads/' . date('Ym') . '/' . $name;
        return ['ok' => true, 'url' => $url];
    }
    return ['ok' => false, 'msg' => '文件保存失败，请检查目录写入权限'];
}

/**
 * 删除已上传的文件（支持相对路径 assets/uploads/...）
 */
function delete_uploaded_file($url) {
    if (empty($url)) return;
    // data URI 或 外部URL 不处理
    if (strpos($url, 'data:') === 0) return;
    if (preg_match('/^https?:\/\//i', $url)) return;
    // 相对路径转绝对路径
    $path = __DIR__ . '/../' . ltrim($url, '/');
    if (is_file($path)) {
        @unlink($path);
    }
}

/**
 * 检查PHP上传配置
 */
function upload_check() {
    return [
        'file_uploads'      => ini_get('file_uploads'),
        'upload_max_filesize' => ini_get('upload_max_filesize'),
        'post_max_size'     => ini_get('post_max_size'),
        'max_file_uploads'  => ini_get('max_file_uploads'),
    ];
}

/**
 * 获取用户头像
 */
function avatar($user) {
    if (!empty($user['avatar'])) {
        // 如果是上传的图片，确保路径正确
        $av = $user['avatar'];
        // 如果是 data URI 直接返回
        if (strpos($av, 'data:') === 0) return $av;
        // 如果是绝对URL直接返回
        if (preg_match('/^https?:\/\//i', $av)) return $av;
        // 相对路径补全
        return $av;
    }
    $color = ['#FFB6C1', '#B39DDB', '#81D4FA', '#A5D6A7', '#FFCC80', '#CE93D8', '#F48FB1', '#90CAF9'];
    $c = $color[($user['id'] ?? 0) % count($color)];
    $name = mb_substr($user['nickname'] ?? ($user['username'] ?? 'U'), 0, 1);
    $svg = "<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='80' height='80' rx='40' fill='{$c}'/><text x='40' y='54' font-size='36' fill='white' text-anchor='middle' dominant-baseline='middle' font-family='sans-serif'>{$name}</text></svg>";
    return "data:image/svg+xml;base64," . base64_encode($svg);
}

/**
 * 获取贴吧封面
 */
function cover($tieba) {
    // 有封面图片则使用图片
    if (!empty($tieba['cover']) && strpos($tieba['cover'], 'assets/uploads') === 0) {
        return "url('" . e($tieba['cover']) . "') center/cover no-repeat";
    }
    // 否则使用渐变色
    $colors = [
        'linear-gradient(135deg,#a18cd1 0%,#fbc2eb 100%)',
        'linear-gradient(135deg,#fad0c4 0%,#ffd1ff 100%)',
        'linear-gradient(135deg,#ffecd2 0%,#fcb69f 100%)',
        'linear-gradient(135deg,#a1c4fd 0%,#c2e9fb 100%)',
        'linear-gradient(135deg,#d4fc79 0%,#96e6a1 100%)',
        'linear-gradient(135deg,#fddb92 0%,#d1fdff 100%)',
    ];
    return $colors[($tieba['id'] ?? 0) % count($colors)];
}

/**
 * 分页
 */
function paginate($total, $page, $perPage = 20) {
    return [
        'total'     => (int)$total,
        'page'      => (int)$page,
        'perPage'   => (int)$perPage,
        'totalPage' => (int)ceil($total / $perPage),
    ];
}

/**
 * 获取请求IP
 */
function client_ip() {
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

/**
 * 检查用户是否关注贴吧
 */
function is_followed($tiebaId) {
    $u = current_user();
    if (!$u) return false;
    $stmt = db()->prepare("SELECT 1 FROM tieba_follows WHERE user_id = ? AND tieba_id = ?");
    $stmt->execute([$u['id'], $tiebaId]);
    return (bool)$stmt->fetch();
}

/**
 * 检查用户是否点赞
 */
function is_liked($postId) {
    $u = current_user();
    if (!$u) return false;
    $stmt = db()->prepare("SELECT 1 FROM post_likes WHERE user_id = ? AND post_id = ?");
    $stmt->execute([$u['id'], $postId]);
    return (bool)$stmt->fetch();
}

/**
 * 检查用户是否收藏
 */
function is_favorited($postId) {
    $u = current_user();
    if (!$u) return false;
    $stmt = db()->prepare("SELECT 1 FROM post_favorites WHERE user_id = ? AND post_id = ?");
    $stmt->execute([$u['id'], $postId]);
    return (bool)$stmt->fetch();
}

/**
 * 获取可选图标列表（Font Awesome 4.7，带中文标签）
 */
function icon_list() {
    return [
        'tree' => '🌳 大树',
        'leaf' => '🍃 树叶',
        'pagelines' => '🌱 嫩芽',
        'envira' => '🌿 草本',
        'flower' => '� 花朵',
        'heart' => '❤️ 爱心',
        'heart-o' => '🤍 空心爱',
        'star' => '⭐ 星星',
        'star-o' => '☆ 空心星',
        'sun' => '☀️ 太阳',
        'moon' => '🌙 月亮',
        'cloud' => '☁️ 云朵',
        'snowflake' => '❄️ 雪花',
        'tint' => '💧 水滴',
        'fire' => '🔥 火焰',
        'coffee' => '☕ 咖啡',
        'glass' => '🍸 酒杯',
        'cutlery' => '🍴 餐具',
        'lemon-o' => '🍋 柠檬',
        'apple' => '🍎 苹果',
        'gift' => '🎁 礼物',
        'birthday-cake' => '� 蛋糕',
        'music' => '🎵 音符',
        'headphones' => '🎧 耳机',
        'microphone' => '� 麦克风',
        'radio' => '� 收音机',
        'film' => '🎞️ 胶片',
        'video-camera' => '📹 摄像机',
        'camera' => '📷 相机',
        'image' => '🖼️ 图片',
        'book' => '� 书本',
        'pencil' => '✏️ 铅笔',
        'bookmark' => '� 书签',
        'tag' => '�️ 标签',
        'flag' => '🚩 旗帜',
        'map-marker' => '📍 位置',
        'globe' => '🌍 地球',
        'compass' => '🧭 指南针',
        'map' => '🗺️ 地图',
        'location-arrow' => '➤ 定位',
        'home' => '🏠 房子',
        'building' => '🏢 大楼',
        'university' => '🎓 大学',
        'graduation-cap' => '🎓 学士帽',
        'briefcase' => '💼 公文包',
        'shopping-cart' => '� 购物车',
        'shopping-bag' => '�️ 购物袋',
        'credit-card' => '� 信用卡',
        'money' => '� 钱',
        'dollar' => '� 美元',
        'cny' => '� 人民币',
        'crown' => '� 皇冠',
        'trophy' => '🏆 奖杯',
        'diamond' => '� 钻石',
        'bell' => '� 铃铛',
        'bell-o' => '� 空铃',
        'envelope' => '✉️ 信封',
        'paper-plane' => '✈️ 纸飞机',
        'inbox' => '📥 收件箱',
        'comments' => '💬 多评论',
        'comment' => '💭 评论',
        'commenting' => '🗨️ 讨论',
        'smile' => '😊 微笑',
        'frown' => '☹️ 难过',
        'meh' => '😐 无感',
        'user' => '� 用户',
        'users' => '� 多人',
        'user-plus' => '➕ 添加用户',
        'user-circle' => '⭕ 用户圈',
        'male' => '👨 男',
        'female' => '👩 女',
        'child' => '🧒 小孩',
        'baby' => '� 婴儿',
        'paw' => '� 爪印',
        'bug' => '🐛 虫子',
        'fish' => '� 鱼',
        'futbol-o' => '⚽ 足球',
        'bicycle' => '🚲 自行车',
        'motorcycle' => '�️ 摩托车',
        'car' => '� 汽车',
        'taxi' => '� 出租车',
        'bus' => '🚌 公交',
        'truck' => '� 卡车',
        'train' => '� 火车',
        'subway' => '🚇 地铁',
        'ship' => '🚢 轮船',
        'plane' => '✈️ 飞机',
        'rocket' => '🚀 火箭',
        'space-shuttle' => '🚀 航天飞机',
        'anchor' => '⚓ 锚',
        'life-ring' => '🛟 救生圈',
        'wheelchair' => '♿ 轮椅',
        'mobile' => '� 手机',
        'laptop' => '� 笔记本',
        'tablet' => '� 平板',
        'television' => '📺 电视',
        'keyboard' => '⌨️ 键盘',
        'mouse-pointer' => '�️ 鼠标',
        'hdd' => '💾 硬盘',
        'database' => '�️ 数据库',
        'server' => '🖥️ 服务器',
        'wifi' => '📶 无线',
        'signal' => '📶 信号',
        'battery-full' => '� 满电',
        'plug' => '� 插头',
        'lightbulb-o' => '💡 灯泡',
        'lock' => '� 锁',
        'unlock' => '� 解锁',
        'key' => '� 钥匙',
        'shield' => '�️ 盾牌',
        'eye' => '�️ 眼睛',
        'eye-slash' => '� 闭眼',
        'search' => '🔍 搜索',
        'filter' => '🔬 过滤',
        'sort' => '� 排序',
        'check' => '✅ 对勾',
        'check-circle' => '✅ 圆对勾',
        'check-circle-o' => '⭕ 空对勾',
        'times' => '❌ 叉号',
        'times-circle' => '❌ 圆叉',
        'plus' => '➕ 加号',
        'plus-circle' => '➕ 圆加',
        'minus' => '➖ 减号',
        'minus-circle' => '➖ 圆减',
        'edit' => '✏️ 编辑',
        'pencil-square' => '📝 编辑',
        'save' => '💾 保存',
        'floppy-o' => '💾 软盘',
        'folder' => '📁 文件夹',
        'folder-open' => '📂 打开',
        'file' => '📄 文件',
        'file-text' => '📄 文本',
        'file-image-o' => '🖼️ 图片',
        'file-video-o' => '🎥 视频',
        'file-audio-o' => '🎵 音频',
        'file-code-o' => '💻 代码',
        'file-archive-o' => '📦 压缩',
        'trash' => '�️ 垃圾桶',
        'trash-o' => '�️ 空垃圾桶',
        'recycle' => '♻️ 回收',
        'eraser' => '🧽 橡皮',
        'paint-brush' => '🖌️ 画笔',
        'magic' => '✨ 魔法',
        'wrench' => '� 扳手',
        'cogs' => '⚙️ 多齿轮',
        'cog' => '⚙️ 齿轮',
        'sliders' => '🎚️ 滑块',
        'tachometer' => '📊 仪表盘',
        'bar-chart' => '📊 柱状图',
        'pie-chart' => '🥧 饼图',
        'line-chart' => '📈 折线图',
        'calendar' => '� 日历',
        'clock-o' => '� 时钟',
        'hourglass' => '⏳ 沙漏',
        'stopwatch' => '⏱️ 秒表',
        'volume-up' => '� 音量大',
        'volume-down' => '� 音量小',
        'volume-off' => '� 静音',
        'pause' => '⏸️ 暂停',
        'play' => '▶️ 播放',
        'stop' => '⏹️ 停止',
        'fast-forward' => '⏩ 快进',
        'fast-backward' => '⏪ 快退',
        'step-forward' => '⏭️ 下一首',
        'step-backward' => '⏮️ 上一首',
        'random' => '� 随机',
        'repeat' => '� 重复',
        'eject' => '⏏️ 弹出',
        'rss' => '📡 订阅',
        'hashtag' => '# 话题',
        'at' => '@ 艾特',
        'share-alt' => '🔄 分享',
        'retweet' => '🔁 转发',
        'thumbs-o-up' => '� 点赞',
        'thumbs-o-down' => '� 踩',
        'thumbs-up' => '� 赞',
        'thumbs-down' => '� 踩',
        'hand-peace' => '✌️ 和平',
        'hand-rock' => '🤘 摇滚',
        'hand-pointer' => '� 指',
        'hand-paper' => '✋ 手掌',
        'hand-scissors' => '✌️ 剪刀',
        'arrow-up' => '⬆️ 上',
        'arrow-down' => '⬇️ 下',
        'arrow-left' => '⬅️ 左',
        'arrow-right' => '➡️ 右',
        'angle-up' => '▲ 上',
        'angle-down' => '▼ 下',
        'angle-left' => '◀ 左',
        'angle-right' => '▶ 右',
        'chevron-up' => '⌃ 向上',
        'chevron-down' => '⌄ 向下',
        'chevron-left' => '‹ 向左',
        'chevron-right' => '› 向右',
        'caret-up' => '▲ 上三角',
        'caret-down' => '▼ 下三角',
        'caret-left' => '◀ 左三角',
        'caret-right' => '▶ 右三角',
        'external-link' => '↗️ 外链',
        'link' => '🔗 链接',
        'unlink' => '🔓 断开',
        'paperclip' => '📎 回形针',
        'thumb-tack' => '📌 图钉',
        'sticky-note' => '📝 便利贴',
        'clipboard' => '📋 剪贴板',
        'android' => '🤖 安卓',
        'apple' => '🍎 苹果',
        'windows' => '🪟 窗口',
        'linux' => '🐧 企鹅',
        'chrome' => '🌐 Chrome',
        'firefox' => '🦊 火狐',
        'github' => '🐙 GitHub',
        'git' => '📚 Git',
        'html5' => '🟧 HTML5',
        'css3' => '🟦 CSS3',
        'js' => '🟨 JS',
        'php' => '🐘 PHP',
        'python' => '🐍 Python',
        'java' => '☕ Java',
        'node' => '🟢 Node',
        'react' => '⚛️ React',
        'vue' => '💚 Vue',
        'bitcoin' => '₿ 比特币',
        'steam' => '� Steam',
        'spotify' => '🎵 Spotify',
        'soundcloud' => '🎵 声云',
        'youtube' => '▶️ YouTube',
        'twitch' => '🎮 Twitch',
        'weibo' => '📱 微博',
        'wechat' => '� 微信',
        'qq' => '� QQ',
    ];
}

/**
 * 渲染图标下拉选择框（带预览）
 */
function icon_select($name, $selected = '', $id = '') {
    $id = $id ?: $name;
    $list = icon_list();
    $selected = $selected ?: 'tree';
    $html = '<div class="icon-select-wrap">';
    $html .= '<span class="icon-preview" id="preview-'.$id.'"><i class="fa fa-'.e($selected).'"></i></span>';
    $html .= "<select name=\"{$name}\" id=\"{$id}\" class=\"form-select icon-select\" onchange=\"document.getElementById('preview-{$id}').firstChild.className='fa fa-'+this.value;\">";
    foreach ($list as $val => $label) {
        $sel = $selected === $val ? ' selected' : '';
        $html .= "<option value=\"{$val}\"{$sel}>{$label}</option>";
    }
    $html .= '</select>';
    $html .= '</div>';
    return $html;
}

