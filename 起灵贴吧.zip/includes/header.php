<?php
/**
 * 公共头部
 */
$pageTitle = $pageTitle ?? '起灵贴吧';
$showSearch = $showSearch ?? true;
$currentPage = $currentPage ?? 'home';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= e($pageTitle) ?> - <?= e($settings['site_name']) ?></title>
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/v4-shims.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css?v=<?= @filemtime(__DIR__ . '/../assets/css/style.css') ?: '1' ?>">
    <script src="assets/js/app.js?v=<?= @filemtime(__DIR__ . '/../assets/js/app.js') ?: '1' ?>"></script>
</head>
<body class="<?= $bodyClass ?? '' ?>">
<!-- 漂浮装饰 -->
<div class="floating-leaf" style="left:5%; animation-delay:0s;">🍃</div>
<div class="floating-leaf" style="left:85%; animation-delay:3s;">🌸</div>
<div class="floating-leaf" style="left:45%; animation-delay:6s;">✨</div>
