<?php
/**
 * 起灵贴吧 - 前台入口 (SPA单页程序)
 */
define('IN_APP', true);
require __DIR__ . '/includes/functions.php';

// 未安装则跳转安装
if (!is_installed()) {
    header('Location: install.php');
    exit;
}

start_session();
$user = current_user();

// 确保上传目录可写
$uploadDir = __DIR__ . '/assets/uploads';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0777, true);
}

// 获取设置
$settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch() ?: ['site_name' => '起灵贴吧', 'site_desc' => '温暖的情绪树洞'];

// 自动创建收藏表（兼容已安装系统）
db()->exec("CREATE TABLE IF NOT EXISTS post_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME,
    UNIQUE KEY uniq_fav (post_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 确保 posts 表有 favorites 字段
try {
    db()->exec("ALTER TABLE posts ADD COLUMN favorites INT NOT NULL DEFAULT 0");
} catch (Exception $e) { /* 字段已存在，忽略 */ }

// 自动迁移：用户隐私字段 + 贴吧吧主字段（兼容已安装系统）
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_posts ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_following ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_followers ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_tiebas ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE tiebas ADD COLUMN owner_id INT UNSIGNED NOT NULL DEFAULT 0"); } catch (Exception $e) {}
// 公告字段
try { db()->exec("ALTER TABLE settings ADD COLUMN announcement TEXT"); } catch (Exception $e) {}
// 首页Banner背景图
try { db()->exec("ALTER TABLE settings ADD COLUMN banner_image VARCHAR(255) DEFAULT ''"); } catch (Exception $e) {}
// 联系站长消息类型
try { db()->exec("ALTER TABLE messages MODIFY COLUMN type ENUM('like','comment','follow','system','chat','contact') DEFAULT 'system'"); } catch (Exception $e) {}

// 路由参数
$page = $_GET['page'] ?? 'home';
$id   = $_GET['id'] ?? 0;
$act  = $_GET['act'] ?? '';

// 引入页面
$allowed = ['home','discover','publish','message','profile','tieba','post','search','login','register','user','edit','privacy','contact','contact_chat','about','rules'];
if (!in_array($page, $allowed)) $page = 'home';

// 需要登录的页面
$needLogin = ['publish','message','edit','privacy'];
if (in_array($page, $needLogin) && !$user) {
    header('Location: index.php?page=login');
    exit;
}

include __DIR__ . '/pages/' . $page . '.php';
