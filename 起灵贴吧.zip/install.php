<?php
/**
 * 系统安装程序
 * 填写数据库地址、管理员信息，自动创建数据表
 */
define('IN_APP', true);
require __DIR__ . '/includes/functions.php';

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

if (is_installed()) {
    die('系统已安装，如需重装请删除 config/installed.lock 文件');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost    = trim($_POST['db_host'] ?? '127.0.0.1');
    $dbPort    = trim($_POST['db_port'] ?? '3306');
    $dbName    = trim($_POST['db_name'] ?? 'qiling_tieba');
    $dbUser    = trim($_POST['db_user'] ?? 'root');
    $dbPass    = $_POST['db_pass'] ?? '';
    $adminUser = trim($_POST['admin_user'] ?? 'admin');
    $adminPass = $_POST['admin_pass'] ?? 'admin123';
    $adminMail = trim($_POST['admin_mail'] ?? 'admin@qiling.com');
    $siteName  = trim($_POST['site_name'] ?? '起灵贴吧');

    try {
        // 测试连接并创建数据库
        $pdo = new PDO("mysql:host={$dbHost};port={$dbPort}", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$dbName}`");

        // 写入配置文件
        $configContent = "<?php\nreturn [\n    'host'     => '{$dbHost}',\n    'port'     => '{$dbPort}',\n    'dbname'   => '{$dbName}',\n    'username' => '{$dbUser}',\n    'password' => '" . addslashes($dbPass) . "',\n    'charset'  => 'utf8mb4',\n];\n";
        file_put_contents(__DIR__ . '/config/database.php', $configContent);

        // 执行建表SQL
        $sql = file_get_contents(__DIR__ . '/sql/install.sql');
        $pdo->exec($sql);

        // 创建管理员
        $hash = hash_password($adminPass);
        $stmt = $pdo->prepare("INSERT INTO users (username, password, nickname, email, role, avatar, created_at) VALUES (?, ?, ?, ?, 'admin', '', NOW())");
        $stmt->execute([$adminUser, $hash, '管理员', $adminMail]);

        // 写入站点配置
        $stmt = $pdo->prepare("INSERT INTO settings (site_name, site_desc, site_keywords) VALUES (?, ?, ?)");
        $stmt->execute([$siteName, '一个温暖的情绪树洞社区', '贴吧,树洞,情绪,分享']);

        // 创建默认贴吧
        $defaultTiebas = [
            ['心情树洞', '在这里倾诉你的喜怒哀乐', 'tree'],
            ['深夜电台', '夜深了，说说话吧', 'radio'],
            ['治愈系', '分享温暖治愈的瞬间', 'heart'],
            ['日常碎片', '记录生活中的小美好', 'sun'],
            ['情绪宣泄', '把不开心都倒出来', 'fire'],
            ['温柔时光', '珍藏每一份温柔', 'flower'],
        ];
        $stmt = $pdo->prepare("INSERT INTO tiebas (name, description, icon, members, posts, created_at) VALUES (?, ?, ?, 0, 0, NOW())");
        foreach ($defaultTiebas as $t) {
            $stmt->execute($t);
        }

        // 标记已安装
        file_put_contents(__DIR__ . '/config/installed.lock', date('Y-m-d H:i:s'));

        $success = '安装成功！';
    } catch (Exception $e) {
        $error = '安装失败: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装 - 起灵贴吧</title>
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.5.1/css/v4-shims.min.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background: linear-gradient(135deg, #fdf2f8 0%, #f3e8ff 50%, #e0f2fe 100%);
            min-height: 100vh;
            font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .install-card {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.75);
            border: 1px solid rgba(255, 255, 255, 0.8);
            border-radius: 24px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            width: 100%;
            max-width: 480px;
            padding: 32px;
        }
        .text-center { text-align: center; }
        .logo-circle {
            width: 80px; height: 80px;
            margin: 0 auto;
            border-radius: 50%;
            background: linear-gradient(135deg, #f472b6, #a855f7);
            display: flex; align-items: center; justify-content: center;
            box-shadow: 0 10px 30px rgba(236,72,153,0.3);
        }
        .floating { animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        h1.title {
            font-size: 24px; font-weight: bold;
            background: linear-gradient(135deg, #ec4899, #9333ea);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 16px;
        }
        .subtitle { color: #6b7280; font-size: 14px; margin-top: 4px; }
        .mb-8 { margin-bottom: 32px; }
        .mb-6 { margin-bottom: 24px; }
        .mb-4 { margin-bottom: 16px; }
        .mb-3 { margin-bottom: 12px; }
        .mb-1 { margin-bottom: 4px; }
        .mt-1 { margin-top: 4px; }
        .mt-2 { margin-top: 8px; }
        .mt-4 { margin-top: 16px; }
        .mt-6 { margin-top: 24px; }
        .error-box {
            background: #fef2f2; border: 1px solid #fecaca;
            color: #dc2626; padding: 12px 16px;
            border-radius: 16px; font-size: 14px;
            margin-bottom: 16px; display: flex; align-items: center;
        }
        .success-icon {
            width: 80px; height: 80px; margin: 0 auto;
            border-radius: 50%; background: #d1fae5;
            display: flex; align-items: center; justify-content: center;
            color: #10b981; font-size: 36px;
        }
        h2.success-title { font-size: 20px; font-weight: bold; color: #1f2937; margin-top: 16px; }
        .success-desc { color: #6b7280; margin-top: 8px; }
        .btn-group { margin-top: 24px; display: flex; flex-direction: column; gap: 12px; }
        .btn-primary {
            display: block; width: 100%;
            padding: 12px; border-radius: 16px;
            background: linear-gradient(135deg, #ec4899, #a855f7);
            color: white; font-weight: 600; text-align: center;
            text-decoration: none; border: none; cursor: pointer;
            transition: all .3s; font-size: 15px;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(236,72,153,0.3); }
        .btn-secondary {
            display: block; width: 100%;
            padding: 12px; border-radius: 16px;
            background: white; border: 1px solid #e9d5ff;
            color: #9333ea; font-weight: 600; text-align: center;
            text-decoration: none; transition: all .3s;
        }
        .btn-secondary:hover { background: #faf5ff; }
        .steps { display: flex; align-items: center; margin-bottom: 24px; padding: 0 16px; }
        .step-dot {
            width: 32px; height: 32px; border-radius: 50%;
            background: #e5e7eb; color: #6b7280;
            display: flex; align-items: center; justify-content: center;
            font-size: 14px; font-weight: bold;
            transition: all .3s;
        }
        .step-dot.active {
            background: linear-gradient(135deg, #ec4899, #a855f7);
            color: white; transform: scale(1.1);
        }
        .step-dot.done { background: #10b981; color: white; }
        .step-line { flex: 1; height: 2px; background: #e5e7eb; margin: 0 8px; }
        .form-section {
            border-radius: 16px; padding: 16px; margin-bottom: 16px;
        }
        .section-db { background: rgba(243, 232, 255, 0.5); }
        .section-user { background: rgba(253, 242, 248, 0.5); }
        .section-title { font-weight: 600; margin-bottom: 12px; display: flex; align-items: center; }
        .section-title.db { color: #7c3aed; }
        .section-title.user { color: #db2777; }
        .section-title i { margin-right: 8px; }
        .field-group { display: flex; flex-direction: column; gap: 12px; }
        .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .field label {
            display: block; font-size: 12px; color: #6b7280;
            margin-bottom: 4px;
        }
        .input-field {
            width: 100%; padding: 10px 16px;
            border-radius: 12px; border: 1px solid #e5e7eb;
            outline: none; font-size: 14px;
            background: rgba(255,255,255,0.6);
            transition: all .3s;
        }
        .input-field:focus {
            background: white;
            box-shadow: 0 0 0 3px rgba(236, 72, 153, 0.15);
            border-color: #ec4899;
        }
        .footer-text { text-align: center; font-size: 12px; color: #9ca3af; margin-top: 24px; }
        .text-white { color: #fff; }
        .text-3xl { font-size: 30px; }
        .text-4xl { font-size: 36px; }
        .mr-2 { margin-right: 8px; }
    </style>
</head>
<body>
    <div class="install-card">
        <div class="text-center mb-8">
            <div class="logo-circle floating">
                <i class="fa fa-tree text-white text-3xl"></i>
            </div>
            <h1 class="title">起灵贴吧</h1>
            <p class="subtitle">一个温暖的情绪树洞 · 安装向导</p>
        </div>

        <?php if ($error): ?>
            <div class="error-box">
                <i class="fa fa-exclamation-circle mr-2"></i><?= e($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="text-center" style="padding:32px 0;">
                <div class="success-icon">
                    <i class="fa fa-check"></i>
                </div>
                <h2 class="success-title">安装成功！</h2>
                <p class="success-desc">欢迎来到起灵贴吧，开始你的树洞之旅吧 ~</p>
                <div class="btn-group">
                    <a href="index.php" class="btn-primary">
                        <i class="fa fa-home mr-2"></i>进入首页
                    </a>
                    <a href="admin.php" class="btn-secondary">
                        <i class="fa fa-cog mr-2"></i>管理后台
                    </a>
                </div>
            </div>
        <?php else: ?>
            <form method="post">
                <div class="steps">
                    <div class="step-dot done"><i class="fa fa-check" style="font-size:12px;"></i></div>
                    <div class="step-line"></div>
                    <div class="step-dot active">2</div>
                    <div class="step-line"></div>
                    <div class="step-dot">3</div>
                </div>

                <div class="form-section section-db">
                    <h3 class="section-title db"><i class="fa fa-database"></i>数据库配置</h3>
                    <div class="field-group">
                        <div class="field">
                            <label>数据库地址</label>
                            <input name="db_host" value="127.0.0.1" class="input-field">
                        </div>
                        <div class="field-row">
                            <div class="field">
                                <label>端口</label>
                                <input name="db_port" value="3306" class="input-field">
                            </div>
                            <div class="field">
                                <label>数据库名</label>
                                <input name="db_name" value="qiling_tieba" class="input-field">
                            </div>
                        </div>
                        <div class="field">
                            <label>用户名</label>
                            <input name="db_user" value="root" class="input-field">
                        </div>
                        <div class="field">
                            <label>密码</label>
                            <input name="db_pass" type="password" class="input-field">
                        </div>
                    </div>
                </div>

                <div class="form-section section-user">
                    <h3 class="section-title user"><i class="fa fa-user-circle"></i>管理员与站点</h3>
                    <div class="field-group">
                        <div class="field">
                            <label>站点名称</label>
                            <input name="site_name" value="起灵贴吧" class="input-field">
                        </div>
                        <div class="field-row">
                            <div class="field">
                                <label>管理员账号</label>
                                <input name="admin_user" value="admin" class="input-field">
                            </div>
                            <div class="field">
                                <label>管理员密码</label>
                                <input name="admin_pass" type="password" value="admin123" class="input-field">
                            </div>
                        </div>
                        <div class="field">
                            <label>管理员邮箱</label>
                            <input name="admin_mail" type="email" value="admin@qiling.com" class="input-field">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-primary mt-6">
                    <i class="fa fa-magic mr-2"></i>开始安装
                </button>
            </form>
        <?php endif; ?>

        <p class="footer-text">© 2026 起灵贴吧 · 情绪树洞</p>
    </div>
</body>
</html>
