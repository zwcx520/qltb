<?php
/**
 * 联系站长页面
 */
$pageTitle = '联系站长';
$currentPage = 'contact';
include __DIR__ . '/../includes/header.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $content  = trim($_POST['content'] ?? '');

    if (empty($username)) {
        $error = '请输入用户名';
    } elseif (mb_strlen($content) < 5) {
        $error = '留言内容至少5个字符';
    } elseif (mb_strlen($content) > 500) {
        $error = '留言内容不能超过500个字符';
    } else {
        // 验证用户是否存在
        $stmt = db()->prepare("SELECT id, nickname FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $u = $stmt->fetch();

        if (!$u) {
            $error = '该用户名不存在，请确认后重试';
        } else {
            // 查找管理员
            $admin = db()->query("SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1")->fetch();
            if (!$admin) {
                $error = '系统异常：未找到管理员';
            } else {
                $nickname = $u['nickname'] ?: $username;
                // 发送给管理员（使用 contact 类型，方便会话管理）
                db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, is_read, created_at) VALUES (?, ?, 'contact', ?, 0, NOW())")
                    ->execute([$u['id'], $admin['id'], $content]);
                $success = '留言已发送，站长会尽快回复你 🌸';
                $username = '';
                $content = '';
            }
        }
    }
}
?>

<div style="min-height:100vh;display:flex;flex-direction:column;padding:0;">
    <!-- 顶部导航 -->
    <div style="display:flex;align-items:center;padding:14px 16px;background:white;border-bottom:1px solid var(--border);">
        <a href="<?= $user ? 'index.php?page=about' : 'index.php?page=login' ?>" class="icon-btn" style="background:var(--bg);"><i class="fa fa-angle-left"></i></a>
        <span style="flex:1;text-align:center;font-size:16px;font-weight:600;">联系站长</span>
        <span style="width:36px;"></span>
    </div>

    <div style="padding:20px 16px;flex:1;">
        <!-- 说明 -->
        <div style="background:linear-gradient(135deg,#fce7f3 0%,#ddd6fe 100%);border-radius:16px;padding:18px;margin-bottom:20px;">
            <div style="display:flex;align-items:center;gap:10px;">
                <div style="width:42px;height:42px;border-radius:12px;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;">
                    <i class="fa fa-envelope text-xl" style="color:var(--primary);"></i>
                </div>
                <div>
                    <div style="font-size:15px;font-weight:600;color:var(--text);">给站长留言</div>
                    <div style="font-size:12px;color:var(--text-soft);margin-top:2px;">遇到问题或建议，告诉我们</div>
                </div>
            </div>
        </div>

        <?php if ($success): ?>
            <div style="background:#dcfce7;border:1px solid #bbf7d0;color:#166534;padding:12px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
                <i class="fa fa-check-circle"></i> <?= e($success) ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div style="background:#fef2f2;border:1px solid #fecaca;color:#dc2626;padding:12px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;display:flex;align-items:center;gap:8px;">
                <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" style="background:white;border-radius:16px;padding:20px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <div class="form-group">
                <label class="form-label"><i class="fa fa-user text-primary"></i> 你的用户名</label>
                <input name="username" class="form-input" placeholder="请输入你的用户名" required value="<?= e($username ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label"><i class="fa fa-comment text-primary"></i> 留言内容</label>
                <textarea name="content" class="form-textarea" rows="5" placeholder="请描述你的问题或建议..." required maxlength="500"><?= e($content ?? '') ?></textarea>
                <div style="text-align:right;font-size:12px;color:var(--text-light);margin-top:4px;">
                    <?= mb_strlen($content ?? '') ?>/500
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:13px;font-size:15px;">
                <i class="fa fa-paper-plane"></i> 发送留言
            </button>
        </form>

        <div style="margin-top:20px;padding:14px;background:rgba(255,255,255,0.5);border-radius:12px;font-size:12px;color:var(--text-soft);line-height:1.7;">
            <div style="font-weight:600;color:var(--text);margin-bottom:6px;"><i class="fa fa-info-circle"></i> 温馨提示</div>
            <div>• 请填写正确的用户名，方便站长联系你</div>
            <div>• 留言将发送给管理员，请耐心等待回复</div>
            <div>• 请勿发送垃圾信息或违规内容</div>
        </div>

        <!-- 查看留言回复 -->
        <div style="margin-top:24px;background:linear-gradient(135deg,#ede9fe,#ddd6fe);border-radius:16px;padding:18px;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
                <div style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,0.7);display:flex;align-items:center;justify-content:center;">
                    <i class="fa fa-comments" style="color:#8b5cf6;"></i>
                </div>
                <div>
                    <div style="font-size:14px;font-weight:600;color:var(--text);">查看站长回复</div>
                    <div style="font-size:11px;color:var(--text-soft);">忘记密码也能查看留言哦</div>
                </div>
            </div>
            <form method="get" action="index.php" style="display:flex;gap:8px;">
                <input type="hidden" name="page" value="contact_chat">
                <input name="username" class="form-input" placeholder="输入用户名查询回复" required style="flex:1;">
                <button type="submit" class="btn btn-primary" style="padding:0 16px;white-space:nowrap;">
                    <i class="fa fa-search"></i> 查询
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
