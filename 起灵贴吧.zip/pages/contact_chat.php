<?php
/**
 * 联系站长 - 会话回复页面
 * 已登录用户：查看自己与站长的对话
 * 未登录用户：通过 username 参数查看对话（忘记密码场景）
 * 管理员：可通过 uid 参数查看指定用户的对话并回复
 */
$pageTitle = '联系站长';
$currentPage = 'contact';
include __DIR__ . '/../includes/header.php';

// 获取管理员
$admin = db()->query("SELECT id, nickname, avatar FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1")->fetch();
if (!$admin) {
    echo '<div style="padding:40px;text-align:center;color:var(--text-soft);">系统异常：未找到管理员</div>';
    include __DIR__ . '/../includes/footer.php';
    exit;
}

// 确定对话用户
$chatUser = null;
$isAdminView = false;

if ($user) {
    // 已登录
    if (($user['role'] ?? '') === 'admin' && isset($_GET['uid'])) {
        // 管理员查看指定用户
        $uid = intval($_GET['uid']);
        $stmt = db()->prepare("SELECT id, username, nickname, avatar FROM users WHERE id = ?");
        $stmt->execute([$uid]);
        $chatUser = $stmt->fetch();
        $isAdminView = true;
    } else {
        $chatUser = ['id' => $user['id'], 'username' => $user['username'], 'nickname' => $user['nickname'], 'avatar' => $user['avatar']];
    }
} else {
    // 未登录：通过用户名查询
    $username = trim($_GET['username'] ?? '');
    if ($username) {
        $stmt = db()->prepare("SELECT id, username, nickname, avatar FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $chatUser = $stmt->fetch();
    }
}

if (!$chatUser) {
    // 未找到用户，显示输入框
    ?>
    <div style="min-height:100vh;display:flex;flex-direction:column;">
        <div style="display:flex;align-items:center;padding:14px 16px;background:white;border-bottom:1px solid var(--border);">
            <a href="index.php?page=contact" class="icon-btn" style="background:var(--bg);"><i class="fa fa-angle-left"></i></a>
            <span style="flex:1;text-align:center;font-size:16px;font-weight:600;">查看留言回复</span>
            <span style="width:36px;"></span>
        </div>
        <div style="padding:24px 16px;flex:1;">
            <div style="background:linear-gradient(135deg,#fce7f3,#ddd6fe);border-radius:16px;padding:20px;margin-bottom:20px;text-align:center;">
                <i class="fa fa-search text-3xl" style="color:var(--primary);"></i>
                <div style="font-size:15px;font-weight:600;margin-top:10px;">输入用户名查看站长回复</div>
                <div style="font-size:12px;color:var(--text-soft);margin-top:4px;">忘记密码也能查看留言哦</div>
            </div>
            <form method="get" action="index.php" style="background:white;border-radius:16px;padding:20px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
                <input type="hidden" name="page" value="contact_chat">
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-user text-primary"></i> 用户名</label>
                    <input name="username" class="form-input" placeholder="请输入你的用户名" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> 查询留言</button>
            </form>
            <div style="text-align:center;margin-top:16px;">
                <a href="index.php?page=login" style="font-size:13px;color:var(--primary);">想起密码了？去登录</a>
            </div>
        </div>
    </div>
    <?php
    include __DIR__ . '/../includes/footer.php';
    exit;
}

// 发送新消息
$sendError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_content'])) {
    $content = trim($_POST['reply_content'] ?? '');
    if (mb_strlen($content) < 1) {
        $sendError = '请输入回复内容';
    } elseif (mb_strlen($content) > 500) {
        $sendError = '内容不能超过500个字符';
    } else {
        if ($isAdminView) {
            // 管理员回复用户
            db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, is_read, created_at) VALUES (?, ?, 'contact', ?, 0, NOW())")
                ->execute([$user['id'], $chatUser['id'], $content]);
        } else {
            // 用户发送给管理员
            db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, is_read, created_at) VALUES (?, ?, 'contact', ?, 0, NOW())")
                ->execute([$chatUser['id'], $admin['id'], $content]);
        }
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
}

// 加载对话记录
$uid = $chatUser['id'];
$aid = $admin['id'];
$msgs = db()->query("
    SELECT m.*, u.nickname, u.avatar
    FROM messages m
    LEFT JOIN users u ON m.from_user_id = u.id
    WHERE m.type = 'contact'
      AND ((m.from_user_id = {$uid} AND m.to_user_id = {$aid}) OR (m.from_user_id = {$aid} AND m.to_user_id = {$uid}))
    ORDER BY m.created_at ASC
")->fetchAll();

// 标记对方发的消息为已读
if ($user) {
    $myId = $user['id'];
    db()->exec("UPDATE messages SET is_read = 1 WHERE type = 'contact' AND to_user_id = {$myId} AND from_user_id = " . ($isAdminView ? $uid : $aid));
} elseif ($chatUser) {
    // 未登录用户查看，标记管理员发给该用户的消息为已读
    db()->exec("UPDATE messages SET is_read = 1 WHERE type = 'contact' AND to_user_id = {$uid} AND from_user_id = {$aid}");
}

$otherName = $isAdminView ? ($chatUser['nickname'] ?: $chatUser['username']) : '站长';
$backUrl = $user ? 'index.php?page=message&type=contact' : 'index.php?page=contact';
?>

<div style="min-height:100vh;display:flex;flex-direction:column;background:var(--bg);">
    <!-- 顶部导航 -->
    <div style="display:flex;align-items:center;padding:14px 16px;background:white;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;">
        <a href="<?= $backUrl ?>" class="icon-btn" style="background:var(--bg);"><i class="fa fa-angle-left"></i></a>
        <div style="flex:1;text-align:center;">
            <div style="font-size:16px;font-weight:600;"><?= e($otherName) ?></div>
            <div style="font-size:11px;color:var(--text-light);"><?= $isAdminView ? '@' . e($chatUser['username']) : '在线客服' ?></div>
        </div>
        <span style="width:36px;"></span>
    </div>

    <!-- 对话内容 -->
    <div style="flex:1;padding:16px;overflow-y:auto;padding-bottom:90px;">
        <?php if (empty($msgs)): ?>
            <div style="text-align:center;padding:60px 20px;color:var(--text-soft);">
                <i class="fa fa-comments-o text-4xl" style="color:#ddd;"></i>
                <div style="margin-top:12px;font-size:14px;">还没有留言</div>
                <div style="font-size:12px;margin-top:4px;">在下方输入框发送第一条消息吧</div>
            </div>
        <?php else: ?>
            <?php foreach ($msgs as $m):
                $isMe = $isAdminView ? ($m['from_user_id'] == $user['id']) : ($m['from_user_id'] == $chatUser['id']);
            ?>
            <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:16px;<?= $isMe ? 'flex-direction:row-reverse;' : '' ?>">
                <img src="<?= e(avatar(['id'=>$m['from_user_id'],'avatar'=>$m['avatar'],'nickname'=>$m['nickname']])) ?>" class="avatar-md" style="width:36px;height:36px;">
                <div style="max-width:70%;">
                    <div style="font-size:11px;color:var(--text-light);margin-bottom:4px;<?= $isMe ? 'text-align:right;' : '' ?>">
                        <?= e($m['nickname'] ?: ($isMe ? '我' : '站长')) ?> · <?= time_ago($m['created_at']) ?>
                    </div>
                    <div style="padding:10px 14px;border-radius:14px;font-size:14px;line-height:1.6;word-break:break-word;
                        <?= $isMe
                            ? 'background:linear-gradient(135deg,#ec4899,#a855f7);color:white;border-bottom-right-radius:4px;'
                            : 'background:white;color:var(--text);border-bottom-left-radius:4px;box-shadow:0 1px 4px rgba(0,0,0,0.05);' ?>">
                        <?= e($m['content']) ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- 回复输入框 -->
    <div style="position:fixed;bottom:0;left:0;right:0;background:white;border-top:1px solid var(--border);padding:12px 16px;padding-bottom:calc(12px + env(safe-area-inset-bottom));display:flex;gap:10px;align-items:center;">
        <?php if ($sendError): ?>
            <div style="position:absolute;bottom:100%;left:0;right:0;background:#fef2f2;color:#dc2626;padding:8px 16px;font-size:13px;text-align:center;">
                <?= e($sendError) ?>
            </div>
        <?php endif; ?>
        <form method="post" style="display:flex;gap:10px;width:100%;align-items:center;">
            <input type="text" name="reply_content" class="form-input" placeholder="输入回复内容..." maxlength="500" style="flex:1;" autofocus>
            <button type="submit" class="btn btn-primary" style="padding:10px 18px;white-space:nowrap;">
                <i class="fa fa-paper-plane"></i> 发送
            </button>
        </form>
    </div>
</div>

</body>
</html>
