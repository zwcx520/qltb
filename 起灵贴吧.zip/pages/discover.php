<?php
/**
 * 发现页
 */
$pageTitle = '发现';
$currentPage = 'discover';
include __DIR__ . '/../includes/header.php';

$kw = trim($_GET['kw'] ?? '');

// 创建贴吧处理
$createMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['act'] ?? '') === 'create_tieba') {
    if (!$user) { $createMsg = '请先登录'; }
    else {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $icon = $_POST['icon'] ?? 'tree';
        $cat  = trim($_POST['category'] ?? '');
        if (mb_strlen($name) < 2 || mb_strlen($name) > 20) {
            $createMsg = '贴吧名称需2-20个字符';
        } else {
            // 检查重名
            $chk = db()->prepare("SELECT id FROM tiebas WHERE name = ?");
            $chk->execute([$name]);
            if ($chk->fetch()) {
                $createMsg = '该贴吧名称已存在';
            } else {
                // 处理封面图上传
                $cover = '';
                if (!empty($_FILES['cover']['name'])) {
                    $r = handle_upload($_FILES['cover'], ['jpg','jpeg','png','gif','webp'], 5242880);
                    if ($r['ok']) $cover = $r['url'];
                }
                $stmt = db()->prepare("INSERT INTO tiebas (name, description, icon, cover, category, owner_id, members, created_at) VALUES (?,?,?,?,?,?,1,NOW())");
                $stmt->execute([$name, $desc, $icon, $cover, $cat, $user['id']]);
                $newId = db()->lastInsertId();
                // 创建者自动加入
                db()->prepare("INSERT INTO tieba_follows (tieba_id, user_id, created_at) VALUES (?,?,NOW())")->execute([$newId, $user['id']]);
                header('Location: index.php?page=tieba&id=' . $newId);
                exit;
            }
        }
    }
}

// 贴吧列表
$tiebas = db()->query("SELECT * FROM tiebas ORDER BY hot DESC, members DESC")->fetchAll();

// 分类
$cats = db()->query("SELECT * FROM categories ORDER BY sort ASC")->fetchAll();
$catColors = ['#f472b6','#fb923c','#fbbf24','#a78bfa','#60a5fa','#34d399'];

// 热门帖子
$hotPosts = db()->query("
    SELECT p.*, u.nickname, u.avatar as u_avatar, t.name as tieba_name
    FROM posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.status = 1 ORDER BY p.likes DESC, p.comments DESC LIMIT 10
")->fetchAll();
?>

<div class="app-header">
    <div class="header-inner">
        <form action="index.php" method="get" class="search-bar w-full">
            <i class="fa fa-search text-light"></i>
            <input type="hidden" name="page" value="search">
            <input type="text" name="kw" value="<?= e($kw) ?>" placeholder="搜索贴吧、帖子、用户...">
        </form>
    </div>
</div>

<!-- 分类标签 -->
<div style="padding:12px 16px;display:flex;gap:8px;flex-wrap:wrap;">
    <a href="index.php?page=discover" class="tag" style="background:linear-gradient(135deg,#ec4899,#a855f7);color:white;">全部</a>
    <?php foreach ($cats as $i => $c): ?>
        <a href="index.php?page=discover&cat=<?= $c['id'] ?>" class="tag" style="background:rgba(255,255,255,0.8);color:<?= $catColors[$i % count($catColors)] ?>;border:1px solid <?= $catColors[$i % count($catColors)] ?>33;">
            <i class="fa fa-<?= e($c['icon']) ?>"></i> <?= e($c['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- 推荐贴吧 -->
<div class="section-title">
    <span><i class="fa fa-compass text-primary mr-1"></i>全部贴吧</span>
    <?php if ($user): ?>
    <a href="javascript:;" id="show-create-tieba" class="more" style="color:var(--primary);"><i class="fa fa-plus-circle"></i> 创建贴吧</a>
    <?php endif; ?>
</div>

<!-- 创建贴吧表单 -->
<?php if ($user): ?>
<div id="create-tieba-form" class="card" style="margin:0 16px 12px;padding:16px;display:none;">
    <?php if ($createMsg): ?>
    <div style="padding:8px 12px;border-radius:8px;background:#fee2e2;color:#991b1b;font-size:13px;margin-bottom:12px;">
        <i class="fa fa-exclamation-circle"></i> <?= e($createMsg) ?>
    </div>
    <?php endif; ?>
    <form method="post" id="createTiebaForm" enctype="multipart/form-data">
        <input type="hidden" name="act" value="create_tieba">
        <div style="margin-bottom:12px;">
            <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">贴吧封面（可选，不上传则使用图标）</label>
            <div id="cover-upload-area" style="position:relative;width:100%;height:120px;border:2px dashed var(--border);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;background:rgba(255,255,255,0.5);overflow:hidden;">
                <input type="file" id="cover-input" name="cover" accept="image/*" style="display:none;">
                <i class="fa fa-cloud-upload text-2xl" style="color:var(--text-light);"></i>
                <span style="font-size:12px;color:var(--text-light);margin-top:4px;">点击上传封面图</span>
                <img id="cover-preview" style="display:none;width:100%;height:100%;object-fit:cover;position:absolute;inset:0;">
                <button type="button" id="cover-remove" style="display:none;position:absolute;top:6px;right:6px;width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,0.6);color:white;border:none;cursor:pointer;font-size:14px;z-index:2;">×</button>
            </div>
        </div>
        <div style="margin-bottom:12px;">
            <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">贴吧名称 <span style="color:#ef4444;">*</span></label>
            <input type="text" name="name" maxlength="20" required placeholder="2-20个字符" style="width:100%;padding:10px 12px;border:1px solid var(--border);border-radius:10px;font-size:14px;background:rgba(255,255,255,0.8);">
        </div>
        <div style="margin-bottom:12px;">
            <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">贴吧简介</label>
            <textarea name="description" maxlength="100" rows="2" placeholder="一句话介绍你的贴吧..." style="width:100%;padding:10px 12px;border:1px solid var(--border);border-radius:10px;font-size:14px;background:rgba(255,255,255,0.8);resize:none;"></textarea>
        </div>
        <div style="margin-bottom:12px;">
            <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">选择图标</label>
            <div style="display:flex;gap:6px;flex-wrap:wrap;">
                <?php
                $icons = ['heart','sun','moon','star','tree','flower','fire','music','book','game','film','camera'];
                foreach ($icons as $ic):
                ?>
                <label style="cursor:pointer;">
                    <input type="radio" name="icon" value="<?= $ic ?>" <?= $ic==='tree'?'checked':'' ?> style="display:none;">
                    <div class="icon-opt" data-icon="<?= $ic ?>" style="width:36px;height:36px;border-radius:10px;border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--text-soft);">
                        <i class="fa fa-<?= $ic ?>"></i>
                    </div>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <div style="margin-bottom:12px;">
            <label style="font-size:13px;color:var(--text-soft);display:block;margin-bottom:4px;">所属分类</label>
            <select name="category" style="width:100%;padding:10px 12px;border:1px solid var(--border);border-radius:10px;font-size:14px;background:rgba(255,255,255,0.8);">
                <option value="">未分类</option>
                <?php foreach ($cats as $c): ?>
                <option value="<?= e($c['name']) ?>"><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="display:flex;gap:8px;">
            <button type="button" id="cancel-create" class="btn btn-ghost" style="flex:1;padding:10px;">取消</button>
            <button type="submit" class="btn btn-primary" style="flex:2;padding:10px;"><i class="fa fa-check"></i> 创建贴吧</button>
        </div>
    </form>
</div>

<script>
// 切换创建贴吧表单
document.getElementById('show-create-tieba').addEventListener('click', function(){
    var f = document.getElementById('create-tieba-form');
    f.style.display = f.style.display === 'none' ? 'block' : 'none';
    if (f.style.display === 'block') f.scrollIntoView({behavior:'smooth',block:'center'});
});
document.getElementById('cancel-create').addEventListener('click', function(){
    document.getElementById('create-tieba-form').style.display = 'none';
});
// 图标选择高亮
document.querySelectorAll('.icon-opt').forEach(function(el){
    el.addEventListener('click', function(){
        document.querySelectorAll('.icon-opt').forEach(function(e){
            e.style.borderColor = 'var(--border)';
            e.style.color = 'var(--text-soft)';
            e.style.background = 'transparent';
        });
        this.style.borderColor = 'var(--primary)';
        this.style.color = 'var(--primary)';
        this.style.background = 'rgba(236,72,153,0.08)';
    });
});
// 默认高亮第一个
var firstIcon = document.querySelector('.icon-opt');
if (firstIcon && firstIcon.querySelector('input')?.checked) {
    firstIcon.style.borderColor = 'var(--primary)';
    firstIcon.style.color = 'var(--primary)';
    firstIcon.style.background = 'rgba(236,72,153,0.08)';
}
// 封面图上传预览
var coverArea = document.getElementById('cover-upload-area');
var coverInput = document.getElementById('cover-input');
var coverPreview = document.getElementById('cover-preview');
var coverRemove = document.getElementById('cover-remove');
if (coverArea && coverInput) {
    coverArea.addEventListener('click', function(e){
        if (e.target !== coverRemove) coverInput.click();
    });
    coverInput.addEventListener('change', function(){
        if (this.files && this.files[0]) {
            coverPreview.src = URL.createObjectURL(this.files[0]);
            coverPreview.style.display = 'block';
            coverRemove.style.display = 'flex';
            coverArea.querySelector('.fa-cloud-upload').style.display = 'none';
            coverArea.querySelector('span').style.display = 'none';
        }
    });
    coverRemove.addEventListener('click', function(e){
        e.stopPropagation();
        coverInput.value = '';
        coverPreview.src = '';
        coverPreview.style.display = 'none';
        coverRemove.style.display = 'none';
        coverArea.querySelector('.fa-cloud-upload').style.display = '';
        coverArea.querySelector('span').style.display = '';
    });
}
</script>
<?php endif; ?>

<?php foreach ($tiebas as $t): ?>
    <a href="index.php?page=tieba&id=<?= $t['id'] ?>" class="tieba-row">
        <div class="tieba-cover" style="background:<?= cover($t) ?>">
            <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
        </div>
        <div class="tieba-info">
            <div class="tieba-name"><?= e($t['name']) ?></div>
            <div class="tieba-desc"><?= e($t['description']) ?></div>
            <div class="tieba-meta">
                <i class="fa fa-users"></i> <?= $t['members'] ?> 成员
                <i class="fa fa-file-text-o ml-2"></i> <?= $t['posts'] ?> 帖子
            </div>
        </div>
        <?php if ($t['hot'] > 0): ?><span class="tag tag-hot">HOT</span><?php endif; ?>
    </a>
<?php endforeach; ?>

<!-- 热门帖子 -->
<div class="section-title" style="margin-top:8px;">
    <span><i class="fa fa-fire text-primary mr-1"></i>热门帖子</span>
</div>

<?php foreach ($hotPosts as $p):
    $liked = is_liked($p['id']);
    $imgs = $p['images'] ? json_decode($p['images'], true) : [];
?>
    <div class="post-card">
        <div class="post-header">
            <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar">
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname']) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?> · <?= e($p['tieba_name']) ?></div>
            </div>
        </div>
        <a href="index.php?page=post&id=<?= $p['id'] ?>">
            <?php if ($p['title']): ?><div class="post-title"><?= e($p['title']) ?></div><?php endif; ?>
            <div class="post-content"><?= e($p['content']) ?></div>
            <?php if (!empty($imgs)): ?>
                <div class="post-images <?= count($imgs)===1?'single':(count($imgs)===2?'double':'triple') ?>">
                    <?php foreach (array_slice($imgs,0,3) as $img): ?>
                        <img src="<?= e($img) ?>">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </a>
        <div class="post-actions">
            <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i><span class="count"><?= $p['likes'] ?></span>
            </div>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-action"><i class="fa fa-comment-o"></i><span><?= $p['comments'] ?></span></a>
        </div>
    </div>
<?php endforeach; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
