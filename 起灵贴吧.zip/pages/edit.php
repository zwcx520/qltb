<?php
/**
 * 编辑资料页
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$pageTitle = '编辑资料';
$currentPage = 'profile';
include __DIR__ . '/../includes/header.php';

$msg = '';
$msgType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nickname = trim($_POST['nickname'] ?? '');
    $bio = trim($_POST['bio'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // 头像上传
    $avatar = $user['avatar'];
    if (!empty($_FILES['avatar']['name'])) {
        $r = handle_upload($_FILES['avatar'], ['jpg','jpeg','png','gif','webp'], 5242880);
        if ($r['ok']) {
            // 上传成功，删除旧头像文件（覆盖原图片）
            if (!empty($user['avatar'])) {
                delete_uploaded_file($user['avatar']);
            }
            $avatar = $r['url'];
        } else {
            $msg = '头像上传失败: ' . $r['msg'];
            $msgType = 'error';
        }
    }

    if ($msgType === 'success') {
        $stmt = db()->prepare("UPDATE users SET nickname = ?, bio = ?, email = ?, avatar = ? WHERE id = ?");
        $stmt->execute([$nickname, $bio, $email, $avatar, $user['id']]);
        $msg = '保存成功';
        $user = current_user(); // 刷新
    }
}
?>

<div class="app-header">
    <div class="header-inner">
        <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-angle-left"></i></a>
        <h1 class="app-title" style="font-size:17px;">编辑资料</h1>
        <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-check text-primary"></i></a>
    </div>
</div>

<?php if ($msg): ?>
    <div style="padding:12px 16px;color:white;text-align:center;font-size:13px;border-radius:0;<?= $msgType==='error'?'background:#ef4444':'background:#10b981' ?>">
        <i class="fa fa-<?= $msgType==='error'?'exclamation-circle':'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" style="padding:16px;">
    <!-- 头像 -->
    <div class="form-group" style="text-align:center;">
        <label class="form-label">头像</label>
        <label for="avatar-input" style="cursor:pointer;display:inline-block;position:relative;">
            <img id="avatar-preview" src="<?= e(avatar($user)) ?>" class="avatar-lg" style="border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
            <div style="position:absolute;bottom:0;right:0;width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#ec4899,#a855f7);color:white;display:flex;align-items:center;justify-content:center;font-size:14px;border:2px solid white;">
                <i class="fa fa-camera"></i>
            </div>
        </label>
        <input type="file" id="avatar-input" name="avatar" accept="image/*" style="display:none;">
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">点击头像更换，支持 JPG/PNG/GIF，最大 5MB</div>
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-user text-primary"></i> 用户名</label>
        <input class="form-input" value="<?= e($user['username']) ?>" disabled style="opacity:0.6;">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-smile-o text-primary"></i> 昵称</label>
        <input name="nickname" class="form-input" value="<?= e($user['nickname']) ?>" maxlength="50">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-envelope text-primary"></i> 邮箱</label>
        <input name="email" type="email" class="form-input" value="<?= e($user['email']) ?>">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-quote-left text-primary"></i> 个性签名</label>
        <textarea name="bio" class="form-textarea" maxlength="200" placeholder="一句话介绍自己..."><?= e($user['bio']) ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary btn-block" style="padding:14px;margin-top:8px;">
        <i class="fa fa-save"></i> 保存修改
    </button>
</form>

<script>
// 头像即时预览
document.getElementById('avatar-input').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('avatar-preview').src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
    }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
