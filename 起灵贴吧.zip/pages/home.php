<?php
/**
 * 首页
 */
$pageTitle = '首页';
$currentPage = 'home';
include __DIR__ . '/../includes/header.php';

// 获取帖子列表（关联用户和贴吧）
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 10;
$offset = ($pageNum - 1) * $perPage;

$total = db()->query("SELECT COUNT(*) FROM posts WHERE status = 1")->fetchColumn();
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.role, u.posts, t.name as tieba_name, t.icon as tieba_icon
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.status = 1
    ORDER BY p.is_top DESC, p.created_at DESC
    LIMIT {$offset}, {$perPage}
");
$stmt->execute();
$posts = $stmt->fetchAll();

// 热门贴吧
$hotTiebas = db()->query("SELECT * FROM tiebas ORDER BY members DESC LIMIT 8")->fetchAll();

// 分类
$cats = db()->query("SELECT * FROM categories ORDER BY sort ASC")->fetchAll();
$catIcons = ['heart'=>'#f472b6','coffee'=>'#fb923c','sun'=>'#fbbf24','tree'=>'#a78bfa','star'=>'#60a5fa'];
?>

<!-- 顶部 -->
<div class="app-header">
    <div class="header-inner">
        <h1 class="app-title"><img src="https://picsum.photos/100/100?random=1" class="title-logo" alt="" onerror="this.style.display='none'">起灵贴吧</h1>
        <a href="index.php?page=search" class="icon-btn"><i class="fa fa-search"></i></a>
        <a href="index.php?page=message" class="icon-btn">
            <i class="fa fa-bell-o"></i>
            <?php if ($user): $unread = db()->query("SELECT COUNT(*) FROM messages WHERE to_user_id = {$user['id']} AND is_read = 0")->fetchColumn(); ?>
                <?php if ($unread > 0): ?><span class="badge"><?= $unread > 99 ? '99+' : $unread ?></span><?php endif; ?>
            <?php endif; ?>
        </a>
    </div>
</div>
<!-- 公告跑马灯 -->
<?php
$gongaoText = trim($settings['announcement'] ?? '');
if ($gongaoText === '') {
    $gongaoText = '🔔 社区公告：请遵守社区规范，禁止发布违法违规、色情暴力、人身攻击等不良信息，共同维护文明友好的社区环境。违反者将视情节轻重予以警告、禁言或封号处理。';
}
?>
<div class="gongao">
    <i class="fa fa-bullhorn gongao-icon"></i>
    <div class="gongao-track">
        <span class="gongao-text"><?= e($gongaoText) ?></span>
    </div>
</div>
<!-- Banner -->
<?php $bannerImg = trim($settings['banner_image'] ?? ''); ?>
<div class="banner"<?php if ($bannerImg): ?> style="background-image:url('<?= e($bannerImg) ?>');background-size:cover;background-position:center;"<?php endif; ?>>
    <div class="banner-text">
        <h2>🌳 欢迎来到情绪树洞</h2>
        <p>在这里，每一份情绪都被温柔以待</p>
    </div>
</div>

<!-- 分类入口 -->
<div class="category-grid">
    <?php foreach ($cats as $c): ?>
        <a href="index.php?page=discover&cat=<?= $c['id'] ?>" class="cat-item">
            <div class="cat-icon" style="background: linear-gradient(135deg, <?= $catIcons[$c['icon']] ?? '#a855f7' ?>, <?= $catIcons[$c['icon']] ?? '#ec4899' ?>)">
                <i class="fa fa-<?= e($c['icon']) ?>"></i>
            </div>
            <span><?= e($c['name']) ?></span>
        </a>
    <?php endforeach; ?>
</div>

<!-- 热门贴吧 -->
<div class="section-title">
    <span><i class="fa fa-fire text-primary mr-1"></i>热门贴吧</span>
    <a href="index.php?page=discover" class="more">更多 <i class="fa fa-angle-right"></i></a>
</div>
<div style="display:flex;gap:10px;overflow-x:auto;padding:0 16px 8px;scrollbar-width:none;">
    <?php foreach ($hotTiebas as $t): ?>
        <a href="index.php?page=tieba&id=<?= $t['id'] ?>" style="flex-shrink:0;width:110px;text-align:center;">
            <div class="tieba-cover" style="width:70px;height:70px;margin:0 auto;background:<?= cover($t) ?>">
                <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
            </div>
            <div class="text-sm font-bold mt-1"><?= e($t['name']) ?></div>
            <div class="text-xs text-light"><?= $t['members'] ?> 人</div>
        </a>
    <?php endforeach; ?>
</div>

<!-- 帖子流 -->
<div class="section-title">
    <span><i class="fa fa-rss text-primary mr-1"></i>推荐动态</span>
</div>

<?php if (empty($posts)): ?>
    <div class="empty">
        <i class="fa fa-leaf"></i>
        <p>还没有动态，去发布第一条吧 ~</p>
        
    </div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
        $imgClass = count($imgs) === 1 ? 'single' : (count($imgs) === 2 ? 'double' : (count($imgs) >= 3 ? 'triple' : ''));
        $liked = is_liked($p['id']);
        $favorited = is_favorited($p['id']);
    ?>
    <div class="post-card">
        <div class="post-header">
            <a href="index.php?page=user&id=<?= $p['user_id'] ?>">
                <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar">
            </a>
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname']) ?> <?= user_label($p) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?></div>
            </div>
            <a href="index.php?page=tieba&id=<?= $p['tieba_id'] ?>" class="post-tieba-tag">
                <i class="fa fa-<?= e($p['tieba_icon'] ?: 'tree') ?>"></i> <?= e($p['tieba_name']) ?>
            </a>
        </div>

        <?php if ($p['title']): ?>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-title">
                <?php if ($p['is_top']): ?><span class="tag tag-top" style="margin-right:6px;">置顶</span><?php endif; ?>
                <?php if ($p['is_hot']): ?><span class="tag tag-hot" style="margin-right:6px;">热门</span><?php endif; ?>
                <?= e($p['title']) ?>
            </a>
        <?php endif; ?>

        <?php if ($p['content']): ?>
            <div class="post-content"><?= nl2br(e($p['content'])) ?></div>
        <?php endif; ?>

        <?php if (!empty($imgs)): ?>
            <div class="post-images <?= $imgClass ?>">
                <?php foreach (array_slice($imgs, 0, 9) as $img): ?>
                    <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')">
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($p['video']): ?>
            <div class="post-video">
                <video src="<?= e($p['video']) ?>" preload="metadata" poster=""></video>
                <div class="video-play"><i class="fa fa-play"></i></div>
            </div>
        <?php endif; ?>

        <div class="post-actions">
            <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $liked ? 'fa-heart' : 'fa-heart-o' ?>"></i>
                <span class="count"><?= $p['likes'] ?></span>
            </div>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-action">
                <i class="fa fa-comment-o"></i>
                <span><?= $p['comments'] ?></span>
            </a>
            <div class="post-action <?= $favorited?'favorited':'' ?>" onclick="favoritePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $favorited ? 'fa-bookmark' : 'fa-bookmark-o' ?>"></i>
                <span class="count"><?= $p['favorites'] ?? 0 ?></span>
            </div>
            <div class="post-action" onclick="toast('分享成功~')">
                <i class="fa fa-share-alt"></i>
                <span><?= $p['shares'] ?></span>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- 分页 -->
    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div style="display:flex;justify-content:center;gap:8px;padding:16px;">
        <?php if ($pageNum > 1): ?>
            <a href="index.php?page=home&p=<?= $pageNum-1 ?>" class="btn btn-ghost"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="btn btn-ghost"><?= $pageNum ?> / <?= $totalPage ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="index.php?page=home&p=<?= $pageNum+1 ?>" class="btn btn-ghost"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
