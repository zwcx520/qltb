<?php
/**
 * 登录页
 */
$pageTitle = '登录';
$currentPage = 'login';
include __DIR__ . '/../includes/header.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $u = $stmt->fetch();
    if ($u && verify_password($password, $u['password'])) {
        $_SESSION['uid'] = $u['id'];
        db()->exec("UPDATE users SET last_login = NOW() WHERE id = {$u['id']}");
        header('Location: index.php');
        exit;
    } else {
        $error = '用户名或密码错误';
    }
}
?>

<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;">
    <!-- 头像 / LOGO 区域 -->
    <div style="text-align:center;margin-bottom:30px;">
        <div id="loginAvatarBox" style="width:86px;height:86px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,#ec4899,#a855f7);display:flex;align-items:center;justify-content:center;box-shadow:0 10px 30px rgba(236,72,153,0.3);transition:all 0.3s ease;overflow:hidden;">
            <i class="fa fa-tree text-white text-3xl" id="loginAvatarIcon"></i>
            <img id="loginAvatarImg" src="" style="display:none;width:100%;height:100%;object-fit:cover;">
        </div>
        <h1 style="font-size:24px;font-weight:700;background:linear-gradient(135deg,#ec4899,#a855f7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-top:16px;">起灵贴吧</h1>
        <div id="loginAvatarTip" style="font-size:12px;color:var(--text-soft);margin-top:6px;min-height:16px;">欢迎回来，继续你的树洞之旅 </div>
    </div>

    <?php if ($error): ?>
        <div style="background:#fef2f2;border:1px solid #fecaca;color:#dc2626;padding:10px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;width:100%;max-width:340px;text-align:center;">
            <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
        </div>
    <?php endif; ?>

    <form method="post" style="width:100%;max-width:340px;">
        <div class="form-group">
            <label class="form-label"><i class="fa fa-user text-primary"></i> 用户名</label>
            <input name="username" id="loginUsername" class="form-input" placeholder="请输入用户名" required autocomplete="username">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock text-primary"></i> 密码</label>
            <input name="password" type="password" class="form-input" placeholder="请输入密码" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block" style="padding:14px;font-size:15px;margin-top:8px;">
            <i class="fa fa-sign-in"></i> 登 录
        </button>
    </form>

    <div style="margin-top:24px;text-align:center;">
        <?php if (intval($settings['allow_register'] ?? 1) === 1): ?>
        <p style="font-size:13px;color:var(--text-soft);">
            还没有账号？
            <a href="index.php?page=register" style="color:var(--primary);font-weight:500;">立即注册</a>
        </p>
        <?php endif; ?>
        <a href="index.php?page=contact" style="display:inline-block;margin-top:16px;font-size:12px;color:var(--text-light);">
            <i class="fa fa-envelope"></i> 联系站长
        </a>
    </div>
</div>

<script>
(function(){
    var usernameInput = document.getElementById('loginUsername');
    var avatarBox = document.getElementById('loginAvatarBox');
    var avatarIcon = document.getElementById('loginAvatarIcon');
    var avatarImg = document.getElementById('loginAvatarImg');
    var avatarTip = document.getElementById('loginAvatarTip');
    var lastQuery = '';

    function showDefaultAvatar() {
        avatarImg.style.display = 'none';
        avatarIcon.style.display = '';
        avatarIcon.className = 'fa fa-tree text-white text-3xl';
        avatarBox.style.background = 'linear-gradient(135deg,#ec4899,#a855f7)';
        avatarTip.textContent = '欢迎回来，继续你的树洞之旅 ';
    }

    function fetchAvatar(username) {
        if (!username || username === lastQuery) return;
        lastQuery = username;
        // 显示加载态
        avatarIcon.style.display = 'none';
        avatarImg.style.display = 'none';
        avatarBox.style.background = 'linear-gradient(135deg,#f3f4f6,#e5e7eb)';
        avatarTip.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 正在查找用户...';

        fetch('api/get_avatar.php?username=' + encodeURIComponent(username))
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (username !== lastQuery) return; // 防止旧请求覆盖新结果
            if (d.code === 0) {
                avatarImg.src = d.avatar;
                avatarImg.style.display = 'block';
                avatarBox.style.background = 'linear-gradient(135deg,#ec4899,#a855f7)';
                avatarTip.innerHTML = '<i class="fa fa-check-circle" style="color:#10b981;"></i> 欢迎，尊敬的：' + d.nickname;
            } else {
                showDefaultAvatar();
                avatarTip.innerHTML = '<i class="fa fa-question-circle" style="color:#9ca3af;"></i> 平台没有该用户';
            }
        })
        .catch(function(){
            if (username === lastQuery) showDefaultAvatar();
        });
    }

    var timer = null;
    usernameInput.addEventListener('input', function(){
        var val = this.value.trim();
        if (!val) {
            lastQuery = '';
            showDefaultAvatar();
            return;
        }
        clearTimeout(timer);
        timer = setTimeout(function(){ fetchAvatar(val); }, 400);
    });

    usernameInput.addEventListener('blur', function(){
        var val = this.value.trim();
        if (val) fetchAvatar(val);
    });
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
