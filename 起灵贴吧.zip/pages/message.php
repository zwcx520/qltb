<?php
/**
 * 消息页 - 评论/点赞/关注/系统通知
 */
$pageTitle = '消息';
$currentPage = 'message';
include __DIR__ . '/../includes/header.php';

if (!$user) { header('Location: index.php?page=login'); exit; }

// 处理全部已读
if (isset($_GET['read_all'])) {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']} AND is_read = 0");
    header('Location: index.php?page=message');
    exit;
}

// 标记当前分类消息已读
$type = $_GET['type'] ?? 'all';
if ($type === 'all') {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']}");
} else {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']} AND type = '" . addslashes($type) . "'");
}

// 各分类未读数
$unreadStats = db()->query("
    SELECT type, COUNT(*) as cnt FROM messages
    WHERE to_user_id = {$user['id']} AND is_read = 0
    GROUP BY type
")->fetchAll();
$unreadMap = [];
foreach ($unreadStats as $s) $unreadMap[$s['type']] = (int)$s['cnt'];
$totalUnread = array_sum($unreadMap);

// 消息列表
$where = "to_user_id = {$user['id']}";
if ($type !== 'all') $where .= " AND type = '" . addslashes($type) . "'";

$msgs = db()->query("
    SELECT m.*, u.nickname, u.avatar, u.id as from_id
    FROM messages m
    LEFT JOIN users u ON m.from_user_id = u.id
    WHERE {$where}
    ORDER BY m.created_at DESC
    LIMIT 50
")->fetchAll();

$tabs = [
    'all' => ['全部', 'inbox'],
    'comment' => ['评论', 'comment'],
    'like' => ['赞', 'heart'],
    'follow' => ['关注', 'user-plus'],
    'system' => ['通知', 'bell'],
    'contact' => ['联系站长', 'envelope'],
];
?>

<div class="app-header">
    <div class="header-inner">
        <h1 class="app-title" style="font-size:18px;">消息</h1>
        <?php if ($totalUnread > 0): ?>
        <a href="index.php?page=message&read_all=1" class="icon-btn" style="font-size:12px;color:var(--primary);" onclick="return confirm('标记全部已读？')">
            <i class="fa fa-check-circle-o"></i> 全部已读
        </a>
        <?php else: ?>
        <span class="icon-btn" style="font-size:12px;color:var(--text-light);"><i class="fa fa-check-circle-o"></i> 全部已读</span>
        <?php endif; ?>
    </div>
    <div style="display:flex;gap:4px;margin-top:10px;overflow-x:auto;padding-bottom:4px;">
        <?php foreach ($tabs as $k => $v): ?>
            <?php $cnt = $k==='all' ? $totalUnread : ($unreadMap[$k] ?? 0); ?>
            <a href="index.php?page=message&type=<?= $k ?>" class="tag" style="background:<?= $type===$k?'linear-gradient(135deg,#ec4899,#a855f7)':'rgba(255,255,255,0.6)' ?>;color:<?= $type===$k?'white':'var(--text-soft)' ?>;white-space:nowrap;position:relative;">
                <i class="fa fa-<?= $v[1] ?>"></i> <?= $v[0] ?>
                <?php if ($cnt > 0): ?><span style="background:#ef4444;color:white;font-size:10px;padding:0 5px;border-radius:8px;margin-left:4px;"><?= $cnt ?></span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<?php if (empty($msgs)): ?>
    <div class="empty">
        <i class="fa fa-envelope-o"></i>
        <p>暂无<?= $type==='all'?'':$tabs[$type][0] ?>消息</p>
        <p class="text-xs text-light mt-1">有新消息会在这里通知你哦 ~</p>
        <?php if ($type === 'contact'): ?>
            <a href="index.php?page=contact_chat" class="btn btn-primary" style="margin-top:16px;padding:10px 24px;">
                <i class="fa fa-comments"></i> 给站长留言
            </a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <?php foreach ($msgs as $m):
    // 联系站长消息跳转会话页，其他消息跳转对应用户/帖子
    if ($m['type'] === 'contact') {
        if (($user['role'] ?? '') === 'admin') {
            $msgLink = 'index.php?page=contact_chat&uid=' . $m['from_id'];
        } else {
            $msgLink = 'index.php?page=contact_chat';
        }
    } else {
        $msgLink = $m['post_id'] ? 'index.php?page=post&id='.$m['post_id'] : ($m['from_id'] ? 'index.php?page=user&id='.$m['from_id'] : '#');
    }
    ?>
    <a href="<?= $msgLink ?>"
       style="display:flex;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid var(--border);transition:all .3s;background:<?= !$m['is_read']?'rgba(236,72,153,0.03)':'transparent' ?>;"
       onmouseover="this.style.background='rgba(255,255,255,0.5)'">
        <div style="position:relative;">
            <img src="<?= e(avatar(['id'=>$m['from_id'],'avatar'=>$m['avatar'],'nickname'=>$m['nickname']])) ?>" class="avatar-md">
            <?php
                $iconMap = ['like'=>'heart','comment'=>'comment','follow'=>'user-plus','system'=>'bell','contact'=>'envelope','chat'=>'envelope'];
                $colorMap = ['like'=>'#f472b6','comment'=>'#a78bfa','follow'=>'#60a5fa','system'=>'#fbbf24','contact'=>'#8b5cf6','chat'=>'#34d399'];
            ?>
            <span style="position:absolute;bottom:-2px;right:-2px;width:20px;height:20px;border-radius:50%;background:<?= $colorMap[$m['type']] ?>;color:white;display:flex;align-items:center;justify-content:center;font-size:10px;border:2px solid var(--bg);">
                <i class="fa fa-<?= $iconMap[$m['type']] ?? 'bell' ?>"></i>
            </span>
        </div>
        <div style="flex:1;min-width:0;">
            <div style="font-size:14px;font-weight:500;display:flex;align-items:center;gap:6px;">
                <?= e($m['nickname'] ?: '系统消息') ?>
                <?php if (!$m['is_read']): ?><span style="width:6px;height:6px;border-radius:50%;background:var(--primary);"></span><?php endif; ?>
            </div>
            <div style="font-size:12px;color:var(--text-soft);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($m['content']) ?></div>
            <div style="font-size:11px;color:var(--text-light);margin-top:2px;"><?= time_ago($m['created_at']) ?></div>
        </div>
    </a>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
