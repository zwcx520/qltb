<?php
/**
 * 我的贴吧 - 列出当前用户创建的贴吧
 * 仅可管理贴吧内的内容（帖子），不能删除/编辑贴吧本身信息
 */
$pageTitle = '我的贴吧';
$bodyClass = 'no-nav';
include __DIR__ . '/../includes/header.php';

if (!$user) { header('Location: index.php?page=login'); exit; }

// 处理置顶/取消置顶/删除帖子的操作反馈（由 tieba_manage 跳回时带 msg）
$opMsg = $_GET['msg'] ?? '';

// 我创建的贴吧
$myTiebas = db()->prepare("
    SELECT * FROM tiebas WHERE owner_id = ? ORDER BY created_at DESC
");
$myTiebas->execute([$user['id']]);
$myTiebas = $myTiebas->fetchAll();
?>

<!-- 顶部栏 -->
<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:white;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;">
    <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-angle-left"></i></a>
    <div style="font-size:17px;font-weight:600;flex:1;">我的贴吧</div>
    <span style="font-size:12px;color:var(--text-light);"><?= count($myTiebas) ?> 个</span>
</div>

<?php if ($opMsg): ?>
<div style="padding:10px 16px;background:#dcfce7;color:#166534;font-size:13px;">
    <i class="fa fa-check-circle"></i> <?= e($opMsg) ?>
</div>
<?php endif; ?>

<!-- 说明条 -->
<div style="padding:10px 16px;background:rgba(251,191,36,0.12);color:#92400e;font-size:12.5px;display:flex;align-items:flex-start;gap:8px;">
    <i class="fa fa-info-circle" style="margin-top:2px;"></i>
    <span>你只能管理自己创建的贴吧内的帖子（删除、置顶），不能修改或删除贴吧本身信息。</span>
</div>

<?php if (empty($myTiebas)): ?>
    <div class="empty">
        <i class="fa fa-star-o"></i>
        <p>你还没有创建任何贴吧</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">贴吧由管理员在后台创建，你成为某贴吧的吧主后可在此管理内容。</p>
    </div>
<?php else: ?>
    <div style="padding:12px 16px;display:flex;flex-direction:column;gap:12px;">
        <?php foreach ($myTiebas as $t): ?>
        <div class="post-card" style="padding:14px;">
            <div style="display:flex;align-items:center;gap:12px;">
                <div class="tieba-cover" style="width:52px;height:52px;background:<?= cover($t) ?>;flex-shrink:0;">
                    <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:15px;font-weight:600;color:var(--text);"><?= e($t['name']) ?></div>
                    <div style="font-size:12px;color:var(--text-soft);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($t['description'] ?: '暂无简介') ?></div>
                    <div style="display:flex;gap:14px;margin-top:6px;font-size:11px;color:var(--text-light);">
                        <span><i class="fa fa-users"></i> <?= $t['members'] ?> 成员</span>
                        <span><i class="fa fa-file-text-o"></i> <?= $t['posts'] ?> 帖子</span>
                    </div>
                </div>
            </div>
            <div style="display:flex;gap:8px;margin-top:12px;">
                <a href="index.php?page=tieba_manage&id=<?= $t['id'] ?>" class="btn btn-primary btn-sm" style="flex:1;">
                    <i class="fa fa-cog"></i> 管理内容
                </a>
                <a href="index.php?page=tieba&id=<?= $t['id'] ?>" class="btn btn-ghost btn-sm">
                    <i class="fa fa-eye"></i> 查看
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
