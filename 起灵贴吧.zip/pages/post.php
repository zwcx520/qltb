<?php
/**
 * 帖子详情页
 */
$postId = intval($_GET['id'] ?? 0);
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.bio, u.id as uid, t.name as tieba_name, t.id as tieba_id, t.icon as tieba_icon
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.id = ?
");
$stmt->execute([$postId]);
$post = $stmt->fetch();

if (!$post) { header('Location: index.php'); exit; }

$pageTitle = $post['title'] ?: '帖子详情';
$currentPage = 'home';
$bodyClass = 'no-nav';
include __DIR__ . '/../includes/header.php';

// 增加浏览量
db()->exec("UPDATE posts SET views = views + 1 WHERE id = {$postId}");

$imgs = $post['images'] ? json_decode($post['images'], true) : [];
$liked = is_liked($postId);
$favorited = is_favorited($postId);

// 是否已关注作者
$isFollowingAuthor = false;
if ($user && $user['id'] != $post['uid']) {
    $stmt = db()->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
    $stmt->execute([$user['id'], $post['uid']]);
    $isFollowingAuthor = (bool)$stmt->fetch();
}

// 评论列表
$comments = db()->query("
    SELECT c.*, u.nickname, u.avatar as u_avatar, u.id as uid
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.post_id = {$postId} AND c.status = 1 AND c.parent_id = 0
    ORDER BY c.created_at ASC
")->fetchAll();

// 查询每条评论的回复
foreach ($comments as &$c) {
    $c['replies'] = db()->query("
        SELECT r.*, u.nickname, u.avatar as u_avatar, u.id as uid
        FROM comments r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = {$c['id']} AND r.status = 1
        ORDER BY r.created_at ASC
    ")->fetchAll();
}
unset($c);

$imgClass = count($imgs) === 1 ? 'single' : (count($imgs) === 2 ? 'double' : (count($imgs) >= 3 ? 'triple' : ''));
?>

<div class="app-header">
    <div class="header-inner">
        <a href="index.php?page=tieba&id=<?= $post['tieba_id'] ?>" class="icon-btn"><i class="fa fa-angle-left"></i></a>
        <h1 class="app-title" style="font-size:16px;flex:1;text-align:center;">帖子详情</h1>
        <a href="index.php?page=tieba&id=<?= $post['tieba_id'] ?>" class="icon-btn"><i class="fa fa-tree"></i></a>
    </div>
</div>

<!-- 帖子主体 -->
<div class="post-card" style="margin:12px 16px;">
    <!-- 作者 -->
    <div class="post-header">
        <a href="index.php?page=user&id=<?= $post['uid'] ?>">
            <img src="<?= e(avatar(['id'=>$post['uid'],'avatar'=>$post['u_avatar'],'nickname'=>$post['nickname']])) ?>" class="post-avatar">
        </a>
        <div class="post-user">
            <div class="post-nick"><?= e($post['nickname']) ?></div>
            <div class="post-time"><?= time_ago($post['created_at']) ?> · 来自 <a href="index.php?page=tieba&id=<?= $post['tieba_id'] ?>" style="color:var(--primary);"><?= e($post['tieba_name']) ?></a></div>
        </div>
        <?php if ($user && $user['id'] != $post['uid']): ?>
            <button class="btn <?= $isFollowingAuthor ? 'btn-ghost' : 'btn-primary' ?>" style="padding:6px 14px;font-size:12px;" onclick="followUser(<?= $post['uid'] ?>, this)">
                <i class="fa fa-<?= $isFollowingAuthor ? 'check' : 'plus' ?>"></i> <?= $isFollowingAuthor ? '已关注' : '关注' ?>
            </button>
        <?php endif; ?>
    </div>

    <!-- 标题 -->
    <?php if ($post['title']): ?>
        <h1 style="font-size:18px;font-weight:700;margin-bottom:12px;line-height:1.4;"><?= e($post['title']) ?></h1>
    <?php endif; ?>

    <!-- 内容 -->
    <div style="font-size:15px;line-height:1.8;color:var(--text);margin-bottom:14px;"><?= nl2br(e($post['content'])) ?></div>

    <!-- 图片 -->
    <?php if (!empty($imgs)): ?>
        <div class="post-images <?= $imgClass ?>" style="margin-bottom:14px;">
            <?php foreach (array_slice($imgs, 0, 9) as $img): ?>
                <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')">
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- 视频 -->
    <?php if ($post['video']): ?>
        <div class="post-video" style="margin-bottom:14px;">
            <video src="<?= e($post['video']) ?>" controls preload="metadata"></video>
        </div>
    <?php endif; ?>

    <!-- 统计 -->
    <div style="display:flex;gap:16px;font-size:12px;color:var(--text-light);padding-top:12px;border-top:1px solid var(--border);">
        <span><i class="fa fa-eye"></i> <?= $post['views'] ?> 浏览</span>
        <span><i class="fa fa-clock-o"></i> <?= date('Y-m-d H:i', strtotime($post['created_at'])) ?></span>
    </div>
</div>

<!-- 互动栏 -->
<div class="card" style="margin:0 16px 12px;display:flex;justify-content:space-around;padding:12px;">
    <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $postId ?>, this)" style="font-size:15px;">
        <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i>
        <span class="count"><?= $post['likes'] ?></span> 赞
    </div>
    <div class="post-action" style="font-size:15px;"><i class="fa fa-comment-o"></i> <?= $post['comments'] ?> 评论</div>
    <div class="post-action <?= $favorited?'favorited':'' ?>" onclick="favoritePost(<?= $postId ?>, this)" style="font-size:15px;">
        <i class="fa <?= $favorited?'fa-bookmark':'fa-bookmark-o' ?>"></i>
        <span class="count"><?= $post['favorites'] ?? 0 ?></span> 收藏
    </div>
    <div class="post-action" onclick="toast('已分享~')" style="font-size:15px;"><i class="fa fa-share-alt"></i> 分享</div>
    <?php if ($user && ($user['id'] == $post['uid'] || $user['role'] === 'admin')): ?>
    <div class="post-action" onclick="deletePost(<?= $postId ?>, 'index.php')" style="font-size:15px;color:#ef4444;">
        <i class="fa fa-trash-o"></i> 删除
    </div>
    <?php endif; ?>
</div>

<!-- 评论区 -->
<div class="section-title">
    <span><i class="fa fa-comments text-primary mr-1"></i>评论 (<?= $post['comments'] ?>)</span>
</div>

<?php if (empty($comments)): ?>
    <div class="empty" style="padding:30px;">
        <i class="fa fa-comment-o"></i>
        <p>还没有评论，快来抢沙发吧 ~</p>
    </div>
<?php else: ?>
    <div style="padding:0 16px;">
        <?php foreach ($comments as $c): ?>
            <div style="display:flex;gap:10px;padding:12px 0;border-bottom:1px solid var(--border);">
                <a href="index.php?page=user&id=<?= $c['uid'] ?>">
                    <img src="<?= e(avatar(['id'=>$c['uid'],'avatar'=>$c['u_avatar'],'nickname'=>$c['nickname']])) ?>" class="avatar-sm">
                </a>
                <div style="flex:1;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="font-size:13px;font-weight:600;"><?= e($c['nickname']) ?></span>
                        <span class="text-xs text-light"><?= time_ago($c['created_at']) ?></span>
                    </div>
                    <div style="font-size:14px;margin-top:4px;line-height:1.6;"><?= nl2br(e($c['content'])) ?></div>
                    <div style="display:flex;gap:12px;margin-top:6px;font-size:12px;color:var(--text-light);">
                        <span><i class="fa fa-thumbs-o-up"></i> <?= $c['likes'] ?></span>
                        <span onclick="document.getElementById('comment-input').focus();toast('回复功能开发中~')" style="cursor:pointer;"><i class="fa fa-reply"></i> 回复</span>
                    </div>
                    <!-- 楼中楼回复 -->
                    <?php if (!empty($c['replies'])): ?>
                        <div style="margin-top:8px;background:var(--bg-soft);border-radius:12px;padding:10px;">
                            <?php foreach ($c['replies'] as $r): ?>
                                <div style="font-size:13px;margin-bottom:6px;">
                                    <span style="color:var(--primary);font-weight:500;"><?= e($r['nickname']) ?>：</span>
                                    <?= e($r['content']) ?>
                                    <span class="text-xs text-light ml-2"><?= time_ago($r['created_at']) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- 评论输入框 -->
<?php if ($user): ?>
<div class="comment-bar">
    <input id="comment-input" class="form-input" style="flex:1;padding:10px 14px;" placeholder="说点什么吧..." onkeydown="if(event.key==='Enter')submitComment(<?= $postId ?>)">
    <button class="btn btn-primary" style="padding:10px 16px;" onclick="submitComment(<?= $postId ?>)">
        <i class="fa fa-paper-plane"></i>
    </button>
</div>
<?php else: ?>
<div class="comment-bar" style="justify-content:center;">
    <a href="index.php?page=login" class="btn btn-primary"><i class="fa fa-sign-in"></i> 登录后评论</a>
</div>
<?php endif; ?>

<!-- app.js 已在页头引入，无需重复加载 -->
</body>
</html>
