<?php
/**
 * 隐私设置页
 */
$pageTitle = '隐私设置';
$currentPage = 'profile';
include __DIR__ . '/../includes/header.php';

if (!$user) { header('Location: index.php?page=login'); exit; }

$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $privacyPosts     = $_POST['privacy_posts'] === 'private' ? 'private' : 'public';
    $privacyFollowing = $_POST['privacy_following'] === 'private' ? 'private' : 'public';
    $privacyFollowers = $_POST['privacy_followers'] === 'private' ? 'private' : 'public';
    $privacyTiebas    = $_POST['privacy_tiebas'] === 'private' ? 'private' : 'public';

    $stmt = db()->prepare("UPDATE users SET privacy_posts=?, privacy_following=?, privacy_followers=?, privacy_tiebas=? WHERE id=?");
    $stmt->execute([$privacyPosts, $privacyFollowing, $privacyFollowers, $privacyTiebas, $user['id']]);

    $msg = '隐私设置已保存';
    $user = current_user(); // 刷新
}

// 读取当前设置
$pPosts     = $user['privacy_posts'] ?? 'public';
$pFollowing = $user['privacy_following'] ?? 'public';
$pFollowers = $user['privacy_followers'] ?? 'public';
$pTiebas    = $user['privacy_tiebas'] ?? 'public';
?>

<div class="app-header">
    <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-chevron-left"></i></a>
    <h1 class="app-title" style="font-size:18px;">隐私设置</h1>
    
</div>

<?php if ($msg): ?>
<div class="toast-<?= $msgType ?>" style="margin:12px 16px;padding:12px;border-radius:12px;text-align:center;background:<?= $msgType==='success'?'#dcfce7':'#fee2e2' ?>;color:<?= $msgType==='success'?'#166534':'#991b1b' ?>;">
    <i class="fa fa-<?= $msgType==='success'?'check-circle':'exclamation-circle' ?>"></i> <?= e($msg) ?>
</div>
<?php endif; ?>

<form method="post" style="padding:0 16px;">
    <div class="card" style="padding:0;overflow:hidden;">
        <?php
        $privacyItems = [
            ['privacy_posts',     'file-text-o', '我的动态', '控制其他用户是否可以查看你发布的帖子', $pPosts],
            ['privacy_following', 'user-plus',   '我的关注', '控制其他用户是否可以查看你关注的人',   $pFollowing],
            ['privacy_followers', 'users',       '我的粉丝', '控制其他用户是否可以查看你的粉丝列表', $pFollowers],
            ['privacy_tiebas',    'th',          '我的贴吧', '控制其他用户是否可以查看你加入的贴吧', $pTiebas],
        ];
        foreach ($privacyItems as $i => $item):
            list($field, $icon, $title, $desc, $val) = $item;
            $isLast = ($i === count($privacyItems) - 1);
        ?>
        <div style="padding:16px;<?= $isLast?'':'border-bottom:1px solid var(--border);' ?>">
            <div style="font-size:14px;font-weight:600;color:var(--text);display:flex;align-items:center;gap:8px;">
                <i class="fa fa-<?= $icon ?> text-primary"></i> <?= $title ?>
            </div>
            <div style="font-size:12px;color:var(--text-soft);margin:6px 0 12px;"><?= $desc ?></div>
            <div class="seg-switch">
                <input type="radio" name="<?= $field ?>" value="public"  <?= $val==='public' ?'checked':'' ?> id="<?= $field ?>_public">
                <input type="radio" name="<?= $field ?>" value="private" <?= $val==='private'?'checked':'' ?> id="<?= $field ?>_private">
                <label for="<?= $field ?>_public"><i class="fa fa-globe"></i> 公开</label>
                <label for="<?= $field ?>_private"><i class="fa fa-lock"></i> 仅自己</label>
                <div class="seg-slider"></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div style="margin:16px 0;">
        <div class="card" style="padding:12px;font-size:12px;color:var(--text-soft);line-height:1.8;">
            <i class="fa fa-info-circle text-primary"></i> 设为"仅自己"后，其他用户访问你的主页时将无法看到对应内容，但你本人仍可正常查看。
        </div>
    </div>

    <button type="submit" class="btn btn-primary btn-block" style="padding:14px;">
        <i class="fa fa-save"></i> 保存隐私设置
    </button>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>
