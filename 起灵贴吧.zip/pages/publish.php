<?php
/**
 * 发布页 - 支持多图、视频、文案
 */
$pageTitle = '发布';
$currentPage = 'publish';
include __DIR__ . '/../includes/header.php';

$tiebas = db()->query("SELECT id, name, icon FROM tiebas ORDER BY members DESC")->fetchAll();
$selectedTieba = intval($_GET['tieba'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tiebaId = intval($_POST['tieba_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $type = $_POST['type'] ?? 'text';
    $uploadError = '';

    if ($tiebaId <= 0) { $uploadError = '请选择贴吧'; }
    else if (!$content && empty($_FILES['images']['name'][0]) && empty($_FILES['video']['name'])) { $uploadError = '说点什么吧~'; }
    else {
        // 处理图片
        $images = [];
        $imgErrors = [];
        if (!empty($_FILES['images']['name'][0])) {
            foreach ($_FILES['images']['name'] as $i => $name) {
                if ($_FILES['images']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $file = [
                    'name' => $name,
                    'type' => $_FILES['images']['type'][$i],
                    'tmp_name' => $_FILES['images']['tmp_name'][$i],
                    'error' => $_FILES['images']['error'][$i],
                    'size' => $_FILES['images']['size'][$i],
                ];
                $r = handle_upload($file, ['jpg','jpeg','png','gif','webp'], 10485760);
                if ($r['ok']) $images[] = $r['url'];
                else $imgErrors[] = $name . ': ' . $r['msg'];
            }
        }

        // 处理视频
        $video = '';
        $videoError = '';
        if (!empty($_FILES['video']['name'])) {
            $r = handle_upload($_FILES['video'], ['mp4','webm','mov'], 104857600);
            if ($r['ok']) $video = $r['url'];
            else $videoError = $r['msg'];
        }

        if (!empty($imgErrors)) {
            $uploadError = '图片上传失败: ' . implode('; ', array_slice($imgErrors, 0, 2));
        } elseif ($videoError) {
            $uploadError = '视频上传失败: ' . $videoError;
        } else {
            if ($video) $type = 'video';
            elseif (!empty($images)) $type = 'image';

            $imagesJson = json_encode($images);
            $stmt = db()->prepare("INSERT INTO posts (user_id, tieba_id, title, content, images, video, type, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->execute([$user['id'], $tiebaId, $title, $content, $imagesJson, $video, $type]);

            db()->exec("UPDATE tiebas SET posts = posts + 1 WHERE id = {$tiebaId}");
            db()->exec("UPDATE users SET posts = posts + 1 WHERE id = {$user['id']}");

            header('Location: index.php?page=post&id=' . db()->lastInsertId());
            exit;
        }
    }
}
?>

<div class="app-header">
    <div class="header-inner">
        <a href="index.php" class="icon-btn"><i class="fa fa-angle-left"></i></a>
        <h1 class="app-title" style="font-size:17px;">发布动态</h1>
        <button type="submit" form="publish-form" class="btn btn-primary" style="padding:6px 16px;font-size:13px;">
            <i class="fa fa-paper-plane"></i> 发布
        </button>
    </div>
</div>

<?php if (!empty($uploadError)): ?>
<div style="margin:12px 16px;padding:12px 16px;background:#fef2f2;border:1px solid #fecaca;color:#dc2626;border-radius:12px;font-size:13px;">
    <i class="fa fa-exclamation-circle"></i> <?= e($uploadError) ?>
</div>
<?php endif; ?>

<?php
$up = upload_check();
?>

<form id="publish-form" method="post" enctype="multipart/form-data" style="padding:16px;">
    <!-- 选择贴吧 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-tag text-primary"></i> 选择贴吧</label>
        <select name="tieba_id" class="form-select" required>
            <option value="">请选择要发布到的贴吧...</option>
            <?php foreach ($tiebas as $t): ?>
                <option value="<?= $t['id'] ?>" <?= $selectedTieba==$t['id']?'selected':'' ?>><i class="fa fa-<?= e($t['icon']) ?>"></i> <?= e($t['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- 标题 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-font text-primary"></i> 标题（可选）</label>
        <input name="title" class="form-input" maxlength="100" placeholder="给你的树洞起个名字...">
    </div>

    <!-- 内容 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-pencil text-primary"></i> 内容</label>
        <textarea name="content" class="form-textarea" placeholder="在这里写下你的心情、故事、想说的话... 🌳" required></textarea>
    </div>

    <!-- 图片上传 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-image text-primary"></i> 图片（最多9张）</label>
        <input type="file" name="images[]" id="image-input" accept="image/*" multiple style="display:none;">
        <div id="image-preview" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">
            <label for="image-input" class="upload-add-btn" style="aspect-ratio:1;border:2px dashed var(--border);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;color:var(--text-light);transition:all .3s;background:rgba(255,255,255,0.5);">
                <i class="fa fa-plus text-2xl"></i>
                <span class="text-xs mt-1">添加图片</span>
            </label>
        </div>
    </div>

    <!-- 视频上传 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-video-camera text-primary"></i> 视频（可选）</label>
        <input type="file" name="video" id="video-input" accept="video/*" style="display:none;">
        <label for="video-input" id="video-upload-label" style="display:block;border:2px dashed var(--border);border-radius:12px;padding:20px;text-align:center;cursor:pointer;color:var(--text-light);transition:all .3s;background:rgba(255,255,255,0.5);">
            <i class="fa fa-film text-2xl"></i>
            <div class="text-sm mt-2" id="video-name">点击上传视频</div>
        </label>
        <div id="video-preview" style="display:none;margin-top:8px;border-radius:12px;overflow:hidden;position:relative;">
            <video id="video-preview-el" style="width:100%;max-height:240px;object-fit:cover;background:#000;" controls></video>
            <button type="button" id="video-remove-btn" style="position:absolute;top:8px;right:8px;width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,0.6);color:white;border:none;cursor:pointer;font-size:16px;">×</button>
        </div>
    </div>

    <!-- 话题/表情 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-smile-o text-primary"></i> 表情</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:20px;">
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌳'">🌳</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌸'">🌸</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' ☀️'">☀️</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌙'">🌙</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 💭'">💭</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🤍'">🤍</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🦋'">🦋</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🍃'">🍃</span>
        </div>
    </div>

    <p class="text-xs text-light text-center mt-4">
        <i class="fa fa-shield"></i> 发布即代表遵守社区规范，请勿发布违规内容
    </p>
    <p class="text-xs text-light text-center mt-2">
        <i class="fa fa-info-circle"></i> 服务器限制：单图 <?= $up['upload_max_filesize'] ?> | 单视频 100MB | 单次最多 <?= $up['max_file_uploads'] ?> 个文件
    </p>
</form>

<script>
setupImageUpload('image-input', 'image-preview', 9);

// 视频预览与删除
const videoInput = document.getElementById('video-input');
const videoPreview = document.getElementById('video-preview');
const videoPreviewEl = document.getElementById('video-preview-el');
const videoRemoveBtn = document.getElementById('video-remove-btn');
const videoUploadLabel = document.getElementById('video-upload-label');
const videoName = document.getElementById('video-name');

videoInput.addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const url = URL.createObjectURL(this.files[0]);
        videoPreviewEl.src = url;
        videoPreview.style.display = 'block';
        videoUploadLabel.style.display = 'none';
        videoName.textContent = this.files[0].name;
    }
});
videoRemoveBtn.addEventListener('click', function() {
    videoInput.value = '';
    videoPreviewEl.src = '';
    videoPreview.style.display = 'none';
    videoUploadLabel.style.display = 'block';
    videoName.textContent = '点击上传视频';
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
