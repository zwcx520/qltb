<?php
/**
 * 发布页 - 支持多图、视频、文案
 */
$pageTitle = '发布';
$currentPage = 'publish';
include __DIR__ . '/../includes/header.php';

$selectedTieba = intval($_GET['tieba'] ?? 0);
$targetTieba = null; // 指定贴吧模式（从贴吧详情页悬浮按钮进入）
$myTiebas = [];      // 通用模式（底部导航进入）：只列自己创建的贴吧

if ($selectedTieba) {
    $stmt = db()->prepare("SELECT id, name, icon FROM tiebas WHERE id = ?");
    $stmt->execute([$selectedTieba]);
    $targetTieba = $stmt->fetch();
    if (!$targetTieba) $selectedTieba = 0; // 贴吧不存在则退回通用模式
}
if (!$selectedTieba) {
    $stmt = db()->prepare("SELECT id, name, icon FROM tiebas WHERE owner_id = ? ORDER BY id DESC");
    $stmt->execute([$user['id']]);
    $myTiebas = $stmt->fetchAll();
}

// 是否有可发布的贴吧
$canPublish = $selectedTieba > 0 || !empty($myTiebas);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tiebaId = intval($_POST['tieba_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $type = $_POST['type'] ?? 'text';
    $uploadError = '';

    // 1) 贴吧归属校验（防止伪造POST发布到任意贴吧）
    if ($tiebaId <= 0) {
        $uploadError = $selectedTieba ? '贴吧信息缺失，请从贴吧页面重新进入' : '请选择贴吧';
    } else {
        $stmt = db()->prepare("SELECT id, owner_id FROM tiebas WHERE id = ?");
        $stmt->execute([$tiebaId]);
        $tiebaRow = $stmt->fetch();
        if (!$tiebaRow) {
            $uploadError = '贴吧不存在或已被删除';
        } elseif ($selectedTieba && $tiebaId != $selectedTieba) {
            $uploadError = '请发布到对应的贴吧';
        } elseif (!$selectedTieba && (int)$tiebaRow['owner_id'] !== (int)$user['id']) {
            $uploadError = '从底部导航只能发布到自己创建的贴吧；请到对应贴吧内点击右下角悬浮按钮发布';
        }
    }

    // 2) 内容校验
    if (!$uploadError && !$content && empty($_FILES['images']['name'][0]) && empty($_FILES['video']['name'])) {
        $uploadError = '说点什么吧~';
    }

    // 3) 处理上传与入库
    if (!$uploadError) {
        // 处理图片
        $images = [];
        $imgErrors = [];
        if (!empty($_FILES['images']['name'][0])) {
            foreach ($_FILES['images']['name'] as $i => $name) {
                if ($_FILES['images']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $file = [
                    'name' => $name,
                    'type' => $_FILES['images']['type'][$i],
                    'tmp_name' => $_FILES['images']['tmp_name'][$i],
                    'error' => $_FILES['images']['error'][$i],
                    'size' => $_FILES['images']['size'][$i],
                ];
                $r = handle_upload($file, ['jpg','jpeg','png','gif','webp'], 10485760);
                if ($r['ok']) $images[] = $r['url'];
                else $imgErrors[] = $name . ': ' . $r['msg'];
            }
        }

        // 处理视频
        $video = '';
        $videoError = '';
        if (!empty($_FILES['video']['name'])) {
            $r = handle_upload($_FILES['video'], ['mp4','webm','mov'], 104857600);
            if ($r['ok']) $video = $r['url'];
            else $videoError = $r['msg'];
        }

        if (!empty($imgErrors)) {
            $uploadError = '图片上传失败: ' . implode('; ', array_slice($imgErrors, 0, 2));
        } elseif ($videoError) {
            $uploadError = '视频上传失败: ' . $videoError;
        } else {
            if ($video) $type = 'video';
            elseif (!empty($images)) $type = 'image';

            $imagesJson = json_encode($images);
            $stmt = db()->prepare("INSERT INTO posts (user_id, tieba_id, title, content, images, video, type, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
            $stmt->execute([$user['id'], $tiebaId, $title, $content, $imagesJson, $video, $type]);

            db()->exec("UPDATE tiebas SET posts = posts + 1 WHERE id = {$tiebaId}");
            db()->exec("UPDATE users SET posts = posts + 1 WHERE id = {$user['id']}");

            // 检查是否达到 100 级（2000 帖），自动升级为管理员
            check_level_up($user['id']);

            header('Location: index.php?page=post&id=' . db()->lastInsertId());
            exit;
        }
    }
}
?>

<div class="app-header">
    <div class="header-inner">
        <a href="<?= $selectedTieba ? 'index.php?page=tieba&id='.$selectedTieba : 'index.php' ?>" class="icon-btn"><i class="fa fa-angle-left"></i></a>
        <h1 class="app-title" style="font-size:17px;">发布动态</h1>
        <?php if ($canPublish): ?>
        <button type="submit" form="publish-form" class="btn btn-primary" style="padding:6px 16px;font-size:13px;">
            <i class="fa fa-paper-plane"></i> 发布
        </button>
        <?php else: ?>
        <span style="width:64px;"></span>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($uploadError)): ?>
<div style="margin:12px 16px;padding:12px 16px;background:#fef2f2;border:1px solid #fecaca;color:#dc2626;border-radius:12px;font-size:13px;">
    <i class="fa fa-exclamation-circle"></i> <?= e($uploadError) ?>
</div>
<?php endif; ?>

<?php
$up = upload_check();
?>

<?php if ($canPublish): ?>
<form id="publish-form" method="post" enctype="multipart/form-data" style="padding:16px;">
    <!-- 贴吧：指定模式锁定显示 / 通用模式只能选自己创建的贴吧 -->
    <?php if ($selectedTieba): ?>
    <div class="form-group">
        <label class="form-label"><i class="fa fa-bullhorn text-primary"></i> 发布到贴吧</label>
        <div style="display:flex;align-items:center;gap:10px;padding:14px 16px;border-radius:14px;background:linear-gradient(135deg,#ec4899,#a855f7);color:white;box-shadow:0 6px 16px rgba(236,72,153,0.3);">
            <span style="width:38px;height:38px;border-radius:11px;background:rgba(255,255,255,0.22);display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;">
                <i class="fa fa-<?= e($targetTieba['icon'] ?: 'tree') ?>"></i>
            </span>
            <div style="flex:1;min-width:0;">
                <div style="font-weight:600;font-size:15px;"><?= e($targetTieba['name']) ?></div>
                <div style="font-size:11px;opacity:0.85;margin-top:2px;">动态将直接发布到本贴吧，无需再选择</div>
            </div>
            <i class="fa fa-lock" style="opacity:0.75;"></i>
        </div>
        <input type="hidden" name="tieba_id" value="<?= $selectedTieba ?>">
    </div>
    <?php else: ?>
    <div class="form-group">
        <label class="form-label"><i class="fa fa-tag text-primary"></i> 选择我创建的贴吧</label>
        <select name="tieba_id" class="form-select" required>
            <option value="">请选择要发布到的贴吧...</option>
            <?php foreach ($myTiebas as $t): ?>
                <option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <small style="display:block;color:var(--text-light);font-size:12px;margin-top:6px;line-height:1.7;">
            <i class="fa fa-info-circle"></i> 从这里发布仅限自己创建的贴吧；想在其他贴吧发帖，请进入对应贴吧后点击右下角悬浮 + 按钮
        </small>
    </div>
    <?php endif; ?>

    <!-- 标题 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-font text-primary"></i> 标题（可选）</label>
        <input name="title" class="form-input" maxlength="100" placeholder="给你的树洞起个名字...">
    </div>

    <!-- 内容 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-pencil text-primary"></i> 内容</label>
        <textarea name="content" class="form-textarea" placeholder="在这里写下你的心情、故事、想说的话... 🌳" required></textarea>
    </div>

    <!-- 图片上传 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-image text-primary"></i> 图片（最多9张）</label>
        <input type="file" name="images[]" id="image-input" accept="image/*" multiple style="display:none;">
        <div id="image-preview" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">
            <label for="image-input" class="upload-add-btn" style="aspect-ratio:1;border:2px dashed var(--border);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;color:var(--text-light);transition:all .3s;background:rgba(255,255,255,0.5);">
                <i class="fa fa-plus text-2xl"></i>
                <span class="text-xs mt-1">添加图片</span>
            </label>
        </div>
    </div>

    <!-- 视频上传 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-video-camera text-primary"></i> 视频（可选）</label>
        <input type="file" name="video" id="video-input" accept="video/*" style="display:none;">
        <label for="video-input" id="video-upload-label" style="display:block;border:2px dashed var(--border);border-radius:12px;padding:20px;text-align:center;cursor:pointer;color:var(--text-light);transition:all .3s;background:rgba(255,255,255,0.5);">
            <i class="fa fa-film text-2xl"></i>
            <div class="text-sm mt-2" id="video-name">点击上传视频</div>
        </label>
        <div id="video-preview" style="display:none;margin-top:8px;border-radius:12px;overflow:hidden;position:relative;">
            <video id="video-preview-el" style="width:100%;max-height:240px;object-fit:cover;background:#000;" controls></video>
            <button type="button" id="video-remove-btn" style="position:absolute;top:8px;right:8px;width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,0.6);color:white;border:none;cursor:pointer;font-size:16px;">×</button>
        </div>
    </div>

    <!-- 话题/表情 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-smile-o text-primary"></i> 表情</label>
        <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:20px;">
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌳'">🌳</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌸'">🌸</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' ☀️'">☀️</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🌙'">🌙</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 💭'">💭</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🤍'">🤍</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🦋'">🦋</span>
            <span style="cursor:pointer;" onclick="document.querySelector('[name=content]').value+=' 🍃'">🍃</span>
        </div>
    </div>

    <p class="text-xs text-light text-center mt-4">
        <i class="fa fa-shield"></i> 发布即代表遵守社区规范，请勿发布违规内容
    </p>
    <p class="text-xs text-light text-center mt-2">
        <i class="fa fa-info-circle"></i> 服务器限制：单图 <?= $up['upload_max_filesize'] ?> | 单视频 100MB | 单次最多 <?= $up['max_file_uploads'] ?> 个文件
    </p>
</form>

<script>
setupImageUpload('image-input', 'image-preview', 9);

// 视频预览与删除
const videoInput = document.getElementById('video-input');
const videoPreview = document.getElementById('video-preview');
const videoPreviewEl = document.getElementById('video-preview-el');
const videoRemoveBtn = document.getElementById('video-remove-btn');
const videoUploadLabel = document.getElementById('video-upload-label');
const videoName = document.getElementById('video-name');

videoInput.addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const url = URL.createObjectURL(this.files[0]);
        videoPreviewEl.src = url;
        videoPreview.style.display = 'block';
        videoUploadLabel.style.display = 'none';
        videoName.textContent = this.files[0].name;
    }
});
videoRemoveBtn.addEventListener('click', function() {
    videoInput.value = '';
    videoPreviewEl.src = '';
    videoPreview.style.display = 'none';
    videoUploadLabel.style.display = 'block';
    videoName.textContent = '点击上传视频';
});
</script>
<?php else: ?>
<!-- 没有创建任何贴吧时的引导 -->
<div style="padding:70px 28px;text-align:center;">
    <div style="width:84px;height:84px;margin:0 auto;border-radius:28px;background:linear-gradient(135deg,#fce7f3,#ede9fe);display:flex;align-items:center;justify-content:center;font-size:36px;color:var(--primary);box-shadow:0 8px 24px rgba(236,72,153,0.15);">
        <i class="fa fa-tree"></i>
    </div>
    <p style="font-size:16px;font-weight:600;margin-top:20px;">你还没有创建贴吧</p>
    <p style="font-size:13px;color:var(--text-light);margin-top:10px;line-height:1.9;">
        从底部导航发布，仅限自己创建的贴吧哦~<br>
        想在其他贴吧发帖，请先进入对应贴吧，<br>点击右下角悬浮 <strong style="color:var(--primary);">+</strong> 按钮就能直接发布啦
    </p>
    <a href="index.php?page=discover" class="btn btn-primary" style="margin-top:22px;padding:10px 22px;">
        <i class="fa fa-compass"></i> 去创建自己的贴吧
    </a>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
