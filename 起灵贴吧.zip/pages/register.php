<?php
/**
 * 注册页
 */
$pageTitle = '注册';
$currentPage = 'register';
include __DIR__ . '/../includes/header.php';

$error = '';
$registerOpen = intval($settings['allow_register'] ?? 1) === 1;

// 注册关闭时，拒绝所有 POST 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$registerOpen) {
    $error = '站长已关闭注册功能';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (strlen($username) < 3) $error = '用户名至少3个字符';
    elseif (strlen($password) < 6) $error = '密码至少6个字符';
    elseif ($password !== $confirm) $error = '两次密码不一致';
    else {
        $stmt = db()->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) $error = '用户名已被使用';
        else {
            $hash = hash_password($password);
            $stmt = db()->prepare("INSERT INTO users (username, password, nickname, email, role, created_at) VALUES (?, ?, ?, ?, 'user', NOW())");
            $stmt->execute([$username, $hash, $nickname ?: $username, $email]);
            $_SESSION['uid'] = db()->lastInsertId();
            header('Location: index.php');
            exit;
        }
    }
}
?>

<div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;">
    <div style="text-align:center;margin-bottom:30px;">
        <div style="width:70px;height:70px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,#a855f7,#ec4899);display:flex;align-items:center;justify-content:center;box-shadow:0 10px 30px rgba(168,85,247,0.3);">
            <i class="fa fa-star text-white text-2xl"></i>
        </div>
        <h1 style="font-size:24px;font-weight:700;background:linear-gradient(135deg,#a855f7,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-top:14px;">加入起灵贴吧</h1>
        <p style="color:var(--text-soft);margin-top:6px;font-size:13px;">在这里，每一份情绪都被温柔以待 🌸</p>
    </div>

    <?php if ($error): ?>
        <div style="background:#fef2f2;border:1px solid #fecaca;color:#dc2626;padding:10px 16px;border-radius:12px;font-size:13px;margin-bottom:16px;width:100%;max-width:340px;text-align:center;">
            <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
        </div>
    <?php endif; ?>

    <?php if (!$registerOpen): ?>
        <!-- 注册已关闭 -->
        <div style="width:100%;max-width:340px;text-align:center;padding:40px 20px;background:rgba(255,255,255,0.6);border-radius:20px;backdrop-filter:blur(10px);">
            <div style="width:60px;height:60px;margin:0 auto;border-radius:50%;background:#fee2e2;color:#dc2626;display:flex;align-items:center;justify-content:center;">
                <i class="fa fa-lock text-2xl"></i>
            </div>
            <h3 style="font-size:16px;font-weight:600;margin-top:16px;color:var(--text);">注册功能已关闭</h3>
            <p style="font-size:13px;color:var(--text-soft);margin-top:8px;line-height:1.6;">管理员已暂时关闭新用户注册<br>如有疑问请联系站方</p>
            <a href="index.php?page=login" class="btn btn-primary" style="margin-top:18px;width:100%;">
                <i class="fa fa-sign-in"></i> 去登录
            </a>
        </div>
    <?php else: ?>
    <form method="post" style="width:100%;max-width:340px;">
        <div class="form-group">
            <label class="form-label"><i class="fa fa-user text-primary"></i> 用户名</label>
            <input name="username" class="form-input" placeholder="3-20个字符" required minlength="3" maxlength="20">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-smile-o text-primary"></i> 昵称</label>
            <input name="nickname" class="form-input" placeholder="给自己起个好听的名字">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-envelope text-primary"></i> 邮箱（可选）</label>
            <input name="email" type="email" class="form-input" placeholder="用于找回密码">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock text-primary"></i> 密码</label>
            <input name="password" type="password" class="form-input" placeholder="至少6个字符" required minlength="6">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock text-primary"></i> 确认密码</label>
            <input name="confirm" type="password" class="form-input" placeholder="再次输入密码" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block" style="padding:14px;font-size:15px;margin-top:8px;">
            <i class="fa fa-heart"></i> 注 册
        </button>
    </form>
    <?php endif; ?>

    <div style="margin-top:24px;text-align:center;">
        <p style="font-size:13px;color:var(--text-soft);">
            已有账号？
            <a href="index.php?page=login" style="color:var(--primary);font-weight:500;">去登录</a>
        </p>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
