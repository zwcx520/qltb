<?php
/**
 * 社区规范
 */
$pageTitle = '社区规范';
$currentPage = 'rules';
include __DIR__ . '/../includes/header.php';
?>

<div style="min-height:100vh;display:flex;flex-direction:column;padding:0;">
    <!-- 顶部导航 -->
    <div style="display:flex;align-items:center;padding:14px 16px;background:white;border-bottom:1px solid var(--border);">
        <a href="index.php?page=profile" class="icon-btn" style="background:var(--bg);"><i class="fa fa-angle-left"></i></a>
        <span style="flex:1;text-align:center;font-size:16px;font-weight:600;">社区规范</span>
        <span style="width:36px;"></span>
    </div>

    <div style="padding:20px 16px;flex:1;">
        <!-- 头部说明 -->
        <div style="background:linear-gradient(135deg,#d1fae5 0%,#a7f3d0 100%);border-radius:16px;padding:18px;margin-bottom:20px;">
            <div style="display:flex;align-items:center;gap:10px;">
                <div style="width:42px;height:42px;border-radius:12px;background:rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;">
                    <i class="fa fa-shield text-xl" style="color:#059669;"></i>
                </div>
                <div>
                    <div style="font-size:15px;font-weight:600;color:var(--text);">社区公约</div>
                    <div style="font-size:12px;color:var(--text-soft);margin-top:2px;">共同维护温暖友好的社区环境</div>
                </div>
            </div>
        </div>

        <!-- 一、基本原则 -->
        <div style="background:white;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <h3 style="font-size:15px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
                <span style="width:24px;height:24px;border-radius:8px;background:#ec4899;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;">1</span>
                基本原则
            </h3>
            <ul style="font-size:13px;color:var(--text-soft);line-height:2;padding-left:4px;list-style:none;">
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>尊重每一位成员，友善交流，理性讨论</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>保护个人隐私，不泄露他人信息</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>鼓励原创，分享真实的想法与经历</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>珍惜社区氛围，共同建设美好家园</span></li>
            </ul>
        </div>

        <!-- 二、发帖规范 -->
        <div style="background:white;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <h3 style="font-size:15px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
                <span style="width:24px;height:24px;border-radius:8px;background:#a855f7;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;">2</span>
                发帖规范
            </h3>
            <ul style="font-size:13px;color:var(--text-soft);line-height:2;padding-left:4px;list-style:none;">
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>发布内容应与贴吧主题相关</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>标题清晰，内容完整，表达真实</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>图片、视频内容健康向上</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>禁止发布广告、推广、引流信息</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-check-circle" style="color:#10b981;margin-top:5px;"></i><span>禁止重复发帖、刷屏、恶意灌水</span></li>
            </ul>
        </div>

        <!-- 三、禁止行为 -->
        <div style="background:white;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <h3 style="font-size:15px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
                <span style="width:24px;height:24px;border-radius:8px;background:#ef4444;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;">3</span>
                禁止行为
            </h3>
            <ul style="font-size:13px;color:var(--text-soft);line-height:2;padding-left:4px;list-style:none;">
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>发布违法、违规、涉政敏感内容</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>传播色情、暴力、恐怖、血腥内容</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>辱骂、攻击、人身攻击他人</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>侵犯他人著作权、肖像权、隐私权</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>诱导、诈骗、传销等违法行为</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-times-circle" style="color:#ef4444;margin-top:5px;"></i><span>发布虚假信息、造谣传谣</span></li>
            </ul>
        </div>

        <!-- 四、违规处理 -->
        <div style="background:white;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <h3 style="font-size:15px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
                <span style="width:24px;height:24px;border-radius:8px;background:#f59e0b;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;">4</span>
                违规处理
            </h3>
            <div style="font-size:13px;color:var(--text-soft);line-height:2;">
                <p>违反社区规范的行为，将视情节轻重进行以下处理：</p>
                <div style="background:var(--bg);border-radius:10px;padding:12px;margin-top:8px;">
                    <div style="margin-bottom:6px;"><strong style="color:var(--text);">轻度违规：</strong>删除内容 + 警告提醒</div>
                    <div style="margin-bottom:6px;"><strong style="color:var(--text);">中度违规：</strong>删除内容 + 禁言 1-7 天</div>
                    <div><strong style="color:var(--text);">严重违规：</strong>永久封禁账号</div>
                </div>
            </div>
        </div>

        <!-- 五、举报方式 -->
        <div style="background:white;border-radius:16px;padding:18px;margin-bottom:16px;box-shadow:0 2px 12px rgba(0,0,0,0.04);">
            <h3 style="font-size:15px;font-weight:600;margin-bottom:12px;display:flex;align-items:center;gap:8px;">
                <span style="width:24px;height:24px;border-radius:8px;background:#3b82f6;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;">5</span>
                举报与申诉
            </h3>
            <ul style="font-size:13px;color:var(--text-soft);line-height:2;padding-left:4px;list-style:none;">
                <li style="display:flex;gap:8px;"><i class="fa fa-flag" style="color:#3b82f6;margin-top:5px;"></i><span>发现违规内容，可向站长举报</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-flag" style="color:#3b82f6;margin-top:5px;"></i><span>对处理结果有异议，可联系站长申诉</span></li>
                <li style="display:flex;gap:8px;"><i class="fa fa-flag" style="color:#3b82f6;margin-top:5px;"></i><span>举报时请提供相关证据，便于核实处理</span></li>
            </ul>
            <a href="index.php?page=contact" style="display:inline-flex;align-items:center;gap:6px;margin-top:12px;padding:8px 16px;background:#3b82f6;color:white;border-radius:10px;font-size:13px;font-weight:500;">
                <i class="fa fa-envelope"></i> 联系站长举报
            </a>
        </div>

        <p style="text-align:center;font-size:11px;color:var(--text-light);margin-top:24px;padding:0 20px;line-height:1.7;">
            本规范最终解释权归 <?= e($settings['site_name'] ?? '起灵贴吧') ?> 所有<br>
            感谢每一位成员的理解与配合 🌸
        </p>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
