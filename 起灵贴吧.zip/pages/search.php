<?php
/**
 * 搜索页
 */
$pageTitle = '搜索';
$currentPage = 'search';
include __DIR__ . '/../includes/header.php';

$kw = trim($_GET['kw'] ?? '');
$type = $_GET['type'] ?? 'post';

$results = [];
$hotKeywords = ['心情', '深夜', '治愈', '日常', '树洞', '温柔', '孤独', '希望'];

if ($kw) {
    if ($type === 'tieba') {
        $stmt = db()->prepare("SELECT * FROM tiebas WHERE name LIKE ? OR description LIKE ? ORDER BY members DESC LIMIT 20");
        $stmt->execute(["%{$kw}%", "%{$kw}%"]);
        $results = $stmt->fetchAll();
    } elseif ($type === 'user') {
        $stmt = db()->prepare("SELECT * FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 20");
        $stmt->execute(["%{$kw}%", "%{$kw}%"]);
        $results = $stmt->fetchAll();
    } else {
        $stmt = db()->prepare("
            SELECT p.*, u.nickname, u.avatar, t.name as tieba_name
            FROM posts p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN tiebas t ON p.tieba_id = t.id
            WHERE p.title LIKE ? OR p.content LIKE ?
            ORDER BY p.created_at DESC LIMIT 20
        ");
        $stmt->execute(["%{$kw}%", "%{$kw}%"]);
        $results = $stmt->fetchAll();
    }
}
?>

<div class="app-header">
    <div class="header-inner">
        <form action="index.php" method="get" class="search-bar w-full">
            <i class="fa fa-search text-light"></i>
            <input type="hidden" name="page" value="search">
            <input type="hidden" name="type" value="<?= $type ?>">
            <input type="text" name="kw" value="<?= e($kw) ?>" placeholder="搜索贴吧、帖子、用户..." autofocus>
            <?php if ($kw): ?><a href="index.php?page=search" style="color:var(--text-light);"><i class="fa fa-times"></i></a><?php endif; ?>
        </form>
    </div>
    <div style="display:flex;gap:8px;margin-top:10px;">
        <?php foreach (['post'=>'帖子','tieba'=>'贴吧','user'=>'用户'] as $k => $v): ?>
            <a href="index.php?page=search&type=<?= $k ?>&kw=<?= urlencode($kw) ?>" class="tag" style="background:<?= $type===$k?'linear-gradient(135deg,#ec4899,#a855f7)':'rgba(255,255,255,0.7)' ?>;color:<?= $type===$k?'white':'var(--text-soft)' ?>;"><?= $v ?></a>
        <?php endforeach; ?>
    </div>
</div>

<?php if (!$kw): ?>
    <div class="section-title"><span><i class="fa fa-fire text-primary"></i> 热门搜索</span></div>
    <div style="padding:0 16px;display:flex;gap:8px;flex-wrap:wrap;">
        <?php foreach ($hotKeywords as $k): ?>
            <a href="index.php?page=search&kw=<?= urlencode($k) ?>" class="tag" style="background:rgba(255,255,255,0.8);color:var(--text-soft);">
                <?= e($k) ?>
            </a>
        <?php endforeach; ?>
    </div>
<?php elseif (empty($results)): ?>
    <div class="empty">
        <i class="fa fa-search"></i>
        <p>没有找到"<?= e($kw) ?>"相关内容</p>
        <p class="text-xs text-light mt-1">换个关键词试试吧 ~</p>
    </div>
<?php else: ?>
    <div style="padding:8px 16px;font-size:13px;color:var(--text-soft);">共找到 <?= count($results) ?> 条结果</div>
    <?php if ($type === 'post'): foreach ($results as $r):
        $imgs = $r['images'] ? json_decode($r['images'], true) : [];
    ?>
        <a href="index.php?page=post&id=<?= $r['id'] ?>" class="post-card" style="display:block;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                <img src="<?= e(avatar(['id'=>$r['user_id'],'avatar'=>$r['avatar'],'nickname'=>$r['nickname']])) ?>" class="avatar-sm">
                <span style="font-size:13px;font-weight:500;"><?= e($r['nickname']) ?></span>
                <span class="tag" style="background:rgba(236,72,153,0.1);color:var(--primary);"><?= e($r['tieba_name']) ?></span>
            </div>
            <?php if ($r['title']): ?><div style="font-weight:600;margin-bottom:4px;"><?= e($r['title']) ?></div><?php endif; ?>
            <div class="text-sm text-soft" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?= e($r['content']) ?></div>
            <?php if (!empty($imgs)): ?>
                <div style="display:flex;gap:4px;margin-top:6px;">
                    <?php foreach (array_slice($imgs,0,3) as $img): ?>
                        <img src="<?= e($img) ?>" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </a>
    <?php endforeach; elseif ($type === 'tieba'): foreach ($results as $r): ?>
        <a href="index.php?page=tieba&id=<?= $r['id'] ?>" class="tieba-row">
            <div class="tieba-cover" style="background:<?= cover($r) ?>"><i class="fa fa-<?= e($r['icon'] ?: 'tree') ?>"></i></div>
            <div class="tieba-info">
                <div class="tieba-name"><?= e($r['name']) ?></div>
                <div class="tieba-desc"><?= e($r['description']) ?></div>
                <div class="tieba-meta"><i class="fa fa-users"></i> <?= $r['members'] ?> 成员</div>
            </div>
        </a>
    <?php endforeach; else: foreach ($results as $r): ?>
        <a href="index.php?page=user&id=<?= $r['id'] ?>" class="tieba-row">
            <img src="<?= e(avatar($r)) ?>" class="avatar-md">
            <div class="tieba-info">
                <div class="tieba-name"><?= e($r['nickname'] ?: $r['username']) ?></div>
                <div class="tieba-desc"><?= e($r['bio'] ?: '@'.$r['username']) ?></div>
                <div class="tieba-meta"><i class="fa fa-file-text-o"></i> <?= $r['posts'] ?> 帖子</div>
            </div>
        </a>
    <?php endforeach; endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
