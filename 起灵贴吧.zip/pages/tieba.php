<?php
/**
 * 贴吧详情页
 */
$tiebaId = intval($_GET['id'] ?? 0);
$tieba = db()->prepare("SELECT * FROM tiebas WHERE id = ?");
$tieba->execute([$tiebaId]);
$tieba = $tieba->fetch();

if (!$tieba) { header('Location: index.php?page=discover'); exit; }

$pageTitle = $tieba['name'];
$currentPage = 'discover';
include __DIR__ . '/../includes/header.php';

// 查询吧主信息
$owner = null;
if (!empty($tieba['owner_id'])) {
    $stmt = db()->prepare("SELECT id, nickname, username, avatar FROM users WHERE id = ?");
    $stmt->execute([$tieba['owner_id']]);
    $owner = $stmt->fetch();
}
$isOwner = ($user && $owner && $user['id'] == $owner['id']);

// 吧主更换封面
$coverMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['act'] ?? '') === 'change_cover' && $isOwner) {
    if (!empty($_FILES['cover']['name'])) {
        $r = handle_upload($_FILES['cover'], ['jpg','jpeg','png','gif','webp'], 5242880);
        if ($r['ok']) {
            // 删除旧封面
            if (!empty($tieba['cover'])) delete_uploaded_file($tieba['cover']);
            db()->prepare("UPDATE tiebas SET cover = ? WHERE id = ?")->execute([$r['url'], $tiebaId]);
            // 重新查询
            $tieba = db()->prepare("SELECT * FROM tiebas WHERE id = ?");
            $tieba->execute([$tiebaId]);
            $tieba = $tieba->fetch();
            $coverMsg = '封面更换成功';
        } else {
            $coverMsg = '封面上传失败: ' . $r['msg'];
        }
    } elseif (isset($_POST['remove_cover'])) {
        // 移除封面，恢复图标
        if (!empty($tieba['cover'])) delete_uploaded_file($tieba['cover']);
        db()->prepare("UPDATE tiebas SET cover = '' WHERE id = ?")->execute([$tiebaId]);
        $tieba['cover'] = '';
        $coverMsg = '封面已移除';
    }
}

$sort = $_GET['sort'] ?? 'new';
$order = $sort === 'hot' ? 'p.likes DESC, p.comments DESC' : 'p.is_top DESC, p.created_at DESC';

$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 10;
$offset = ($pageNum - 1) * $perPage;

$total = db()->query("SELECT COUNT(*) FROM posts WHERE tieba_id = {$tiebaId} AND status = 1")->fetchColumn();
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar
    FROM posts p LEFT JOIN users u ON p.user_id = u.id
    WHERE p.tieba_id = ? AND p.status = 1
    ORDER BY {$order}
    LIMIT {$offset}, {$perPage}
");
$stmt->execute([$tiebaId]);
$posts = $stmt->fetchAll();

$followed = is_followed($tiebaId);
?>

<!-- 贴吧封面 -->
<div style="height:160px;background:<?= cover($tieba) ?>;position:relative;display:flex;align-items:flex-end;padding:16px;">
    <a href="javascript:history.back()" class="icon-btn" style="position:absolute;top:12px;left:12px;background:rgba(255,255,255,0.7);"><i class="fa fa-angle-left"></i></a>
    <?php if ($isOwner): ?>
    <form method="post" enctype="multipart/form-data" id="coverForm" style="position:absolute;top:12px;right:12px;">
        <input type="hidden" name="act" value="change_cover">
        <input type="file" name="cover" id="tieba-cover-input" accept="image/*" style="display:none;">
        <button type="button" onclick="document.getElementById('tieba-cover-input').click()" class="icon-btn" style="background:rgba(0,0,0,0.4);color:white;">
            <i class="fa fa-camera"></i> 换封面
        </button>
        <?php if (!empty($tieba['cover'])): ?>
        <button type="submit" name="remove_cover" value="1" class="icon-btn" style="background:rgba(0,0,0,0.4);color:white;margin-left:6px;" onclick="return confirm('确定移除封面，恢复默认图标？')">
            <i class="fa fa-times"></i>
        </button>
        <?php endif; ?>
    </form>
    <?php endif; ?>
    <div style="color:white;text-shadow:0 2px 8px rgba(0,0,0,0.15);">
        <div style="font-size:24px;font-weight:700;"><i class="fa fa-<?= e($tieba['icon'] ?: 'tree') ?>"></i> <?= e($tieba['name']) ?></div>
        <div style="font-size:13px;opacity:0.95;margin-top:4px;"><?= e($tieba['description']) ?></div>
    </div>
</div>

<?php if ($coverMsg): ?>
<div style="padding:8px 16px;background:<?= strpos($coverMsg,'失败')!==false?'#fee2e2':'#dcfce7' ?>;color:<?= strpos($coverMsg,'失败')!==false?'#991b1b':'#166534' ?>;font-size:13px;">
    <i class="fa fa-<?= strpos($coverMsg,'失败')!==false?'exclamation-circle':'check-circle' ?>"></i> <?= e($coverMsg) ?>
</div>
<?php endif; ?>

<!-- 统计与关注 -->
<div style="display:flex;align-items:center;padding:14px 16px;background:white;gap:16px;">
    <div style="flex:1;display:flex;gap:20px;">
        <div><span style="font-size:18px;font-weight:700;color:var(--primary);"><?= $tieba['members'] ?></span><br><span class="text-xs text-light">成员</span></div>
        <div><span style="font-size:18px;font-weight:700;color:var(--primary);"><?= $tieba['posts'] ?></span><br><span class="text-xs text-light">帖子</span></div>
    </div>
    <?php if ($user): ?>
        <button class="btn <?= $followed ? 'btn-ghost' : 'btn-primary' ?>" onclick="followTieba(<?= $tiebaId ?>, this)">
            <i class="fa fa-<?= $followed ? 'check' : 'plus' ?>"></i> <?= $followed ? '已关注' : '关注' ?>
        </button>
    <?php else: ?>
        <a href="index.php?page=login" class="btn btn-primary"><i class="fa fa-plus"></i> 关注</a>
    <?php endif; ?>
</div>

<!-- 吧主信息 -->
<?php if ($owner): ?>
<div style="display:flex;align-items:center;gap:10px;padding:10px 16px;background:rgba(255,255,255,0.6);border-top:1px solid var(--border);">
    <i class="fa fa-crown" style="color:#f59e0b;"></i>
    <span style="font-size:13px;color:var(--text-soft);">吧主：</span>
    <a href="index.php?page=user&id=<?= $owner['id'] ?>" style="display:flex;align-items:center;gap:6px;">
        <img src="<?= e(avatar($owner)) ?>" style="width:24px;height:24px;border-radius:50%;object-fit:cover;">
        <span style="font-size:13px;color:var(--primary);font-weight:500;"><?= e($owner['nickname'] ?: $owner['username']) ?></span>
    </a>
    <?php if ($isOwner): ?>
        <span class="tag" style="margin-left:auto;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:white;font-size:11px;">
            <i class="fa fa-crown"></i> 我是吧主
        </span>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- 排序 -->
<div style="display:flex;gap:8px;padding:12px 16px;background:var(--bg-soft);">
    <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=new" class="tag" style="background:<?= $sort==='new'?'linear-gradient(135deg,#ec4899,#a855f7)':'white' ?>;color:<?= $sort==='new'?'white':'var(--text-soft)' ?>;">
        <i class="fa fa-clock-o"></i> 最新
    </a>
    <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=hot" class="tag" style="background:<?= $sort==='hot'?'linear-gradient(135deg,#ec4899,#a855f7)':'white' ?>;color:<?= $sort==='hot'?'white':'var(--text-soft)' ?>;">
        <i class="fa fa-fire"></i> 热门
    </a>
</div>

<!-- 帖子列表 -->
<?php if (empty($posts)): ?>
    <div class="empty">
        <i class="fa fa-leaf"></i>
        <p>这个贴吧还没有帖子</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">点击底部 + 按钮发布第一条帖子吧 ~</p>
    </div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
        $liked = is_liked($p['id']);
    ?>
    <div class="post-card">
        <div class="post-header">
            <a href="index.php?page=user&id=<?= $p['user_id'] ?>">
                <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar">
            </a>
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname']) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?></div>
            </div>
            <?php if ($p['is_top']): ?><span class="tag tag-top">置顶</span><?php endif; ?>
        </div>
        <a href="index.php?page=post&id=<?= $p['id'] ?>">
            <?php if ($p['title']): ?><div class="post-title"><?= e($p['title']) ?></div><?php endif; ?>
            <div class="post-content"><?= nl2br(e($p['content'])) ?></div>
            <?php if (!empty($imgs)): ?>
                <div class="post-images <?= count($imgs)===1?'single':(count($imgs)===2?'double':'triple') ?>">
                    <?php foreach (array_slice($imgs,0,9) as $img): ?>
                        <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($p['video']): ?>
                <div class="post-video">
                    <video src="<?= e($p['video']) ?>" preload="metadata"></video>
                    <div class="video-play"><i class="fa fa-play"></i></div>
                </div>
            <?php endif; ?>
        </a>
        <div class="post-actions">
            <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i><span class="count"><?= $p['likes'] ?></span>
            </div>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-action"><i class="fa fa-comment-o"></i><span><?= $p['comments'] ?></span></a>
            <div class="post-action" onclick="toast('已分享~')"><i class="fa fa-share-alt"></i><span><?= $p['shares'] ?></span></div>
        </div>
    </div>
    <?php endforeach; ?>

    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div style="display:flex;justify-content:center;gap:8px;padding:16px;">
        <?php if ($pageNum > 1): ?>
            <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=<?= $sort ?>&p=<?= $pageNum-1 ?>" class="btn btn-ghost"><i class="fa fa-angle-left"></i></a>
        <?php endif; ?>
        <span class="btn btn-ghost"><?= $pageNum ?> / <?= $totalPage ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=<?= $sort ?>&p=<?= $pageNum+1 ?>" class="btn btn-ghost"><i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ($isOwner): ?>
<script>
// 选择封面图后自动提交
document.getElementById('tieba-cover-input').addEventListener('change', function(){
    if (this.files && this.files[0]) {
        document.getElementById('coverForm').submit();
    }
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
