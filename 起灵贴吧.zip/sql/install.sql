-- 起灵贴吧数据库结构
SET NAMES utf8mb4;

-- 用户表
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `nickname` VARCHAR(50) NOT NULL DEFAULT '',
    `email` VARCHAR(100) DEFAULT '',
    `avatar` VARCHAR(255) DEFAULT '',
    `bio` VARCHAR(200) DEFAULT '',
    `role` ENUM('user','admin','super_admin') DEFAULT 'user',
    `status` TINYINT DEFAULT 1,
    `followers` INT DEFAULT 0,
    `following` INT DEFAULT 0,
    `posts` INT DEFAULT 0,
    `level` INT NOT NULL DEFAULT 0,
    `privacy_posts` ENUM('public','private') DEFAULT 'public',
    `privacy_following` ENUM('public','private') DEFAULT 'public',
    `privacy_followers` ENUM('public','private') DEFAULT 'public',
    `privacy_tiebas` ENUM('public','private') DEFAULT 'public',
    `last_login` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 贴吧表
CREATE TABLE IF NOT EXISTS `tiebas` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `description` VARCHAR(255) DEFAULT '',
    `icon` VARCHAR(50) DEFAULT '',
    `cover` VARCHAR(255) DEFAULT '',
    `category` VARCHAR(50) DEFAULT '',
    `owner_id` INT UNSIGNED DEFAULT 0,
    `members` INT DEFAULT 0,
    `posts` INT DEFAULT 0,
    `hot` INT DEFAULT 0,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 帖子表
CREATE TABLE IF NOT EXISTS `posts` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `tieba_id` INT UNSIGNED NOT NULL,
    `title` VARCHAR(100) DEFAULT '',
    `content` TEXT,
    `images` TEXT,
    `video` VARCHAR(255) DEFAULT '',
    `type` ENUM('text','image','video','vote') DEFAULT 'text',
    `views` INT DEFAULT 0,
    `likes` INT DEFAULT 0,
    `favorites` INT DEFAULT 0,
    `comments` INT DEFAULT 0,
    `shares` INT DEFAULT 0,
    `is_top` TINYINT DEFAULT 0,
    `is_hot` TINYINT DEFAULT 0,
    `status` TINYINT DEFAULT 1,
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_tieba` (`tieba_id`),
    KEY `idx_user` (`user_id`),
    KEY `idx_hot` (`is_hot`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 评论表
CREATE TABLE IF NOT EXISTS `comments` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `post_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `parent_id` INT DEFAULT 0,
    `content` TEXT,
    `likes` INT DEFAULT 0,
    `status` TINYINT DEFAULT 1,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_post` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 点赞表
CREATE TABLE IF NOT EXISTS `post_likes` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `post_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_post_user` (`post_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 收藏表
CREATE TABLE IF NOT EXISTS `post_favorites` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `post_id` INT UNSIGNED NOT NULL,
    `user_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_fav_user` (`post_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 贴吧关注表
CREATE TABLE IF NOT EXISTS `tieba_follows` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT UNSIGNED NOT NULL,
    `tieba_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_tieba` (`user_id`,`tieba_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 用户关注表
CREATE TABLE IF NOT EXISTS `user_follows` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `follower_id` INT UNSIGNED NOT NULL,
    `following_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_follow` (`follower_id`,`following_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 消息表
CREATE TABLE IF NOT EXISTS `messages` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `from_user_id` INT UNSIGNED DEFAULT 0,
    `to_user_id` INT UNSIGNED NOT NULL,
    `type` ENUM('like','comment','follow','system','chat','contact') DEFAULT 'system',
    `content` VARCHAR(255) DEFAULT '',
    `post_id` INT DEFAULT 0,
    `is_read` TINYINT DEFAULT 0,
    `created_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_to` (`to_user_id`,`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 系统设置表
CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `site_name` VARCHAR(100) DEFAULT '',
    `site_desc` VARCHAR(255) DEFAULT '',
    `site_keywords` VARCHAR(255) DEFAULT '',
    `site_logo` VARCHAR(255) DEFAULT '',
    `icp` VARCHAR(100) DEFAULT '',
    `allow_register` TINYINT DEFAULT 1,
    `post_audit` TINYINT DEFAULT 0,
    `announcement` TEXT,
    `banner_image` VARCHAR(255) DEFAULT '',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 分类表
CREATE TABLE IF NOT EXISTS `categories` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(50) NOT NULL,
    `icon` VARCHAR(50) DEFAULT '',
    `sort` INT DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 插入默认分类
INSERT INTO `categories` (`name`, `icon`, `sort`) VALUES
('情感', 'heart', 1),
('生活', 'coffee', 2),
('治愈', 'sun', 3),
('树洞', 'tree', 4),
('日常', 'star', 5);
