<?php
/**
 * Windows 版 - 文件广场（公开页面）
 * 展示所有用户上传的文件，可查看详情、下载（有密码的文件需在详情页输入密码）
 */
$pageTitle = '文件广场';
$currentPage = 'filehub';
include __DIR__ . '/_header.php';

$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 24;
$offset = ($pageNum - 1) * $perPage;

$total = (int)db()->query("SELECT COUNT(*) FROM user_files")->fetchColumn();
$stmt = db()->prepare("SELECT f.*, u.username, u.nickname, u.avatar FROM user_files f
    LEFT JOIN users u ON f.user_id = u.id
    ORDER BY f.id DESC LIMIT {$offset}, {$perPage}");
$stmt->execute();
$list = $stmt->fetchAll();
$pages = max(1, (int)ceil($total / $perPage));
?>

<style>
.filehub-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px; }
.filehub-item {
    border: 1px solid #ececf2; border-radius: 12px; padding: 14px;
    background: #fff; transition: box-shadow .2s, transform .2s;
    display: flex; flex-direction: column;
}
.filehub-item:hover { box-shadow: 0 6px 18px rgba(0,0,0,.06); transform: translateY(-2px); }
.filehub-head { display: flex; align-items: center; gap: 10px; min-width: 0; }
.filehub-icon {
    width: 42px; height: 42px; border-radius: 10px; flex-shrink: 0;
    background: var(--grad); color: #fff;
    display: flex; align-items: center; justify-content: center; font-size: 18px;
}
.filehub-name { font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.filehub-meta { font-size: 12px; color: var(--text-light); margin-top: 4px; }
.filehub-user { display: flex; align-items: center; gap: 6px; margin-top: 10px; }
.filehub-user img { width: 18px; height: 18px; border-radius: 50%; object-fit: cover; }
.filehub-foot { display: flex; align-items: center; gap: 8px; margin-top: 12px; padding-top: 10px; border-top: 1px solid #f1f1f5; }
.filehub-notice {
    display: flex; align-items: center; gap: 10px; padding: 10px 14px;
    background: linear-gradient(135deg, #fef3c7, #fde68a); border-radius: 10px;
    overflow: hidden; box-shadow: 0 2px 8px rgba(245,158,11,.15);
}
.filehub-notice > i { color: #f59e0b; flex-shrink: 0; }
.filehub-notice-track { flex: 1; overflow: hidden; white-space: nowrap; }
.filehub-notice-text {
    display: inline-block; padding-left: 100%;
    animation: filehub-marquee 22s linear infinite;
    font-size: 13px; color: #92400e; font-weight: 500;
}
@keyframes filehub-marquee {
    0%   { transform: translateX(0); }
    100% { transform: translateX(-100%); }
}
</style>

<div class="win-card">
    <!-- 公告（滚动） -->
    <div class="filehub-notice">
        <i class="fa fa-bullhorn"></i>
        <div class="filehub-notice-track">
            <span class="filehub-notice-text">📢 社区文件库：用户分享的文件都在这里，共 <?= $total ?> 个。点击「详情」查看文件信息；设置了提取密码的文件需输入密码后才能下载。</span>
        </div>
    </div>
    <?php if ($user): ?>
        <div style="margin-top:12px;text-align:right;">
            <a href="index.php?page=files" class="btn btn-ghost btn-sm"><i class="fa fa-upload"></i> 上传我的文件</a>
        </div>
    <?php endif; ?>
</div>

<?php if (empty($list)): ?>
    <div class="win-card" style="margin-top:16px;">
        <div class="empty" style="padding:40px 20px;">
            <i class="fa fa-folder-open-o"></i>
            <p>还没有人分享文件</p>
            <?php if ($user): ?>
                <a href="index.php?page=files" class="btn btn-primary btn-sm" style="margin-top:12px;">去上传第一个文件</a>
            <?php endif; ?>
        </div>
    </div>
<?php else: ?>
    <div class="filehub-grid" style="margin-top:16px;">
        <?php foreach ($list as $f):
            $detailUrl = 'index.php?page=file&id=' . $f['id'];
            $downloadUrl = 'index.php?page=download&id=' . $f['id'];
            $hasPwd = !empty($f['password']);
        ?>
        <div class="filehub-item">
            <a href="<?= $detailUrl ?>" class="filehub-head" style="color:inherit;">
                <div class="filehub-icon"><i class="fa <?= e(file_icon($f['ext'])) ?>"></i></div>
                <div style="flex:1;min-width:0;">
                    <div class="filehub-name">
                        <?= e($f['name']) ?>
                        <?php if ($hasPwd): ?>
                            <span style="font-size:11px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:2px 8px;font-weight:400;"><i class="fa fa-lock"></i> 密码</span>
                        <?php endif; ?>
                    </div>
                    <div class="filehub-meta"><?= human_size($f['filesize']) ?> · <?= time_ago($f['created_at']) ?></div>
                </div>
            </a>
            <div class="filehub-user">
                <img src="<?= e(avatar(['id' => $f['user_id'], 'avatar' => $f['avatar'], 'username' => $f['username'] ?: '?'])) ?>" alt="">
                <span style="font-size:12px;color:var(--text-soft);"><?= e($f['nickname'] ?: $f['username'] ?: '已注销用户') ?></span>
            </div>
            <div class="filehub-foot">
                <span style="font-size:12px;color:var(--text-light);flex:1;"><i class="fa fa-download"></i> <?= intval($f['downloads']) ?></span>
                <?php if ($hasPwd): ?>
                    <a href="<?= $detailUrl ?>" class="btn btn-ghost btn-sm"><i class="fa fa-lock"></i> 输入密码下载</a>
                <?php else: ?>
                    <a href="<?= $downloadUrl ?>" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> 下载</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if ($pages > 1): ?>
        <div style="display:flex;justify-content:center;align-items:center;gap:12px;margin-top:20px;">
            <?php if ($pageNum > 1): ?>
                <a href="index.php?page=filehub&p=<?= $pageNum - 1 ?>" class="btn btn-ghost btn-sm">上一页</a>
            <?php endif; ?>
            <span style="font-size:12px;color:var(--text-light);"><?= $pageNum ?> / <?= $pages ?></span>
            <?php if ($pageNum < $pages): ?>
                <a href="index.php?page=filehub&p=<?= $pageNum + 1 ?>" class="btn btn-ghost btn-sm">下一页</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
