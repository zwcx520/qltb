<?php
/**
 * 文件下载（APP / Windows 共用）
 * 说明：需要密码的文件需在详情页验证通过，验证有效期 30 秒（file_unlock_valid）
 * 下载请求开始后即独立执行，不受验证倒计时影响；此处提前释放 session 锁，避免大文件下载阻塞其他页面
 */
$fileId = intval($_GET['id'] ?? 0);

$stmt = db()->prepare("SELECT f.*, u.username FROM user_files f JOIN users u ON f.user_id = u.id WHERE f.id = ?");
$stmt->execute([$fileId]);
$f = $stmt->fetch();

if (!$f) {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h3 style="font-family:sans-serif;padding:24px;">文件不存在或已被删除</h3>';
    exit;
}

$isOwner = $user && ($user['id'] == $f['user_id']);
$isAdmin = $user && in_array($user['role'], ['admin', 'super_admin'], true);
if ($f['password'] !== '' && !$isOwner && !$isAdmin && !file_unlock_valid($f['id'])) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h3 style="font-family:sans-serif;padding:24px;">该文件需要提取密码</h3>'
       . '<p style="font-family:sans-serif;padding:0 24px;">请先打开文件详情页，输入密码验证后再下载。</p>';
    exit;
}

$path = __DIR__ . '/../' . ltrim($f['file'], '/');
if (!is_file($path)) {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo '<h3 style="font-family:sans-serif;padding:24px;">文件已丢失</h3>';
    exit;
}

db()->prepare("UPDATE user_files SET downloads = downloads + 1 WHERE id = ?")->execute([$f['id']]);

// 释放 session 锁：下载过程中不再阻塞该用户的其他请求
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$name = ($f['name'] !== '' && $f['name'] !== null) ? $f['name'] : basename($path);
$fallback = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
if ($fallback === '' || $fallback === '.') $fallback = 'download';

while (ob_get_level()) { @ob_end_clean(); }
header('Content-Type: application/octet-stream');
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="' . $fallback . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=0, no-cache');
readfile($path);
exit;
