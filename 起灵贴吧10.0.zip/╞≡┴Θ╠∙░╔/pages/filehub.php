<?php
/**
 * 文件广场（APP UI，公开页面）
 * 展示所有用户上传的文件，点击可查看详情并按需下载（有密码的文件需在详情页输入密码）
 */
$pageTitle = '文件广场';
$currentPage = 'filehub';
include __DIR__ . '/../includes/header.php';

$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 20;
$offset = ($pageNum - 1) * $perPage;

$total = (int)db()->query("SELECT COUNT(*) FROM user_files")->fetchColumn();
$stmt = db()->prepare("SELECT f.*, u.username, u.nickname, u.avatar FROM user_files f
    LEFT JOIN users u ON f.user_id = u.id
    ORDER BY f.id DESC LIMIT {$offset}, {$perPage}");
$stmt->execute();
$list = $stmt->fetchAll();
$pages = max(1, (int)ceil($total / $perPage));
?>

<!-- 顶部栏 -->
<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:white;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;">
    <a href="index.php?page=home" class="icon-btn"><i class="fa fa-angle-left"></i></a>
    <div style="font-size:17px;font-weight:600;flex:1;">文件广场</div>
    <?php if ($user): ?>
        <a href="index.php?page=files" class="btn btn-ghost btn-sm"><i class="fa fa-upload"></i> 上传</a>
    <?php endif; ?>
</div>

<!-- 公告（滚动） -->
<div class="gongao">
    <i class="fa fa-bullhorn gongao-icon"></i>
    <div class="gongao-track">
        <span class="gongao-text">📢 社区文件库：用户分享的文件都在这里，共 <?= $total ?> 个。点击「详情」查看文件信息；设置了提取密码的文件需输入密码后才能下载。</span>
    </div>
</div>

<?php if (empty($list)): ?>
    <div class="empty">
        <i class="fa fa-folder-open-o"></i>
        <p>还没有人分享文件</p>
        <?php if ($user): ?>
            <a href="index.php?page=files" class="btn btn-primary btn-sm" style="margin-top:12px;">去上传第一个文件</a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div style="padding:10px 16px 20px;display:flex;flex-direction:column;gap:10px;">
        <?php foreach ($list as $f):
            $detailUrl = 'index.php?page=file&id=' . $f['id'];
            $downloadUrl = 'index.php?page=download&id=' . $f['id'];
            $hasPwd = !empty($f['password']);
        ?>
        <div class="post-card" style="padding:12px;">
            <a href="<?= $detailUrl ?>" style="display:flex;align-items:center;gap:12px;color:inherit;">
                <div style="width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,#ec4899,#a855f7);color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fa <?= e(file_icon($f['ext'])) ?>"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        <?= e($f['name']) ?>
                        <?php if ($hasPwd): ?>
                            <span style="font-size:10px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:1px 6px;margin-left:4px;"><i class="fa fa-lock"></i> 密码</span>
                        <?php endif; ?>
                    </div>
                    <div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
                        <img src="<?= e(avatar(['id' => $f['user_id'], 'avatar' => $f['avatar'], 'username' => $f['username'] ?: '?'])) ?>" style="width:18px;height:18px;border-radius:50%;object-fit:cover;">
                        <span style="font-size:11px;color:var(--text-light);"><?= e($f['nickname'] ?: $f['username'] ?: '已注销用户') ?> · <?= human_size($f['filesize']) ?> · <?= time_ago($f['created_at']) ?></span>
                    </div>
                </div>
            </a>
            <div style="display:flex;align-items:center;gap:8px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(0,0,0,.05);">
                <span style="font-size:11px;color:var(--text-light);flex:1;"><i class="fa fa-download"></i> <?= intval($f['downloads']) ?> 次下载</span>
                <?php if ($hasPwd): ?>
                    <a href="<?= $detailUrl ?>" class="btn btn-ghost btn-sm"><i class="fa fa-lock"></i> 输入密码下载</a>
                <?php else: ?>
                    <a href="<?= $downloadUrl ?>" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> 下载</a>
                <?php endif; ?>
                <a href="<?= $detailUrl ?>" class="btn btn-ghost btn-sm">详情</a>
            </div>
        </div>
        <?php endforeach; ?>

        <?php if ($pages > 1): ?>
            <div style="display:flex;justify-content:center;align-items:center;gap:10px;margin-top:8px;">
                <?php if ($pageNum > 1): ?>
                    <a href="index.php?page=filehub&p=<?= $pageNum - 1 ?>" class="btn btn-ghost btn-sm">上一页</a>
                <?php endif; ?>
                <span style="font-size:12px;color:var(--text-light);"><?= $pageNum ?> / <?= $pages ?></span>
                <?php if ($pageNum < $pages): ?>
                    <a href="index.php?page=filehub&p=<?= $pageNum + 1 ?>" class="btn btn-ghost btn-sm">下一页</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
