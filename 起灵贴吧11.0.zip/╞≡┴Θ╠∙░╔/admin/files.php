<?php
/**
 * 用户文件管理
 * 查看所有用户上传的文件，可下载、删除
 */
$adminPage = 'files';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';
$kw = trim($_GET['kw'] ?? '');

if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    $stmt = db()->prepare("SELECT * FROM user_files WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if ($row) {
        db()->prepare("DELETE FROM user_files WHERE id = ?")->execute([$id]);
        delete_uploaded_file($row['file']);
        $stmt = db()->prepare("SELECT username FROM users WHERE id = ?");
        $stmt->execute([$row['user_id']]);
        $uname = $stmt->fetchColumn();
        if ($uname) {
            $dir = __DIR__ . '/../assets/uploads/files/' . files_folder_name($uname);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
        }
    }
    header('Location: admin.php?page=files' . ($kw !== '' ? '&kw=' . urlencode($kw) : ''));
    exit;
}

if ($kw !== '') {
    $like = '%' . $kw . '%';
    $stmt = db()->prepare("SELECT f.*, u.username, u.nickname, u.avatar FROM user_files f
        LEFT JOIN users u ON f.user_id = u.id
        WHERE u.username LIKE ? OR u.nickname LIKE ? OR f.name LIKE ?
        ORDER BY f.id DESC LIMIT 200");
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = db()->query("SELECT f.*, u.username, u.nickname, u.avatar FROM user_files f
        LEFT JOIN users u ON f.user_id = u.id
        ORDER BY f.id DESC LIMIT 200");
}
$list = $stmt->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <h3 style="font-size:16px;font-weight:600;flex:1;"><i class="fa fa-folder-open text-primary"></i> 用户文件</h3>
        <form method="get" action="admin.php" style="display:flex;gap:8px;align-items:center;">
            <input type="hidden" name="page" value="files">
            <input name="kw" class="form-input" placeholder="搜索用户名 / 昵称 / 文件名" value="<?= e($kw) ?>" style="width:220px;padding:8px 12px;">
            <button class="btn btn-primary btn-sm"><i class="fa fa-search"></i> 搜索</button>
            <?php if ($kw !== ''): ?>
                <a href="admin.php?page=files" class="btn btn-warning btn-sm">重置</a>
            <?php endif; ?>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>用户</th>
                <th>文件名称</th>
                <th>大小</th>
                <th>提取密码</th>
                <th>下载</th>
                <th>上传时间</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($list as $f): ?>
            <tr>
                <td><?= $f['id'] ?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <img src="<?= e(avatar(['id' => $f['user_id'], 'avatar' => $f['avatar'], 'username' => $f['username'] ?: '?'])) ?>" style="width:28px;height:28px;border-radius:50%;object-fit:cover;">
                        <span><strong><?= e($f['nickname'] ?: $f['username'] ?: '已注销用户') ?></strong></span>
                    </div>
                </td>
                <td>
                    <div style="display:flex;align-items:center;gap:6px;max-width:280px;">
                        <i class="fa <?= e(file_icon($f['ext'])) ?> text-primary"></i>
                        <span title="<?= e($f['name']) ?>" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($f['name']) ?></span>
                    </div>
                    <?php if (!empty($f['description'])): ?>
                        <div style="font-size:12px;color:var(--text-light);max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= e($f['description']) ?>"><?= e($f['description']) ?></div>
                    <?php endif; ?>
                </td>
                <td><?= human_size($f['filesize']) ?></td>
                <td>
                    <?php if (!empty($f['password'])): ?>
                        <span style="font-size:11px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:2px 8px;"><i class="fa fa-lock"></i> 已设置</span>
                    <?php else: ?>
                        <span style="font-size:12px;color:var(--text-light);">无</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="index.php?page=download&id=<?= $f['id'] ?>" class="btn btn-ghost btn-sm" target="_blank"><i class="fa fa-download"></i> 下载</a>
                    <div style="font-size:11px;color:var(--text-light);margin-top:3px;"><?= intval($f['downloads']) ?> 次</div>
                </td>
                <td><?= e($f['created_at']) ?></td>
                <td>
                    <a href="index.php?page=file&id=<?= $f['id'] ?>" class="btn btn-ghost btn-sm" target="_blank"><i class="fa fa-info-circle"></i> 详情</a>
                    <a href="admin.php?page=files&act=delete&id=<?= $f['id'] ?>&kw=<?= urlencode($kw) ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除该文件？文件也会一并删除。')">
                        <i class="fa fa-trash"></i> 删除
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($list)): ?>
        <div class="empty"><i class="fa fa-folder-open-o"></i><p>暂无用户上传的文件</p></div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
