<?php
/**
 * 用户背景音乐管理
 * 查看所有用户上传的背景音乐，可试听、删除
 */
$adminPage = 'music';
include __DIR__ . '/admin_header.php';

$act = $_GET['act'] ?? '';
$kw = trim($_GET['kw'] ?? '');

if ($act === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    $stmt = db()->prepare("SELECT * FROM user_music WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if ($row) {
        db()->prepare("DELETE FROM user_music WHERE id = ?")->execute([$id]);
        delete_uploaded_file($row['file']);
    }
    header('Location: admin.php?page=music' . ($kw !== '' ? '&kw=' . urlencode($kw) : ''));
    exit;
}

if ($kw !== '') {
    $like = '%' . $kw . '%';
    $stmt = db()->prepare("SELECT m.*, u.username, u.nickname, u.avatar FROM user_music m
        LEFT JOIN users u ON m.user_id = u.id
        WHERE u.username LIKE ? OR u.nickname LIKE ? OR m.title LIKE ?
        ORDER BY m.id DESC LIMIT 200");
    $stmt->execute([$like, $like, $like]);
} else {
    $stmt = db()->query("SELECT m.*, u.username, u.nickname, u.avatar FROM user_music m
        LEFT JOIN users u ON m.user_id = u.id
        ORDER BY m.id DESC LIMIT 200");
}
$list = $stmt->fetchAll();
?>

<div class="card">
    <div class="toolbar">
        <h3 style="font-size:16px;font-weight:600;flex:1;"><i class="fa fa-music text-primary"></i> 用户背景音乐</h3>
        <form method="get" action="admin.php" style="display:flex;gap:8px;align-items:center;">
            <input type="hidden" name="page" value="music">
            <input name="kw" class="form-input" placeholder="搜索用户名 / 昵称 / 音乐名" value="<?= e($kw) ?>" style="width:220px;padding:8px 12px;">
            <button class="btn btn-primary btn-sm"><i class="fa fa-search"></i> 搜索</button>
            <?php if ($kw !== ''): ?>
                <a href="admin.php?page=music" class="btn btn-warning btn-sm">重置</a>
            <?php endif; ?>
        </form>
    </div>

    <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>用户</th>
                <th>音乐名称</th>
                <th>大小</th>
                <th>上传时间</th>
                <th>试听</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($list as $m): ?>
            <tr>
                <td><?= $m['id'] ?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <img src="<?= e(avatar(['id' => $m['user_id'], 'avatar' => $m['avatar'], 'username' => $m['username'] ?: '?'])) ?>" style="width:28px;height:28px;border-radius:50%;object-fit:cover;">
                        <span><strong><?= e($m['nickname'] ?: $m['username'] ?: '已注销用户') ?></strong></span>
                    </div>
                </td>
                <td><?= e($m['title']) ?></td>
                <td><?= round($m['filesize'] / 1048576, 1) ?> MB</td>
                <td><?= e($m['created_at']) ?></td>
                <td>
                    <audio controls preload="none" src="<?= e($m['file']) ?>" style="height:30px;max-width:190px;"></audio>
                </td>
                <td>
                    <a href="admin.php?page=music&act=delete&id=<?= $m['id'] ?>&kw=<?= urlencode($kw) ?>" class="btn btn-danger btn-sm" onclick="return confirm('确定删除这首音乐？文件也会一并删除。')">
                        <i class="fa fa-trash"></i> 删除
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (empty($list)): ?>
        <div class="empty"><i class="fa fa-music"></i><p>暂无用户上传的背景音乐</p></div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/admin_footer.php'; ?>
