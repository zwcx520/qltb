<?php
/**
 * 评论接口
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
$content = trim($_POST['content'] ?? '');
$parentId = intval($_POST['parent_id'] ?? 0);

if (!$postId || !$content) json_response(null, 1, '参数错误');

// 私密帖：仅作者本人和管理员可评论，其他用户（含伪造请求）一律拒绝
$post = db()->prepare("SELECT user_id, visibility FROM posts WHERE id = ?");
$post->execute([$postId]);
$postRow = $post->fetch();
if (!$postRow) json_response(null, 1, '帖子不存在或已被删除');
if (($postRow['visibility'] ?? 'public') === 'private' && $postRow['user_id'] != $user['id'] && !in_array($user['role'], ['admin','super_admin'])) {
    json_response(null, 1, '无权评论该帖子');
}

// 楼中楼：校验被回复评论属于同一帖子，防止伪造跨帖关联，并取其作者用于通知
$parentAuthor = 0;
if ($parentId) {
    $pStmt = db()->prepare("SELECT user_id FROM comments WHERE id = ? AND post_id = ?");
    $pStmt->execute([$parentId, $postId]);
    $parent = $pStmt->fetch();
    if (!$parent) json_response(null, 1, '要回复的评论不存在或已被删除');
    $parentAuthor = (int)$parent['user_id'];
}

$stmt = db()->prepare("INSERT INTO comments (post_id, user_id, parent_id, content, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt->execute([$postId, $user['id'], $parentId, $content]);

db()->exec("UPDATE posts SET comments = comments + 1 WHERE id = {$postId}");

// 通知帖子作者（被回复人就是帖子作者时只发一条，避免重复）
if ($postRow['user_id'] != $user['id'] && $postRow['user_id'] != $parentAuthor) {
    db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'comment', ?, ?, NOW())")
        ->execute([$user['id'], $postRow['user_id'], '评论了你的帖子', $postId]);
}
// 楼中楼回复：单独通知被回复的评论作者
if ($parentAuthor && $parentAuthor != $user['id'] && $parentAuthor != $postRow['user_id']) {
    db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, post_id, created_at) VALUES (?, ?, 'comment', ?, ?, NOW())")
        ->execute([$user['id'], $parentAuthor, '回复了你的评论', $postId]);
}

json_response(['id' => db()->lastInsertId()]);
