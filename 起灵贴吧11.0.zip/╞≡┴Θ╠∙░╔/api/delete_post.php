<?php
/**
 * 删除帖子接口（同时删除图片和视频文件）
 */
define('IN_APP', true);
require __DIR__ . '/../includes/functions.php';
start_session();

$user = current_user();
if (!$user) json_response(null, 1, '请先登录');

$postId = intval($_POST['post_id'] ?? 0);
if (!$postId) json_response(null, 1, '参数错误');

// 查询帖子
$stmt = db()->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$postId]);
$post = $stmt->fetch();

if (!$post) json_response(null, 1, '帖子不存在');

// 权限检查：作者本人、管理员/站长、或本贴吧吧主可删除
$canDelete = ($post['user_id'] == $user['id']) || in_array($user['role'], ['admin','super_admin']);
if (!$canDelete) {
    // 查是否为本帖所属贴吧的吧主
    $tb = db()->prepare("SELECT owner_id FROM tiebas WHERE id = ?");
    $tb->execute([$post['tieba_id']]);
    $tbRow = $tb->fetch();
    if ($tbRow && $tbRow['owner_id'] == $user['id']) {
        $canDelete = true;
    }
}
if (!$canDelete) {
    json_response(null, 1, '无权删除该帖子');
}

// 先收集文件路径，事务提交成功后再物理删除（避免回滚后留下死链）
$files = [];
if (!empty($post['images'])) {
    $imgs = json_decode($post['images'], true);
    if (is_array($imgs)) {
        foreach ($imgs as $img) $files[] = $img;
    }
}
if (!empty($post['video'])) {
    $files[] = $post['video'];
}

try {
    db()->beginTransaction();

    // 删除关联数据
    db()->prepare("DELETE FROM comments WHERE post_id = ?")->execute([$postId]);
    db()->prepare("DELETE FROM post_likes WHERE post_id = ?")->execute([$postId]);
    db()->prepare("DELETE FROM post_favorites WHERE post_id = ?")->execute([$postId]);
    db()->prepare("DELETE FROM messages WHERE post_id = ?")->execute([$postId]);

    // 更新贴吧帖子数
    db()->exec("UPDATE tiebas SET posts = GREATEST(posts - 1, 0) WHERE id = {$post['tieba_id']}");
    // 更新用户帖子数
    db()->exec("UPDATE users SET posts = GREATEST(posts - 1, 0) WHERE id = {$post['user_id']}");

    // 删除帖子
    db()->prepare("DELETE FROM posts WHERE id = ?")->execute([$postId]);

    db()->commit();

    // 提交成功后删除物理文件
    foreach ($files as $f) delete_uploaded_file($f);

    json_response(['ok' => true]);
} catch (Exception $e) {
    db()->rollBack();
    json_response(null, 1, '删除失败: ' . $e->getMessage());
}
