<?php
/**
 * Windows 版 - 关于我们
 * 功能与 pages/about.php 完全一致：应用简介、功能特色、版本信息、联系站长
 */
$pageTitle = '关于我们';
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<div style="max-width:760px;margin:0 auto;">
    <!-- LOGO 区 -->
    <div style="text-align:center;padding:26px 0 22px;">
        <div style="width:88px;height:88px;margin:0 auto;border-radius:24px;background:linear-gradient(135deg,#ec4899,#a855f7);display:flex;align-items:center;justify-content:center;box-shadow:0 12px 32px rgba(168,85,247,.3);">
            <i class="fa fa-tree" style="color:#fff;font-size:36px;"></i>
        </div>
        <h2 style="font-size:22px;font-weight:700;background:linear-gradient(135deg,#ec4899,#a855f7);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;margin-top:16px;"><?= e($settings['site_name'] ?? '起灵贴吧') ?></h2>
        <p style="font-size:13px;color:var(--text-soft);margin-top:6px;">温暖的情绪树洞社区</p>
    </div>

    <!-- 应用简介 -->
    <div class="win-card">
        <h3 class="win-card-title" style="margin-bottom:10px;"><i class="fa fa-heart"></i> 关于 <?= e($settings['site_name'] ?? '起灵贴吧') ?></h3>
        <p style="font-size:13px;color:var(--text-soft);line-height:1.8;">
            <?= e($settings['site_desc'] ?? '在这里，每一份情绪都被温柔以待。起灵贴吧是一个唯美治愈的情绪树洞社区，你可以在这里倾诉心事、分享生活、结识志同道合的朋友。') ?>
        </p>
    </div>

    <!-- 功能特色 -->
    <div class="win-card">
        <h3 class="win-card-title"><i class="fa fa-star"></i> 功能特色</h3>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
            <?php
                $features = [
                    ['tree', '兴趣贴吧', '加入专属圈子'],
                    ['edit', '发布动态', '图文视频随心发'],
                    ['comment', '互动交流', '评论点赞关注'],
                    ['bell', '消息通知', '实时不错过'],
                    ['lock', '隐私设置', '守护你的秘密'],
                    ['shield', '社区规范', '文明友好环境'],
                ];
                foreach ($features as $f):
            ?>
            <div style="display:flex;align-items:center;gap:10px;padding:12px;background:#faf9fd;border:1px solid var(--border);border-radius:12px;">
                <div style="width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#fce7f3,#ddd6fe);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fa fa-<?= $f[0] ?>" style="color:var(--primary);"></i>
                </div>
                <div style="min-width:0;">
                    <div style="font-size:13px;font-weight:500;"><?= $f[1] ?></div>
                    <div style="font-size:11px;color:var(--text-light);"><?= $f[2] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- 版本信息 -->
    <div class="win-card" style="padding:0;overflow:hidden;">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);">
            <span style="font-size:13px;color:var(--text-soft);"><i class="fa fa-code-fork" style="color:var(--text-light);"></i> 开发者</span>
            <span style="font-size:13px;color:var(--text);">不见桃花不见秋</span>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);">
            <span style="font-size:13px;color:var(--text-soft);"><i class="fa fa-code-fork" style="color:var(--text-light);"></i> 版本号</span>
            <span style="font-size:13px;color:var(--text);">v1.0.0</span>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);">
            <span style="font-size:13px;color:var(--text-soft);"><i class="fa fa-calendar" style="color:var(--text-light);"></i> 更新日期</span>
            <span style="font-size:13px;color:var(--text);">2026-10-02</span>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;">
            <span style="font-size:13px;color:var(--text-soft);"><i class="fa fa-shield" style="color:var(--text-light);"></i> 备案号</span>
            <span style="font-size:13px;color:var(--text);"><?= e($settings['icp'] ?? '暂无') ?></span>
        </div>
    </div>

    <!-- 联系站长 -->
    <a href="index.php?page=contact" style="display:flex;align-items:center;justify-content:center;gap:8px;padding:14px;background:#fff;border:1px solid var(--border);border-radius:var(--radius);box-shadow:var(--shadow);font-size:14px;color:var(--primary);font-weight:500;">
        <i class="fa fa-envelope"></i> 联系站长
    </a>

    <p style="text-align:center;font-size:11px;color:var(--text-light);margin:24px 0 6px;line-height:1.8;">
        © 2026 <?= e($settings['site_name'] ?? '起灵贴吧') ?><br>
        Made with <i class="fa fa-heart" style="color:#ec4899;"></i> for you
    </p>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
