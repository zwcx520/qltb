<?php
/**
 * Windows 版 - 注销账号页
 * 用户主动注销：验证密码 + 二次确认后，彻底删除账号、所创建贴吧、帖子及全部图片/视频文件
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirmed = ($_POST['confirm'] ?? '') === '1';

    if ($password === '' || !verify_password($password, $user['password'])) {
        $error = '密码错误，请输入当前账号的登录密码';
    } elseif (!$confirmed) {
        $error = '请先勾选「我已知晓后果」再确认注销';
    } elseif ($user['role'] === 'super_admin') {
        // 唯一站长保护：站点至少保留一个超级管理员
        $superCount = (int) db()->query("SELECT COUNT(*) FROM users WHERE role = 'super_admin'")->fetchColumn();
        if ($superCount <= 1) {
            $error = '你是当前唯一的站长，注销后站点将无人管理。请先在后台将其他用户设为站长后再注销';
        }
    }

    if (!$error) {
        try {
            delete_account_cascade($user['id']);
            // 销毁登录会话
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $p = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
            }
            session_destroy();
            header('Location: index.php?account_cancelled=1');
            exit;
        } catch (Exception $ex) {
            $error = '注销失败：' . $ex->getMessage();
        }
    }
}

$pageTitle = '注销账号';
$currentPage = 'profile';
include __DIR__ . '/_header.php';

// 将被清理的数据统计
$uid = (int) $user['id'];
$cntPosts    = (int) db()->query("SELECT COUNT(*) FROM posts WHERE user_id = {$uid}")->fetchColumn();
$cntTiebas   = (int) db()->query("SELECT COUNT(*) FROM tiebas WHERE owner_id = {$uid}")->fetchColumn();
$cntComments = (int) db()->query("SELECT COUNT(*) FROM comments WHERE user_id = {$uid}")->fetchColumn();
$cntFollowT  = (int) db()->query("SELECT COUNT(*) FROM tieba_follows WHERE user_id = {$uid}")->fetchColumn();
$cntFollowing= (int) db()->query("SELECT COUNT(*) FROM user_follows WHERE follower_id = {$uid}")->fetchColumn();
$cntFollowers= (int) db()->query("SELECT COUNT(*) FROM user_follows WHERE following_id = {$uid}")->fetchColumn();
// 自己创建的贴吧内、由他人发布的帖子（会连带删除）
$cntOthersPosts = 0;
if ($cntTiebas > 0) {
    $cntOthersPosts = (int) db()->query("SELECT COUNT(*) FROM posts WHERE user_id != {$uid} AND tieba_id IN (SELECT id FROM tiebas WHERE owner_id = {$uid})")->fetchColumn();
}
?>

<div class="win-center">
    <div class="auth-card" style="max-width:620px;text-align:left;">

        <?php if ($error): ?>
        <div class="win-tip win-tip-error">
            <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
        </div>
        <?php endif; ?>

        <form method="post">

            <!-- 危险提示 -->
            <div class="win-card" style="background:linear-gradient(135deg,#fee2e2,#fef2f2);border-color:#fecaca;text-align:center;padding:26px 20px;">
                <div style="width:64px;height:64px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,#ef4444,#f97316);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 20px rgba(239,68,68,.3);">
                    <i class="fa fa-user-times" style="color:#fff;font-size:28px;"></i>
                </div>
                <h2 style="font-size:18px;font-weight:700;color:#b91c1c;margin-top:14px;">注销后无法恢复</h2>
                <p style="font-size:13px;color:#9f1239;margin-top:6px;line-height:1.7;">
                    注销是永久操作，你的账号和以下所有内容将被<strong>彻底删除</strong>，<br>
                    请谨慎操作。
                </p>
            </div>

            <!-- 将删除的数据 -->
            <div class="win-card">
                <div class="win-card-title" style="margin-bottom:12px;"><i class="fa fa-list-ul" style="color:#ef4444;"></i> 以下内容将被清除</div>
                <div style="display:flex;flex-direction:column;gap:11px;font-size:13px;color:var(--text-soft);">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-file-text-o"></i></span>
                        <span style="flex:1;">我发布的动态</span>
                        <strong style="color:#ef4444;"><?= $cntPosts ?> 条</strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-image"></i></span>
                        <span style="flex:1;">上传的图片、视频等文件</span>
                        <strong style="color:#ef4444;">全部删除</strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-comments-o"></i></span>
                        <span style="flex:1;">我的评论</span>
                        <strong style="color:#ef4444;"><?= $cntComments ?> 条</strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-heart-o"></i></span>
                        <span style="flex:1;">我的点赞与收藏</span>
                        <strong style="color:#ef4444;">全部清除</strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-users"></i></span>
                        <span style="flex:1;">关注的贴吧 / 关注与粉丝</span>
                        <strong style="color:#ef4444;"><?= $cntFollowT ?> / <?= $cntFollowing ?> / <?= $cntFollowers ?></strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-envelope-o"></i></span>
                        <span style="flex:1;">我的私信与通知消息</span>
                        <strong style="color:#ef4444;">全部清除</strong>
                    </div>
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="width:32px;height:32px;border-radius:9px;background:#fee2e2;color:#ef4444;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fa fa-user-circle-o"></i></span>
                        <span style="flex:1;">头像与账号资料</span>
                        <strong style="color:#ef4444;">全部删除</strong>
                    </div>
                </div>
            </div>

            <!-- 创建的贴吧 -->
            <div class="win-card" style="border-color:#fecaca;">
                <div style="font-size:14px;font-weight:600;margin-bottom:8px;display:flex;align-items:center;gap:6px;color:#b91c1c;">
                    <i class="fa fa-bullhorn"></i> 我创建的贴吧（<?= $cntTiebas ?> 个）
                </div>
                <p style="font-size:12.5px;color:var(--text-soft);line-height:1.7;">
                    你创建的贴吧属于你的“组织”，注销账号后这些贴吧会连同帖子、封面图片一并删除。
                    <?php if ($cntOthersPosts > 0): ?>
                    <br><span style="color:#dc2626;font-weight:600;">注意：其中有 <?= $cntOthersPosts ?> 条其他成员发布的动态也会被一并清除，建议注销前先在「我的贴吧」中妥善处理。</span>
                    <?php endif; ?>
                </p>
            </div>

            <!-- 密码确认 -->
            <div class="form-group">
                <label class="form-label"><i class="fa fa-lock" style="color:#ef4444;"></i> 输入登录密码以验证身份</label>
                <input type="password" name="password" class="form-input" placeholder="请输入当前账号密码" required autocomplete="off">
            </div>

            <!-- 勾选确认 -->
            <label style="display:flex;align-items:flex-start;gap:10px;padding:12px 14px;background:rgba(254,226,226,.5);border-radius:10px;cursor:pointer;margin-bottom:16px;">
                <input type="checkbox" name="confirm" value="1" style="margin-top:3px;width:16px;height:16px;accent-color:#ef4444;" required>
                <span style="font-size:13px;color:#9f1239;line-height:1.6;">
                    我已知晓注销后账号、我创建的贴吧、所有动态、图片/视频文件、评论、点赞收藏、关注关系和消息都将被<strong>永久删除且无法恢复</strong>。
                </span>
            </label>

            <button type="submit" class="btn btn-block" onclick="return confirm('确定要永久注销账号吗？此操作无法撤销！')"
                    style="padding:13px;font-size:14px;background:linear-gradient(135deg,#ef4444,#f97316);color:#fff;border:none;border-radius:9px;font-weight:600;box-shadow:0 8px 20px rgba(239,68,68,.3);">
                <i class="fa fa-user-times"></i> 确认永久注销
            </button>

            <a href="index.php?page=profile" class="btn btn-ghost btn-block" style="padding:12px;margin-top:10px;">
                我再想想，返回
            </a>
        </form>
    </div>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
