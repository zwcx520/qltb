<?php
/**
 * Windows 版 - 联系站长会话
 * 功能与 pages/contact_chat.php 完全一致：
 * 未登录游客（username 查询）/已登录用户/管理员（uid 指定用户）三种视图、
 * 对话列表（type=contact）、标记已读、回复发送、越权防护（仅管理员可看他人会话）
 */
$pageTitle = '联系站长';
$currentPage = '';

// 获取管理员
$admin = db()->query("SELECT id, nickname, avatar FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1")->fetch();

// 确定对话用户
$chatUser = null;
$isAdminView = false;

if ($admin) {
    if ($user) {
        // 已登录
        if (($user['role'] ?? '') === 'admin' && isset($_GET['uid'])) {
            // 管理员查看指定用户
            $chatUid = intval($_GET['uid']);
            $stmt = db()->prepare("SELECT id, username, nickname, avatar FROM users WHERE id = ?");
            $stmt->execute([$chatUid]);
            $chatUser = $stmt->fetch();
            $isAdminView = true;
        } else {
            $chatUser = ['id' => $user['id'], 'username' => $user['username'], 'nickname' => $user['nickname'], 'avatar' => $user['avatar']];
        }
    } else {
        // 未登录：通过用户名查询
        $username = trim($_GET['username'] ?? '');
        if ($username) {
            $stmt = db()->prepare("SELECT id, username, nickname, avatar FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $chatUser = $stmt->fetch();
        }
    }
}

// 发送新消息
$sendError = '';
if ($admin && $chatUser && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_content'])) {
    $content = trim($_POST['reply_content'] ?? '');
    if (mb_strlen($content) < 1) {
        $sendError = '请输入回复内容';
    } elseif (mb_strlen($content) > 500) {
        $sendError = '内容不能超过500个字符';
    } else {
        if ($isAdminView) {
            // 管理员回复用户
            db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, is_read, created_at) VALUES (?, ?, 'contact', ?, 0, NOW())")
                ->execute([$user['id'], $chatUser['id'], $content]);
        } else {
            // 用户发送给管理员
            db()->prepare("INSERT INTO messages (from_user_id, to_user_id, type, content, is_read, created_at) VALUES (?, ?, 'contact', ?, 0, NOW())")
                ->execute([$chatUser['id'], $admin['id'], $content]);
        }
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    }
}

// 加载对话记录 + 标记已读
$msgs = [];
if ($admin && $chatUser) {
    $uid = $chatUser['id'];
    $aid = $admin['id'];
    $msgs = db()->query("
        SELECT m.*, u.nickname, u.avatar
        FROM messages m
        LEFT JOIN users u ON m.from_user_id = u.id
        WHERE m.type = 'contact'
          AND ((m.from_user_id = {$uid} AND m.to_user_id = {$aid}) OR (m.from_user_id = {$aid} AND m.to_user_id = {$uid}))
        ORDER BY m.created_at ASC
    ")->fetchAll();

    // 标记对方发的消息为已读
    if ($user) {
        $myId = $user['id'];
        db()->exec("UPDATE messages SET is_read = 1 WHERE type = 'contact' AND to_user_id = {$myId} AND from_user_id = " . ($isAdminView ? $uid : $aid));
    } elseif ($chatUser) {
        // 未登录用户查看，标记管理员发给该用户的消息为已读
        db()->exec("UPDATE messages SET is_read = 1 WHERE type = 'contact' AND to_user_id = {$uid} AND from_user_id = {$aid}");
    }
}

$otherName = $isAdminView ? ($chatUser['nickname'] ?: $chatUser['username']) : '站长';
$backUrl = $user ? 'index.php?page=message&type=contact' : 'index.php?page=contact';

include __DIR__ . '/_header.php';
?>

<style>
.chat-header { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; }
.chat-form-row { display: flex; gap: 10px; align-items: center; }
</style>

<div class="chat-header">
    <a href="<?= $backUrl ?>" class="btn btn-ghost btn-sm"><i class="fa fa-angle-left"></i> 返回</a>
    <div style="flex:1;">
        <div style="font-size:16px;font-weight:700;">
            <?php if ($admin && $chatUser): ?><?= e($otherName) ?>
            <?php else: ?>联系站长<?php endif; ?>
        </div>
        <div style="font-size:11px;color:var(--text-light);">
            <?php if ($admin && $chatUser && $isAdminView): ?>@<?= e($chatUser['username']) ?>
            <?php elseif ($admin && $chatUser): ?>在线客服<?php endif; ?>
        </div>
    </div>
</div>

<?php if (!$admin): ?>
    <!-- 系统异常 -->
    <div class="win-card empty"><i class="fa fa-exclamation-triangle"></i><p>系统异常：未找到管理员</p></div>
<?php elseif (!$chatUser): ?>
    <!-- 未找到用户：输入用户名查询（游客找回留言场景） -->
    <div class="win-card" style="text-align:center;background:linear-gradient(135deg,#fce7f3,#ddd6fe);border:none;">
        <i class="fa fa-search" style="font-size:30px;color:var(--accent);"></i>
        <div style="font-size:15px;font-weight:700;margin-top:10px;">输入用户名查看站长回复</div>
        <div style="font-size:12px;color:var(--text-soft);margin-top:4px;">忘记密码也能查看留言哦</div>
    </div>
    <div class="win-card">
        <form method="get" action="index.php">
            <input type="hidden" name="page" value="contact_chat">
            <div class="form-group">
                <label class="form-label"><i class="fa fa-user" style="color:var(--accent);"></i> 用户名</label>
                <input name="username" class="form-input" placeholder="请输入你的用户名" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block"><i class="fa fa-search"></i> 查询留言</button>
        </form>
        <div style="text-align:center;margin-top:14px;">
            <a href="index.php?page=login" style="font-size:13px;color:var(--accent);">想起密码了？去登录</a>
        </div>
    </div>
<?php else: ?>
    <!-- 对话内容 -->
    <div class="win-card">
        <div class="chat-box" id="chat-box">
            <?php if (empty($msgs)): ?>
                <div style="text-align:center;padding:50px 20px;color:var(--text-soft);margin:auto;">
                    <i class="fa fa-comments-o" style="font-size:36px;color:#ddd6fe;"></i>
                    <div style="margin-top:12px;font-size:14px;">还没有留言</div>
                    <div style="font-size:12px;margin-top:4px;">在下方输入框发送第一条消息吧</div>
                </div>
            <?php else: ?>
                <?php foreach ($msgs as $m):
                    $isMe = $isAdminView ? ($m['from_user_id'] == $user['id']) : ($m['from_user_id'] == $chatUser['id']);
                ?>
                <div class="chat-msg <?= $isMe ? 'me' : '' ?>">
                    <img src="<?= e(avatar(['id'=>$m['from_user_id'],'avatar'=>$m['avatar'],'nickname'=>$m['nickname']])) ?>" class="chat-avatar" alt="">
                    <div style="max-width:100%;">
                        <div class="chat-time" style="<?= $isMe ? 'text-align:right;' : '' ?>"><?= e($m['nickname'] ?: ($isMe ? '我' : '站长')) ?> · <?= time_ago($m['created_at']) ?></div>
                        <div class="chat-bubble" style="margin-top:3px;"><?= nl2br(e($m['content'])) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- 回复输入框 -->
        <div class="comment-input-row" style="margin-top:14px;padding-top:14px;border-top:1px solid #f1f1f5;">
            <form method="post" class="chat-form-row" style="flex:1;">
                <input type="text" name="reply_content" class="form-input" placeholder="输入回复内容..." maxlength="500" style="flex:1;" autofocus>
                <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                    <i class="fa fa-paper-plane"></i> 发送
                </button>
            </form>
        </div>
        <?php if ($sendError): ?>
            <div class="win-tip win-tip-error" style="margin:10px 0 0;"><i class="fa fa-exclamation-circle"></i> <?= e($sendError) ?></div>
        <?php endif; ?>
    </div>

    <script>
    // 对话自动滚动到底部
    (function () {
        var b = document.getElementById('chat-box');
        if (b) b.scrollTop = b.scrollHeight;
    })();
    </script>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
