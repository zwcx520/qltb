<?php
/**
 * Windows 版 - 发现页
 * 功能与 pages/discover.php 完全一致：搜索、分类筛选、全部贴吧列表、创建贴吧（封面/图标/分类，创建后自动关注）、热门帖子
 */
$kw = trim($_GET['kw'] ?? '');

// 创建贴吧处理
$createMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['act'] ?? '') === 'create_tieba') {
    if (!$user) { $createMsg = '请先登录'; }
    else {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $icon = $_POST['icon'] ?? 'tree';
        $cat  = trim($_POST['category'] ?? '');
        if (mb_strlen($name) < 2 || mb_strlen($name) > 20) {
            $createMsg = '贴吧名称需2-20个字符';
        } else {
            // 检查重名
            $chk = db()->prepare("SELECT id FROM tiebas WHERE name = ?");
            $chk->execute([$name]);
            if ($chk->fetch()) {
                $createMsg = '该贴吧名称已存在';
            } else {
                // 处理封面图上传
                $cover = '';
                if (!empty($_FILES['cover']['name'])) {
                    $r = handle_upload($_FILES['cover'], ['jpg','jpeg','png','gif','webp'], 5242880);
                    if ($r['ok']) $cover = $r['url'];
                }
                $stmt = db()->prepare("INSERT INTO tiebas (name, description, icon, cover, category, owner_id, members, created_at) VALUES (?,?,?,?,?,?,1,NOW())");
                $stmt->execute([$name, $desc, $icon, $cover, $cat, $user['id']]);
                $newId = db()->lastInsertId();
                // 创建者自动加入
                db()->prepare("INSERT INTO tieba_follows (tieba_id, user_id, created_at) VALUES (?,?,NOW())")->execute([$newId, $user['id']]);
                header('Location: index.php?page=tieba&id=' . $newId);
                exit;
            }
        }
    }
}

// 贴吧列表
$tiebas = db()->query("SELECT * FROM tiebas ORDER BY hot DESC, members DESC")->fetchAll();

// 分类
$cats = db()->query("SELECT * FROM categories ORDER BY sort ASC")->fetchAll();
$catColors = ['#f472b6','#fb923c','#fbbf24','#a78bfa','#60a5fa','#34d399'];

// 热门帖子（仅公开帖，私密帖不进入全站推荐）
$hotPosts = db()->query("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.role, u.posts, t.name as tieba_name
    FROM posts p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.status = 1 AND p.visibility = 'public' ORDER BY p.likes DESC, p.comments DESC LIMIT 10
")->fetchAll();

$pageTitle = '发现';
$currentPage = 'discover';
include __DIR__ . '/_header.php';
?>

<style>
/* 页面级样式：搜索栏 / 图标选择 / 封面上传 */
.dt-search {
    display: flex; align-items: center; gap: 10px;
    background: #fff; border: 1px solid var(--border); border-radius: 22px;
    padding: 12px 20px; box-shadow: var(--shadow);
    transition: border .15s, box-shadow .15s;
}
.dt-search:focus-within { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(168,85,247,.12); }
.dt-search i { color: var(--text-light); }
.dt-search input { flex: 1; border: none; background: none; color: var(--text); font-size: 14px; }
.dt-search input::placeholder { color: var(--text-light); }
.icon-select-wrap { display: flex; align-items: center; gap: 10px; }
.icon-preview {
    width: 42px; height: 42px; border-radius: 10px; flex-shrink: 0;
    background: #faf7ff; border: 1px solid var(--border);
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; color: var(--accent);
}
.cover-upload {
    position: relative; width: 100%; height: 132px;
    border: 2px dashed #d8c8ee; border-radius: 12px;
    display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 5px;
    cursor: pointer; background: #faf7ff; overflow: hidden; transition: border .15s;
}
.cover-upload:hover { border-color: var(--accent); }
.cover-upload .fa-cloud-upload { color: #a78bfa; font-size: 24px; }
.cover-upload span { font-size: 12px; color: var(--text-light); }
.cover-remove {
    position: absolute; top: 8px; right: 8px; z-index: 2;
    width: 26px; height: 26px; border-radius: 50%;
    background: rgba(0,0,0,.6); color: #fff; border: none; cursor: pointer; font-size: 14px;
    display: none; align-items: center; justify-content: center;
}
</style>

<!-- 搜索栏 -->
<form action="index.php" method="get" class="dt-search" onsubmit="if(!this.kw.value.trim())return false;">
    <i class="fa fa-search"></i>
    <input type="hidden" name="page" value="search">
    <input type="text" name="kw" value="<?= e($kw) ?>" placeholder="搜索贴吧、帖子、用户...">
</form>

<!-- 分类筛选 -->
<div class="cat-grid" style="margin-top:14px;">
    <a href="index.php?page=discover" class="cat-chip active"><i class="fa fa-compass"></i> 全部</a>
    <?php foreach ($cats as $i => $c): ?>
        <a href="index.php?page=discover&cat=<?= $c['id'] ?>" class="cat-chip">
            <i class="fa fa-<?= e($c['icon']) ?>" style="color:<?= $catColors[$i % count($catColors)] ?>"></i> <?= e($c['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- 全部贴吧 -->
<div class="win-section-title">
    <span><i class="fa fa-compass"></i> 全部贴吧</span>
    <?php if ($user): ?>
    <a href="javascript:;" id="show-create-tieba" class="more" style="color:var(--accent);"><i class="fa fa-plus-circle"></i> 创建贴吧</a>
    <?php endif; ?>
</div>

<!-- 创建贴吧表单 -->
<?php if ($user): ?>
<div id="create-tieba-form" class="win-card" style="display:<?= $createMsg ? 'block' : 'none' ?>;">
    <div class="win-card-title"><i class="fa fa-flag"></i> 创建贴吧</div>
    <?php if ($createMsg): ?>
    <div class="win-tip win-tip-error"><i class="fa fa-exclamation-circle"></i> <?= e($createMsg) ?></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="act" value="create_tieba">
        <div class="grid-2">
            <div>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-image"></i> 贴吧封面（可选，不上传则使用图标）</label>
                    <div id="cover-upload-area" class="cover-upload">
                        <input type="file" id="cover-input" name="cover" accept="image/*" style="display:none;">
                        <i class="fa fa-cloud-upload"></i>
                        <span>点击上传封面图</span>
                        <img id="cover-preview" style="display:none;width:100%;height:100%;object-fit:cover;position:absolute;inset:0;" alt="">
                        <button type="button" id="cover-remove" class="cover-remove">×</button>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-tag"></i> 所属分类</label>
                    <select name="category" class="form-select">
                        <option value="">未分类</option>
                        <?php foreach ($cats as $c): ?>
                        <option value="<?= e($c['name']) ?>"><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-font"></i> 贴吧名称 <span style="color:var(--danger);">*</span></label>
                    <input type="text" name="name" maxlength="20" required placeholder="2-20个字符" class="form-input">
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-pencil"></i> 贴吧简介</label>
                    <textarea name="description" maxlength="100" rows="3" placeholder="一句话介绍你的贴吧..." class="form-textarea" style="min-height:0;resize:none;"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-smile-o"></i> 选择图标</label>
                    <?= icon_select('icon') ?>
                </div>
            </div>
        </div>
        <div style="display:flex;gap:10px;justify-content:flex-end;border-top:1px solid var(--border);padding-top:14px;">
            <button type="button" id="cancel-create" class="btn btn-ghost">取消</button>
            <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> 创建贴吧</button>
        </div>
    </form>
</div>

<script>
// 切换创建贴吧表单
document.getElementById('show-create-tieba').addEventListener('click', function(){
    var f = document.getElementById('create-tieba-form');
    f.style.display = f.style.display === 'none' ? 'block' : 'none';
    if (f.style.display === 'block') f.scrollIntoView({behavior:'smooth', block:'center'});
});
document.getElementById('cancel-create').addEventListener('click', function(){
    document.getElementById('create-tieba-form').style.display = 'none';
});
// 封面图上传预览
var coverArea = document.getElementById('cover-upload-area');
var coverInput = document.getElementById('cover-input');
var coverPreview = document.getElementById('cover-preview');
var coverRemove = document.getElementById('cover-remove');
if (coverArea && coverInput) {
    coverArea.addEventListener('click', function(e){
        if (e.target !== coverRemove) coverInput.click();
    });
    coverInput.addEventListener('change', function(){
        if (this.files && this.files[0]) {
            coverPreview.src = URL.createObjectURL(this.files[0]);
            coverPreview.style.display = 'block';
            coverRemove.style.display = 'flex';
            coverArea.querySelector('.fa-cloud-upload').style.display = 'none';
            coverArea.querySelector('span').style.display = 'none';
        }
    });
    coverRemove.addEventListener('click', function(e){
        e.stopPropagation();
        coverInput.value = '';
        coverPreview.src = '';
        coverPreview.style.display = 'none';
        coverRemove.style.display = 'none';
        coverArea.querySelector('.fa-cloud-upload').style.display = '';
        coverArea.querySelector('span').style.display = '';
    });
}
</script>
<?php endif; ?>

<!-- 贴吧网格 -->
<?php if (empty($tiebas)): ?>
<div class="win-card empty"><i class="fa fa-leaf"></i><p>还没有任何贴吧，快来创建第一个吧 ~</p></div>
<?php else: ?>
<div class="grid-2">
    <?php foreach ($tiebas as $t): ?>
        <a href="index.php?page=tieba&id=<?= $t['id'] ?>" class="tieba-row">
            <div class="tieba-cover-sm" style="background:<?= cover($t) ?>">
                <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
            </div>
            <div style="flex:1;min-width:0;">
                <div class="tieba-row-name"><?= e($t['name']) ?> <?php if ($t['hot'] > 0): ?><span class="tag tag-hot">HOT</span><?php endif; ?></div>
                <div class="tieba-row-desc"><?= e($t['description']) ?></div>
                <div class="tieba-row-meta"><i class="fa fa-users"></i> <?= $t['members'] ?> 成员 · <i class="fa fa-file-text-o"></i> <?= $t['posts'] ?> 帖子</div>
            </div>
        </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- 热门帖子 -->
<div class="win-section-title"><span><i class="fa fa-fire"></i> 热门帖子</span></div>

<?php if (empty($hotPosts)): ?>
<div class="win-card empty"><i class="fa fa-leaf"></i><p>还没有热门帖子 ~</p></div>
<?php else: ?>
    <?php foreach ($hotPosts as $p):
        $liked = is_liked($p['id']);
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
    ?>
    <div class="post-card">
        <div class="post-header">
            <a href="index.php?page=user&id=<?= $p['user_id'] ?>">
                <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar" alt="">
            </a>
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname']) ?> <?= user_label($p) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?> · <?= e($p['tieba_name']) ?></div>
            </div>
        </div>
        <a href="index.php?page=post&id=<?= $p['id'] ?>">
            <?php if ($p['title']): ?><div class="post-title"><?= e($p['title']) ?></div><?php endif; ?>
            <div class="post-content"><?= nl2br(e($p['content'])) ?></div>
        </a>
        <?php if (!empty($imgs)): ?>
            <div class="post-images <?= count($imgs)===1?'single':(count($imgs)===2?'double':'triple') ?>">
                <?php foreach (array_slice($imgs,0,3) as $img): ?>
                    <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')" alt="">
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <div class="post-actions">
            <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i><span class="count"><?= $p['likes'] ?></span>
            </div>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-action"><i class="fa fa-comment-o"></i><span><?= $p['comments'] ?></span></a>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
