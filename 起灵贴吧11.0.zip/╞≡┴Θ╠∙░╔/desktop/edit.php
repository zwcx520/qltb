<?php
/**
 * Windows 版 - 编辑资料页
 * 功能与 pages/edit.php 完全一致：保存资料（含头像上传）+ 修改密码（action=change_password）
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$msg = '';
$msgType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'change_password') {
        // 修改密码
        $oldPwd  = $_POST['old_password'] ?? '';
        $newPwd  = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($oldPwd === '' || $newPwd === '' || $confirm === '') {
            $msg = '请填写完整的密码信息';
            $msgType = 'error';
        } elseif (!verify_password($oldPwd, $user['password'])) {
            $msg = '当前密码错误，请重新输入';
            $msgType = 'error';
        } elseif (strlen($newPwd) < 6) {
            $msg = '新密码至少6个字符';
            $msgType = 'error';
        } elseif ($newPwd !== $confirm) {
            $msg = '两次输入的新密码不一致';
            $msgType = 'error';
        } elseif ($oldPwd === $newPwd) {
            $msg = '新密码不能与当前密码相同';
            $msgType = 'error';
        } else {
            $stmt = db()->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([hash_password($newPwd), $user['id']]);
            $msg = '密码修改成功，下次登录请使用新密码';
        }
    } else {
        // 保存资料
        $nickname = trim($_POST['nickname'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $email = trim($_POST['email'] ?? '');

        // 头像上传
        $avatar = $user['avatar'];
        if (!empty($_FILES['avatar']['name'])) {
            $r = handle_upload($_FILES['avatar'], ['jpg','jpeg','png','gif','webp'], 5242880);
            if ($r['ok']) {
                // 上传成功，删除旧头像文件（覆盖原图片）
                if (!empty($user['avatar'])) {
                    delete_uploaded_file($user['avatar']);
                }
                $avatar = $r['url'];
            } else {
                $msg = '头像上传失败: ' . $r['msg'];
                $msgType = 'error';
            }
        }

        if ($msgType === 'success') {
            $stmt = db()->prepare("UPDATE users SET nickname = ?, bio = ?, email = ?, avatar = ? WHERE id = ?");
            $stmt->execute([$nickname, $bio, $email, $avatar, $user['id']]);
            $msg = '保存成功';
            $user = current_user(); // 刷新
        }
    }
}

$pageTitle = '编辑资料';
$currentPage = 'profile';
include __DIR__ . '/_header.php';
?>

<?php if ($msg): ?>
    <div class="win-tip <?= $msgType === 'error' ? 'win-tip-error' : 'win-tip-success' ?>">
        <i class="fa fa-<?= $msgType === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
    <div class="win-card">
        <div class="win-card-title"><i class="fa fa-pencil"></i> 编辑资料</div>

        <!-- 头像 -->
        <div class="form-group" style="text-align:center;">
            <label class="form-label">头像</label>
            <label for="avatar-input" style="cursor:pointer;display:inline-block;position:relative;">
                <img id="avatar-preview" src="<?= e(avatar($user)) ?>" class="avatar-lg" style="box-shadow:var(--shadow-lg);">
                <span style="position:absolute;bottom:0;right:0;width:28px;height:28px;border-radius:50%;background:var(--grad);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;border:2px solid #fff;">
                    <i class="fa fa-camera"></i>
                </span>
            </label>
            <input type="file" id="avatar-input" name="avatar" accept="image/*" style="display:none;">
            <div class="form-hint" style="text-align:center;">点击头像更换，支持 JPG/PNG/GIF，最大 5MB</div>
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-user" style="color:var(--accent);margin-right:4px;"></i> 用户名</label>
            <input class="form-input" value="<?= e($user['username']) ?>" disabled>
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-smile-o" style="color:var(--accent);margin-right:4px;"></i> 昵称</label>
            <input name="nickname" class="form-input" value="<?= e($user['nickname']) ?>" maxlength="50">
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-envelope" style="color:var(--accent);margin-right:4px;"></i> 邮箱</label>
            <input name="email" type="email" class="form-input" value="<?= e($user['email']) ?>">
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-quote-left" style="color:var(--accent);margin-right:4px;"></i> 个性签名</label>
            <textarea name="bio" class="form-textarea" maxlength="200" placeholder="一句话介绍自己..."><?= e($user['bio']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary btn-block" style="padding:13px;margin-top:4px;">
            <i class="fa fa-save"></i> 保存修改
        </button>
    </div>
</form>

<!-- 账号安全：修改密码 -->
<div style="display:flex;align-items:center;gap:10px;margin:20px 0 14px;color:var(--text-light);font-size:13px;">
    <div style="flex:1;height:1px;background:var(--border);"></div>
    <span><i class="fa fa-shield"></i> 账号安全</span>
    <div style="flex:1;height:1px;background:var(--border);"></div>
</div>

<form method="post">
    <input type="hidden" name="action" value="change_password">
    <div class="win-card">
        <div class="win-card-title"><i class="fa fa-shield"></i> 修改密码</div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock" style="color:var(--accent);margin-right:4px;"></i> 当前密码</label>
            <input name="old_password" type="password" class="form-input" placeholder="请输入当前密码" autocomplete="current-password" required>
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-key" style="color:var(--accent);margin-right:4px;"></i> 新密码</label>
            <input name="new_password" type="password" class="form-input" placeholder="至少6个字符" autocomplete="new-password" minlength="6" required>
        </div>

        <div class="form-group">
            <label class="form-label"><i class="fa fa-check-circle" style="color:var(--accent);margin-right:4px;"></i> 确认新密码</label>
            <input name="confirm_password" type="password" class="form-input" placeholder="再次输入新密码" autocomplete="new-password" minlength="6" required>
        </div>

        <button type="submit" class="btn btn-ghost btn-block" style="padding:13px;margin-top:4px;">
            <i class="fa fa-shield"></i> 修改密码
        </button>
    </div>
</form>

<script>
// 头像即时预览
document.getElementById('avatar-input').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('avatar-preview').src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
    }
});
</script>

<?php include __DIR__ . '/_footer.php'; ?>
