<?php
/**
 * Windows 版 - 文件详情页（独立页面）
 * 展示文件与发布者信息；点击「立即下载」时，设置密码的文件需先输入提取密码；本人可管理文件
 */
$fileId = intval($_GET['id'] ?? 0);

$stmt = db()->prepare("SELECT f.*, u.username, u.nickname, u.avatar, u.bio, u.role, u.posts FROM user_files f
    JOIN users u ON f.user_id = u.id WHERE f.id = ?");
$stmt->execute([$fileId]);
$file = $stmt->fetch();

$msg = '';
$msgType = 'success';
$isOwner = false;

if ($file) {
    $isOwner = $user && ($user['id'] == $file['user_id']);
    $unlocked = file_unlock_valid($file['id']);
    $needPassword = ($file['password'] !== '') && !$isOwner && !$unlocked;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        if ($action === 'delete' && $isOwner) {
            db()->prepare("DELETE FROM user_files WHERE id = ? AND user_id = ?")->execute([$file['id'], $user['id']]);
            delete_uploaded_file($file['file']);
            $dir = __DIR__ . '/../assets/uploads/files/' . files_folder_name($user['username']);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
            header('Location: index.php?page=files');
            exit;
        }

        if ($action === 'save' && $isOwner) {
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $newPassword = (string)($_POST['password'] ?? '');
            $removePassword = !empty($_POST['remove_password']);

            $pwdHash = $file['password'];
            if ($removePassword) {
                $pwdHash = '';
            } elseif ($newPassword !== '') {
                if (strlen($newPassword) < 4) {
                    $msg = '提取密码至少 4 个字符';
                    $msgType = 'error';
                } else {
                    $pwdHash = password_hash($newPassword, PASSWORD_DEFAULT);
                }
            }

            if ($msgType !== 'error') {
                if ($name === '') $name = $file['name'];
                db()->prepare("UPDATE user_files SET name = ?, description = ?, password = ? WHERE id = ? AND user_id = ?")
                    ->execute([mb_substr($name, 0, 200), mb_substr($description, 0, 255), $pwdHash, $file['id'], $user['id']]);
                $file['name'] = mb_substr($name, 0, 200);
                $file['description'] = mb_substr($description, 0, 255);
                $file['password'] = $pwdHash;
                $msg = '设置已保存';
            }
        }

        if ($action === 'unlock' && !$isOwner && $file['password'] !== '') {
            $pwd = (string)($_POST['password'] ?? '');
            if ($pwd === '') {
                $msg = '请输入提取密码';
                $msgType = 'error';
            } elseif (!password_verify($pwd, $file['password'])) {
                $msg = '提取密码错误，请重试';
                $msgType = 'error';
            } else {
                file_unlock_mark($file['id']);
                header('Location: index.php?page=file&id=' . $file['id']);
                exit;
            }
        }

        $unlocked = file_unlock_valid($file['id']);
        $needPassword = ($file['password'] !== '') && !$isOwner && !$unlocked;
    }
}

$pageTitle = $file ? $file['name'] : '文件详情';
$currentPage = 'profile';
include __DIR__ . '/_header.php';
?>

<?php if (!$file): ?>
    <div class="win-card">
        <div class="empty">
            <i class="fa fa-folder-open-o"></i>
            <p>文件不存在或已被删除</p>
            <a href="index.php" class="btn btn-ghost btn-sm" style="margin-top:12px;">返回首页</a>
        </div>
    </div>
<?php else: ?>

<?php if ($msg): ?>
    <div class="win-tip <?= $msgType === 'error' ? 'win-tip-error' : 'win-tip-success' ?>">
        <i class="fa fa-<?= $msgType === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<div class="win-card">
    <div style="display:flex;align-items:center;gap:16px;">
        <div style="width:64px;height:64px;border-radius:14px;background:var(--grad);color:#fff;display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;">
            <i class="fa <?= e(file_icon($file['ext'])) ?>"></i>
        </div>
        <div style="flex:1;min-width:0;">
            <div style="font-size:17px;font-weight:700;word-break:break-all;"><?= e($file['name']) ?></div>
            <div style="font-size:12px;color:var(--text-light);margin-top:6px;">
                <?= human_size($file['filesize']) ?> · <i class="fa fa-download"></i> <?= intval($file['downloads']) ?> 次下载 · <?= time_ago($file['created_at']) ?>
                <?php if (!empty($file['password'])): ?>
                    <span style="font-size:11px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:2px 8px;margin-left:4px;"><i class="fa fa-lock"></i> 需要密码</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if (!empty($file['description'])): ?>
        <div style="margin-top:14px;padding:10px 12px;background:rgba(0,0,0,.03);border-radius:10px;font-size:12.5px;color:var(--text-soft);line-height:1.7;word-break:break-word;">
            <?= e($file['description']) ?>
        </div>
    <?php endif; ?>

    <!-- 发布者信息（并入文件信息卡） -->
    <div style="margin-top:14px;padding-top:14px;border-top:1px solid #f1f1f5;">
        <div style="font-size:12px;color:var(--text-light);margin-bottom:10px;"><i class="fa fa-user-circle-o"></i> 发布者</div>
        <div style="display:flex;align-items:center;gap:14px;">
            <img src="<?= e(avatar(['id' => $file['user_id'], 'avatar' => $file['avatar'], 'username' => $file['username']])) ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover;flex-shrink:0;">
            <div style="flex:1;min-width:0;">
                <div style="font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                    <?= e($file['nickname'] ?: $file['username']) ?>
                    <?= user_label(['role' => $file['role'], 'posts' => $file['posts']]) ?>
                </div>
                <div style="font-size:12px;color:var(--text-light);margin-top:3px;">@<?= e($file['username']) ?> · <?= intval($file['posts']) ?> 条动态</div>
            </div>
            <a href="index.php?page=user&id=<?= $file['user_id'] ?>" class="btn btn-ghost btn-sm"><i class="fa fa-user"></i> 查看主页</a>
        </div>
        <div style="margin-top:10px;font-size:12.5px;color:var(--text-soft);line-height:1.7;word-break:break-word;">
            <?= e($file['bio'] ?: 'TA 还没有填写简介') ?>
        </div>
    </div>
</div>

<div class="win-card" style="margin-top:16px;">
    <div class="win-card-title"><i class="fa fa-download"></i> 下载</div>
    <?php if (!$isOwner && !empty($file['password'])): ?>
        <!-- 密码视图：未验证或倒计时过期后显示，直接点下载再输入密码 -->
        <div id="dl-pwd" style="<?= $needPassword ? '' : 'display:none' ?>">
            <button type="button" class="btn btn-primary" style="padding:11px 22px;" onclick="document.getElementById('pwd-box').style.display='block';this.style.display='none';"><i class="fa fa-download"></i> 立即下载</button>
            <div id="pwd-box" style="display:none;margin-top:12px;">
                <div style="font-size:13px;color:var(--text-soft);margin-bottom:10px;">该文件已加密，请输入分享者提供的提取密码，验证通过后即可下载。</div>
                <form method="post" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="hidden" name="action" value="unlock">
                    <input type="password" name="password" class="form-input" placeholder="请输入提取密码" required style="flex:1;min-width:200px;">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-unlock-alt"></i> 验证密码并下载</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- 下载视图：无密码 / 本人 / 验证有效期内 -->
    <div id="dl-ready" style="<?= $needPassword ? 'display:none' : '' ?>">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <a href="index.php?page=download&id=<?= $file['id'] ?>" id="download-btn" class="btn btn-primary" style="padding:11px 22px;"><i class="fa fa-download"></i> 立即下载</a>
            <span id="download-url" style="font-size:12px;color:var(--text-light);word-break:break-all;"><?= e(site_base_url() . '/index.php?page=download&id=' . $file['id']) ?></span>
        </div>
        <?php if (!$isOwner && !empty($file['password'])): ?>
            <div id="unlock-hint" data-remain="<?= max(0, file_unlock_ttl() - (time() - (int)($_SESSION['file_unlock'][(int)$file['id']] ?? 0))) ?>" style="font-size:12px;color:#a855f7;margin-top:8px;">
                <i class="fa fa-check-circle"></i> 密码验证通过，<span id="unlock-remain">30</span> 秒内可直接下载
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($isOwner): ?>
<div class="win-card" style="margin-top:16px;">
    <div class="win-card-title"><i class="fa fa-cog"></i> 文件设置</div>
    <form method="post">
        <input type="hidden" name="action" value="save">
        <div class="form-group">
            <label class="form-label"><i class="fa fa-file-text-o" style="color:var(--accent);margin-right:4px;"></i> 文件名称</label>
            <input name="name" class="form-input" value="<?= e($file['name']) ?>" maxlength="200">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-quote-left" style="color:var(--accent);margin-right:4px;"></i> 文件说明</label>
            <textarea name="description" class="form-textarea" maxlength="255" placeholder="可填写文件内容、解压密码等信息..."><?= e($file['description']) ?></textarea>
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock" style="color:var(--accent);margin-right:4px;"></i> 提取密码</label>
            <input name="password" type="text" class="form-input" placeholder="<?= !empty($file['password']) ? '已设置密码，留空则不修改' : '留空表示不需要密码' ?>" autocomplete="off">
            <div class="form-hint">至少 4 个字符；设置后其他访客需输入密码才能获取下载链接。</div>
            <?php if (!empty($file['password'])): ?>
                <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-soft);margin-top:8px;">
                    <input type="checkbox" name="remove_password" value="1"> 取消密码（任何人都可直接下载）
                </label>
            <?php endif; ?>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
            <button type="submit" class="btn btn-primary" style="padding:11px 24px;"><i class="fa fa-save"></i> 保存设置</button>
            <a href="index.php?page=files" class="btn btn-ghost" style="padding:11px 24px;">返回文件库</a>
        </div>
    </form>
</div>

<form method="post" style="margin-top:12px;" onsubmit="return confirm('确定删除该文件吗？删除后将无法下载。');">
    <input type="hidden" name="action" value="delete">
    <button type="submit" class="btn btn-danger" style="padding:11px 24px;"><i class="fa fa-trash"></i> 删除文件</button>
</form>
<?php endif; ?>

<?php endif; ?>

<script>
(function(){
    var hint = document.getElementById('unlock-hint');
    if (!hint) return;
    var remain = parseInt(hint.getAttribute('data-remain'), 10) || 0;
    var span = document.getElementById('unlock-remain');
    if (span) span.textContent = remain;
    var t = setInterval(function(){
        remain--;
        if (remain <= 0) {
            clearInterval(t);
            hint.style.display = 'none';
            var pwd = document.getElementById('dl-pwd');
            var ready = document.getElementById('dl-ready');
            if (pwd) {
                if (ready) ready.style.display = 'none';
                pwd.style.display = 'block';
            }
            return;
        }
        if (span) span.textContent = remain;
    }, 1000);
})();
</script>

<?php include __DIR__ . '/_footer.php'; ?>
