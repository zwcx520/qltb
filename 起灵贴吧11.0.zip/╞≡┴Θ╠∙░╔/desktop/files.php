<?php
/**
 * Windows 版 - 我的文件库
 * 与 pages/files.php 功能一致：多文件上传（单个 ≤100MB）、列表、详情（改名/说明/提取密码）、分享、删除
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$msg = '';
$msgType = 'success';

// 上传体积超过 post_max_size 时 PHP 会清空 $_POST/$_FILES，这里给出明确提示
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES) && intval($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $msg = '上传内容超过服务器限制（post_max_size 当前为 ' . ini_get('post_max_size') . '），请调大后再试';
    $msgType = 'error';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'upload') {
        $files = $_FILES['files'] ?? null;
        if (!$files || !is_array($files['name'] ?? null)) {
            $msg = '请选择要上传的文件';
            $msgType = 'error';
        } else {
            $okCount = 0;
            $errors = [];
            foreach ($files['name'] as $i => $name) {
                if ($name === '' || $files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $one = [
                    'name'     => $name,
                    'type'     => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error'    => $files['error'][$i],
                    'size'     => $files['size'][$i],
                ];
                $r = handle_file_upload($one, $user['username']);
                if ($r['ok']) {
                    db()->prepare("INSERT INTO user_files (user_id, name, file, filesize, ext, created_at) VALUES (?, ?, ?, ?, ?, NOW())")
                        ->execute([$user['id'], mb_substr($name, 0, 200), $r['url'], $r['size'], $r['ext']]);
                    $okCount++;
                } else {
                    $errors[] = $name . '：' . $r['msg'];
                }
            }
            if ($okCount > 0) $msg = '成功上传 ' . $okCount . ' 个文件';
            if ($errors) {
                $msg = ($okCount > 0 ? $msg . '；' : '') . implode('；', array_slice($errors, 0, 3));
                $msgType = 'error';
            }
            if ($okCount === 0 && !$errors) {
                $msg = '请选择要上传的文件';
                $msgType = 'error';
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $stmt = db()->prepare("SELECT * FROM user_files WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            $msg = '文件不存在或无权删除';
            $msgType = 'error';
        } else {
            db()->prepare("DELETE FROM user_files WHERE id = ? AND user_id = ?")->execute([$id, $user['id']]);
            delete_uploaded_file($row['file']);
            $dir = __DIR__ . '/../assets/uploads/files/' . files_folder_name($user['username']);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
            $msg = '已删除该文件';
        }
    }
}

$fileList = user_file_list($user['id']);
$totalSize = 0;
foreach ($fileList as $f) $totalSize += intval($f['filesize']);

$pageTitle = '我的文件';
$currentPage = 'profile';
include __DIR__ . '/_header.php';
?>

<style>
.file-row { display: flex; align-items: center; gap: 14px; padding: 14px 2px; border-bottom: 1px solid #f1f1f5; }
.file-row:last-child { border-bottom: none; }
.file-row .file-name { font-size: 14px; font-weight: 600; }
.file-row .file-meta { font-size: 12px; color: var(--text-light); margin-top: 4px; }
.file-row .file-icon {
    width: 42px; height: 42px; border-radius: 10px; flex-shrink: 0;
    background: var(--grad); color: #fff;
    display: flex; align-items: center; justify-content: center; font-size: 18px;
}
.file-actions { display: flex; gap: 8px; flex-shrink: 0; }
.file-upload-box {
    display: block; padding: 26px 16px; text-align: center; cursor: pointer;
    border: 2px dashed rgba(168,85,247,.35); border-radius: 12px;
    background: rgba(168,85,247,.04);
}
.file-upload-box:hover { border-color: var(--accent); background: rgba(168,85,247,.07); }
</style>

<?php if ($msg): ?>
    <div class="win-tip <?= $msgType === 'error' ? 'win-tip-error' : 'win-tip-success' ?>">
        <i class="fa fa-<?= $msgType === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<div class="win-card">
    <div class="win-card-title"><i class="fa fa-cloud-upload"></i> 上传文件</div>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="upload">
        <label for="files-input" class="file-upload-box">
            <i class="fa fa-cloud-upload" style="font-size:30px;color:var(--accent);"></i>
            <div style="font-size:14px;font-weight:600;margin-top:8px;">点击选择文件（可多选）</div>
            <div style="font-size:12px;color:var(--text-light);margin-top:4px;">支持任意格式，单个文件最大 100MB</div>
        </label>
        <input type="file" id="files-input" name="files[]" multiple style="display:none;">
        <div id="files-selected" style="font-size:12px;color:var(--text-light);margin-top:10px;"></div>
        <button type="submit" class="btn btn-primary" style="padding:11px 26px;margin-top:12px;">
            <i class="fa fa-upload"></i> 开始上传
        </button>
        <div class="form-hint" style="margin-top:10px;">
            文件存放在以你的用户名命名的文件夹中；服务器当前限制：<?= e(ini_get('upload_max_filesize')) ?> / 表单 <?= e(ini_get('post_max_size')) ?>
        </div>
    </form>
</div>

<div class="win-card" style="margin-top:16px;">
    <div class="win-card-title" style="justify-content:space-between;">
        <span><i class="fa fa-folder-open"></i> 我的文件</span>
        <span style="font-size:12px;font-weight:400;color:var(--text-light);"><?= count($fileList) ?> 个 · <?= human_size($totalSize) ?></span>
    </div>

    <?php if (empty($fileList)): ?>
        <div class="empty" style="padding:36px 20px;">
            <i class="fa fa-folder-open-o"></i>
            <p>还没有上传任何文件</p>
            <p style="font-size:12px;margin-top:6px;">上传后可设置提取密码，并把详情页链接分享给其他人</p>
        </div>
    <?php else: ?>
        <?php foreach ($fileList as $f): ?>
        <div class="file-row">
            <div class="file-icon"><i class="fa <?= e(file_icon($f['ext'])) ?>"></i></div>
            <div style="flex:1;min-width:0;">
                <div class="file-name" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                    <?= e($f['name']) ?>
                    <?php if (!empty($f['password'])): ?>
                        <span style="font-size:11px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:2px 8px;margin-left:6px;font-weight:400;"><i class="fa fa-lock"></i> 密码</span>
                    <?php endif; ?>
                </div>
                <div class="file-meta"><?= human_size($f['filesize']) ?> · <?= time_ago($f['created_at']) ?> · <i class="fa fa-download"></i> <?= intval($f['downloads']) ?></div>
            </div>
            <div class="file-actions">
                <a href="index.php?page=file&id=<?= $f['id'] ?>" class="btn btn-ghost btn-sm"><i class="fa fa-info-circle"></i> 详情</a>
                <form method="post" onsubmit="return confirm('确定删除该文件吗？文件也会从服务器删除。');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $f['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
document.getElementById('files-input').addEventListener('change', function() {
    const box = document.getElementById('files-selected');
    if (!this.files || !this.files.length) { box.textContent = ''; return; }
    let total = 0, names = [];
    for (const f of this.files) { total += f.size; names.push(f.name); }
    box.innerHTML = '<i class="fa fa-check-circle" style="color:#10b981;"></i> 已选择 ' + this.files.length + ' 个文件（共 ' + (total / 1048576).toFixed(1) + ' MB）：' + names.join('、');
});
</script>

<?php include __DIR__ . '/_footer.php'; ?>
