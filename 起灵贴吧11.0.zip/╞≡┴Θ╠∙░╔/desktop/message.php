<?php
/**
 * Windows 版 - 消息中心
 * 功能与 pages/message.php 完全一致：全部/评论/赞/关注/系统/联系站长六类 Tab（type 过滤）、
 * 进入分类即标记已读、未读标记、全部已读、联系站长类型跳 contact_chat
 */
$pageTitle = '消息';
$currentPage = 'message';

if (!$user) { header('Location: index.php?page=login'); exit; }

// 处理全部已读
if (isset($_GET['read_all'])) {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']} AND is_read = 0");
    header('Location: index.php?page=message');
    exit;
}

// 标记当前分类消息已读
$type = $_GET['type'] ?? 'all';
if ($type === 'all') {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']}");
} else {
    db()->exec("UPDATE messages SET is_read = 1 WHERE to_user_id = {$user['id']} AND type = '" . addslashes($type) . "'");
}

// 各分类未读数
$unreadStats = db()->query("
    SELECT type, COUNT(*) as cnt FROM messages
    WHERE to_user_id = {$user['id']} AND is_read = 0
    GROUP BY type
")->fetchAll();
$unreadMap = [];
foreach ($unreadStats as $s) $unreadMap[$s['type']] = (int)$s['cnt'];
$totalUnread = array_sum($unreadMap);

// 消息列表
$where = "to_user_id = {$user['id']}";
if ($type !== 'all') $where .= " AND type = '" . addslashes($type) . "'";

$msgs = db()->query("
    SELECT m.*, u.nickname, u.avatar, u.id as from_id
    FROM messages m
    LEFT JOIN users u ON m.from_user_id = u.id
    WHERE {$where}
    ORDER BY m.created_at DESC
    LIMIT 50
")->fetchAll();

$tabs = [
    'all' => ['全部', 'inbox'],
    'comment' => ['评论', 'comment'],
    'like' => ['赞', 'heart'],
    'follow' => ['关注', 'user-plus'],
    'system' => ['通知', 'bell'],
    'contact' => ['联系站长', 'envelope'],
];

include __DIR__ . '/_header.php';
?>

<style>
.msg-tab .tab-badge {
    display: inline-block; background: var(--danger); color: #fff;
    font-size: 10px; font-weight: 700; padding: 0 6px; border-radius: 8px;
    margin-left: 4px; min-width: 16px; line-height: 15px; vertical-align: 1px;
}
.msg-type-icon {
    position: absolute; bottom: -2px; right: -2px; width: 20px; height: 20px;
    border-radius: 50%; color: #fff; display: flex; align-items: center;
    justify-content: center; font-size: 10px; border: 2px solid #fff;
}
.msg-avatar-wrap { position: relative; flex-shrink: 0; }
.unread-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--accent); display: inline-block; flex-shrink: 0; }
</style>

<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;">
    <div class="win-card-title" style="margin-bottom:0;"><i class="fa fa-bell-o"></i> 消息通知</div>
    <?php if ($totalUnread > 0): ?>
        <a href="index.php?page=message&read_all=1" class="btn btn-ghost btn-sm" onclick="return confirm('标记全部已读？')">
            <i class="fa fa-check-circle-o"></i> 全部已读
        </a>
    <?php else: ?>
        <span class="btn btn-ghost btn-sm" style="opacity:.5;cursor:default;"><i class="fa fa-check-circle-o"></i> 全部已读</span>
    <?php endif; ?>
</div>

<!-- 六类 Tab -->
<div class="msg-tabs">
    <?php foreach ($tabs as $k => $v): ?>
        <?php $cnt = $k==='all' ? $totalUnread : ($unreadMap[$k] ?? 0); ?>
        <a href="index.php?page=message&type=<?= $k ?>" class="msg-tab <?= $type===$k?'active':'' ?>">
            <i class="fa fa-<?= $v[1] ?>"></i> <?= $v[0] ?>
            <?php if ($cnt > 0): ?><span class="tab-badge"><?= $cnt > 99 ? '99+' : $cnt ?></span><?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if (empty($msgs)): ?>
    <div class="win-card empty">
        <i class="fa fa-envelope-o"></i>
        <p>暂无<?= $type==='all'?'':$tabs[$type][0] ?>消息</p>
        <p style="font-size:12px;margin-top:6px;">有新消息会在这里通知你哦 ~</p>
        <?php if ($type === 'contact'): ?>
            <a href="index.php?page=contact_chat" class="btn btn-primary" style="margin-top:16px;">
                <i class="fa fa-comments"></i> 给站长留言
            </a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <?php foreach ($msgs as $m):
    // 联系站长消息跳转会话页，其他消息跳转对应用户/帖子
    if ($m['type'] === 'contact') {
        if (($user['role'] ?? '') === 'admin') {
            $msgLink = 'index.php?page=contact_chat&uid=' . $m['from_id'];
        } else {
            $msgLink = 'index.php?page=contact_chat';
        }
    } else {
        $msgLink = $m['post_id'] ? 'index.php?page=post&id='.$m['post_id'] : ($m['from_id'] ? 'index.php?page=user&id='.$m['from_id'] : '#');
    }
    $iconMap = ['like'=>'heart','comment'=>'comment','follow'=>'user-plus','system'=>'bell','contact'=>'envelope','chat'=>'envelope'];
    $colorMap = ['like'=>'#f472b6','comment'=>'#a78bfa','follow'=>'#60a5fa','system'=>'#fbbf24','contact'=>'#8b5cf6','chat'=>'#34d399'];
    ?>
    <a href="<?= $msgLink ?>" class="msg-item <?= !$m['is_read'] ? 'unread' : '' ?>">
        <div class="msg-avatar-wrap">
            <img src="<?= e(avatar(['id'=>$m['from_id'],'avatar'=>$m['avatar'],'nickname'=>$m['nickname']])) ?>" class="msg-avatar" alt="">
            <span class="msg-type-icon" style="background:<?= $colorMap[$m['type']] ?? '#fbbf24' ?>;">
                <i class="fa fa-<?= $iconMap[$m['type']] ?? 'bell' ?>"></i>
            </span>
        </div>
        <div class="msg-body">
            <div class="msg-title" style="display:flex;align-items:center;gap:6px;">
                <?= e($m['nickname'] ?: '系统消息') ?>
                <?php if (!$m['is_read']): ?><span class="unread-dot"></span><?php endif; ?>
            </div>
            <div class="msg-content"><?= e($m['content']) ?></div>
            <div style="font-size:11px;color:var(--text-light);margin-top:3px;"><?= time_ago($m['created_at']) ?></div>
        </div>
        <i class="fa fa-angle-right" style="color:var(--text-light);align-self:center;"></i>
    </a>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
