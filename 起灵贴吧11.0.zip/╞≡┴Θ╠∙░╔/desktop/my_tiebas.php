<?php
/**
 * Windows 版 - 我的贴吧（吧主中心）
 * 功能与 pages/my_tiebas.php 完全一致：列出当前用户创建的贴吧，提供管理入口
 * 仅可管理贴吧内的内容（帖子），不能删除/编辑贴吧本身信息
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

// 处理置顶/取消置顶/删除帖子的操作反馈（由 tieba_manage 跳回时带 msg）
$opMsg = $_GET['msg'] ?? '';

// 我创建的贴吧
$myTiebas = db()->prepare("
    SELECT * FROM tiebas WHERE owner_id = ? ORDER BY created_at DESC
");
$myTiebas->execute([$user['id']]);
$myTiebas = $myTiebas->fetchAll();

$pageTitle = '我的贴吧';
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<!-- 页头 -->
<div class="win-section-title" style="margin-top:0;">
    <span><i class="fa fa-flag"></i> 我的贴吧</span>
    <span style="font-size:12px;font-weight:400;color:var(--text-light);">共 <?= count($myTiebas) ?> 个</span>
</div>

<?php if ($opMsg): ?>
<div class="win-tip win-tip-success"><i class="fa fa-check-circle"></i> <?= e($opMsg) ?></div>
<?php endif; ?>

<!-- 说明条 -->
<div style="background:rgba(251,191,36,.12);color:#92400e;border:1px solid rgba(251,191,36,.3);border-radius:10px;padding:10px 14px;font-size:13px;display:flex;align-items:flex-start;gap:8px;margin-bottom:16px;">
    <i class="fa fa-info-circle" style="margin-top:2px;"></i>
    <span>你只能管理自己创建的贴吧内的帖子（删除、置顶），不能修改或删除贴吧本身信息。</span>
</div>

<?php if (empty($myTiebas)): ?>
    <div class="win-card empty">
        <i class="fa fa-star-o"></i>
        <p>你还没有创建任何贴吧</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">贴吧由管理员在后台创建，你成为某贴吧的吧主后可在此管理内容。</p>
    </div>
<?php else: ?>
    <?php foreach ($myTiebas as $t): ?>
    <div class="tieba-row" style="margin-bottom:12px;">
        <div class="tieba-cover-sm" style="background:<?= cover($t) ?>">
            <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
        </div>
        <div style="flex:1;min-width:0;">
            <div class="tieba-row-name"><?= e($t['name']) ?></div>
            <div class="tieba-row-desc"><?= e($t['description'] ?: '暂无简介') ?></div>
            <div class="tieba-row-meta"><i class="fa fa-users"></i> <?= $t['members'] ?> 成员 · <i class="fa fa-file-text-o"></i> <?= $t['posts'] ?> 帖子</div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;">
            <a href="index.php?page=tieba_manage&id=<?= $t['id'] ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-cog"></i> 管理内容
            </a>
            <a href="index.php?page=tieba&id=<?= $t['id'] ?>" class="btn btn-ghost btn-sm">
                <i class="fa fa-eye"></i> 查看
            </a>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
