<?php
/**
 * Windows 版 - 帖子详情
 * 功能与 pages/post.php 完全一致：浏览量自增、私密帖访问控制、标题/内容/图片/视频、
 * visibility_badge 标识、点赞收藏、评论区（含楼中楼回复）、评论输入（私密帖禁止评论）、删除按钮、返回贴吧
 */
$postId = intval($_GET['id'] ?? 0);
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.bio, u.id as uid, u.role, u.posts, t.name as tieba_name, t.id as tieba_id, t.icon as tieba_icon
    FROM posts p
    LEFT JOIN users u ON p.user_id = u.id
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.id = ?
");
$stmt->execute([$postId]);
$post = $stmt->fetch();

if (!$post) { header('Location: index.php'); exit; }

// 私密帖访问控制：仅作者本人和管理员可查看，其他人（含游客）直接跳回首页
if (($post['visibility'] ?? 'public') === 'private') {
    $canViewPrivate = $user && ($user['id'] == $post['user_id'] || in_array($user['role'], ['admin','super_admin']));
    if (!$canViewPrivate) {
        header('Location: index.php');
        exit;
    }
}

// 待审核帖访问控制：仅作者本人和管理员可查看，审核通过后对所有人开放
if (intval($post['status']) === 0) {
    $canViewPending = $user && ($user['id'] == $post['user_id'] || in_array($user['role'], ['admin','super_admin']));
    if (!$canViewPending) {
        header('Location: index.php');
        exit;
    }
}

$pageTitle = $post['title'] ?: '帖子详情';
$currentPage = '';
include __DIR__ . '/_header.php';

// 增加浏览量
db()->exec("UPDATE posts SET views = views + 1 WHERE id = {$postId}");

$imgs = $post['images'] ? json_decode($post['images'], true) : [];
$liked = is_liked($postId);
$favorited = is_favorited($postId);

// 是否已关注作者
$isFollowingAuthor = false;
if ($user && $user['id'] != $post['uid']) {
    $stmt = db()->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
    $stmt->execute([$user['id'], $post['uid']]);
    $isFollowingAuthor = (bool)$stmt->fetch();
}

// 评论列表
$comments = db()->query("
    SELECT c.*, u.nickname, u.avatar as u_avatar, u.id as uid, u.role, u.posts
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.post_id = {$postId} AND c.status = 1 AND c.parent_id = 0
    ORDER BY c.created_at ASC
")->fetchAll();

// 查询每条评论的回复
foreach ($comments as &$c) {
    $c['replies'] = db()->query("
        SELECT r.*, u.nickname, u.avatar as u_avatar, u.id as uid
        FROM comments r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = {$c['id']} AND r.status = 1
        ORDER BY r.created_at ASC
    ")->fetchAll();
}
unset($c);

$imgClass = count($imgs) === 1 ? 'single' : (count($imgs) === 2 ? 'double' : (count($imgs) >= 3 ? 'triple' : ''));
?>

<style>
.post-detail-title { font-size: 20px; font-weight: 800; line-height: 1.5; margin: 14px 0 12px; }
.detail-meta { display: flex; align-items: center; flex-wrap: wrap; gap: 14px; font-size: 12px; color: var(--text-light); margin-top: 16px; padding-top: 14px; border-top: 1px solid #f1f1f5; }
.detail-actions { display: flex; align-items: center; justify-content: space-around; padding: 14px 0 2px; margin-top: 4px; }
.comment-foot { display: flex; gap: 14px; margin-top: 6px; font-size: 12px; color: var(--text-light); }
.comment-foot .reply-link { cursor: pointer; }
.comment-foot .reply-link:hover { color: var(--accent); }
</style>

<!-- 返回贴吧 -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
    <a href="index.php?page=tieba&id=<?= $post['tieba_id'] ?>" class="btn btn-ghost btn-sm"><i class="fa fa-angle-left"></i> 返回贴吧</a>
    <?= visibility_badge($post) ?>
</div>

<!-- 帖子主体 -->
<div class="win-card" style="padding:24px;">
    <div class="post-header">
        <a href="index.php?page=user&id=<?= $post['uid'] ?>">
            <img src="<?= e(avatar(['id'=>$post['uid'],'avatar'=>$post['u_avatar'],'nickname'=>$post['nickname']])) ?>" class="post-avatar" alt="">
        </a>
        <div class="post-user">
            <div class="post-nick"><?= e($post['nickname']) ?> <?= user_label($post) ?></div>
            <div class="post-time"><?= time_ago($post['created_at']) ?> · 来自 <a href="index.php?page=tieba&id=<?= $post['tieba_id'] ?>" style="color:var(--accent);"><?= e($post['tieba_name']) ?></a></div>
        </div>
        <?php if ($user && $user['id'] != $post['uid']): ?>
            <button class="btn <?= $isFollowingAuthor ? 'btn-ghost' : 'btn-primary' ?>" style="margin-left:auto;padding:6px 14px;font-size:12px;" onclick="followUser(<?= $post['uid'] ?>, this)">
                <i class="fa fa-<?= $isFollowingAuthor ? 'check' : 'plus' ?>"></i> <?= $isFollowingAuthor ? '已关注' : '关注' ?>
            </button>
        <?php endif; ?>
    </div>

    <!-- 标题 -->
    <?php if ($post['title']): ?>
        <h1 class="post-detail-title"><?= e($post['title']) ?><?php if (intval($post['status']) === 0): ?> <span class="tag" style="background:#fef3c7;color:#b45309;">审核中</span><?php endif; ?></h1>
    <?php endif; ?>

    <!-- 内容 -->
    <div style="font-size:15px;line-height:1.8;color:#3d3d46;word-break:break-word;"><?= nl2br(e($post['content'])) ?></div>

    <!-- 图片 -->
    <?php if (!empty($imgs)): ?>
        <div class="post-images <?= $imgClass ?>" style="margin-top:14px;">
            <?php foreach (array_slice($imgs, 0, 9) as $img): ?>
                <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')" alt="">
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- 视频 -->
    <?php if ($post['video']): ?>
        <div class="post-video" style="margin-top:14px;">
            <video src="<?= e($post['video']) ?>" controls preload="metadata"></video>
        </div>
    <?php endif; ?>

    <!-- 统计 -->
    <div class="detail-meta">
        <span><i class="fa fa-eye"></i> <?= $post['views'] ?> 浏览</span>
        <span><i class="fa fa-clock-o"></i> <?= date('Y-m-d H:i', strtotime($post['created_at'])) ?></span>
    </div>

    <!-- 互动栏 -->
    <div class="detail-actions">
        <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $postId ?>, this)" style="font-size:15px;">
            <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i>
            <span class="count"><?= $post['likes'] ?></span> 赞
        </div>
        <a href="#comments" class="post-action" style="font-size:15px;"><i class="fa fa-comment-o"></i> <?= $post['comments'] ?> 评论</a>
        <div class="post-action <?= $favorited?'favorited':'' ?>" onclick="favoritePost(<?= $postId ?>, this)" style="font-size:15px;">
            <i class="fa <?= $favorited?'fa-bookmark':'fa-bookmark-o' ?>"></i>
            <span class="count"><?= $post['favorites'] ?? 0 ?></span> 收藏
        </div>
        <div class="post-action" onclick="toast('已分享~')" style="font-size:15px;"><i class="fa fa-share-alt"></i> 分享</div>
        <?php if ($user && ($user['id'] == $post['uid'] || in_array($user['role'], ['admin','super_admin']))): ?>
        <div class="post-action" onclick="deletePost(<?= $postId ?>, 'index.php')" style="font-size:15px;color:var(--danger);">
            <i class="fa fa-trash-o"></i> 删除
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- 评论区 -->
<div class="win-card" id="comments">
    <div class="win-card-title"><i class="fa fa-comments"></i> 评论 (<?= $post['comments'] ?>)</div>

    <?php if (empty($comments)): ?>
        <div class="empty" style="padding:32px 20px;">
            <i class="fa fa-comment-o"></i>
            <p>还没有评论，快来抢沙发吧 ~</p>
        </div>
    <?php else: ?>
        <?php foreach ($comments as $c): ?>
        <div class="comment-item">
            <a href="index.php?page=user&id=<?= $c['uid'] ?>">
                <img src="<?= e(avatar(['id'=>$c['uid'],'avatar'=>$c['u_avatar'],'nickname'=>$c['nickname']])) ?>" class="comment-avatar" alt="">
            </a>
            <div class="comment-body">
                <div class="comment-nick"><?= e($c['nickname']) ?> <?= user_label($c) ?> <span class="comment-time"><?= time_ago($c['created_at']) ?></span></div>
                <div class="comment-text"><?= nl2br(e($c['content'])) ?></div>
                <div class="comment-foot">
                    <span><i class="fa fa-thumbs-o-up"></i> <?= $c['likes'] ?></span>
                    <span class="reply-link" onclick="setReply(<?= $c['id'] ?>, '<?= e($c['nickname']) ?>')"><i class="fa fa-reply"></i> 回复</span>
                </div>
                <!-- 楼中楼回复 -->
                <?php if (!empty($c['replies'])): ?>
                    <div class="comment-replies">
                        <?php foreach ($c['replies'] as $r): ?>
                        <div class="comment-item">
                            <img src="<?= e(avatar(['id'=>$r['uid'],'avatar'=>$r['u_avatar'],'nickname'=>$r['nickname']])) ?>" class="comment-avatar" alt="">
                            <div class="comment-body">
                                <div class="comment-nick"><?= e($r['nickname']) ?> <span class="comment-time"><?= time_ago($r['created_at']) ?></span></div>
                                <div class="comment-text"><?= nl2br(e($r['content'])) ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- 评论输入框 -->
    <?php if (($post['visibility'] ?? 'public') === 'private'): ?>
    <div style="text-align:center;margin-top:14px;padding:14px 0 2px;border-top:1px solid #f1f1f5;font-size:13px;color:var(--text-light);">
        <i class="fa fa-lock"></i> 该动态仅自己可见，不支持评论
    </div>
    <?php elseif ($user): ?>
    <div class="comment-input-row" style="margin-top:14px;padding-top:14px;border-top:1px solid #f1f1f5;">
        <div id="reply-bar" style="display:none;align-items:center;gap:6px;flex-shrink:0;font-size:12px;color:var(--accent);background:#f5efff;border:1px solid var(--border);border-radius:16px;padding:8px 12px;">
            <i class="fa fa-reply"></i> 回复 <b id="reply-name"></b>
            <span onclick="cancelReply()" style="cursor:pointer;color:var(--text-light);margin-left:2px;"><i class="fa fa-times"></i> 取消</span>
        </div>
        <input id="comment-input" class="form-input" placeholder="说点什么吧..." onkeydown="if(event.key==='Enter')submitComment(<?= $postId ?>)">
        <button class="btn btn-primary" onclick="submitComment(<?= $postId ?>)"><i class="fa fa-paper-plane"></i></button>
    </div>
    <?php else: ?>
    <div style="text-align:center;margin-top:14px;padding-top:14px;border-top:1px solid #f1f1f5;">
        <a href="index.php?page=login" class="btn btn-primary"><i class="fa fa-sign-in"></i> 登录后评论</a>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
