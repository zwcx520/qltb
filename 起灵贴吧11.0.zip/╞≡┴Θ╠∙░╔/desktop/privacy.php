<?php
/**
 * Windows 版 - 隐私设置页
 * 功能与 pages/privacy.php 完全一致：动态/关注/粉丝/贴吧的公开与仅自己设置
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $privacyPosts     = $_POST['privacy_posts'] === 'private' ? 'private' : 'public';
    $privacyFollowing = $_POST['privacy_following'] === 'private' ? 'private' : 'public';
    $privacyFollowers = $_POST['privacy_followers'] === 'private' ? 'private' : 'public';
    $privacyTiebas    = $_POST['privacy_tiebas'] === 'private' ? 'private' : 'public';

    $stmt = db()->prepare("UPDATE users SET privacy_posts=?, privacy_following=?, privacy_followers=?, privacy_tiebas=? WHERE id=?");
    $stmt->execute([$privacyPosts, $privacyFollowing, $privacyFollowers, $privacyTiebas, $user['id']]);

    $msg = '隐私设置已保存';
    $user = current_user(); // 刷新
}

// 读取当前设置
$pPosts     = $user['privacy_posts'] ?? 'public';
$pFollowing = $user['privacy_following'] ?? 'public';
$pFollowers = $user['privacy_followers'] ?? 'public';
$pTiebas    = $user['privacy_tiebas'] ?? 'public';

$pageTitle = '隐私设置';
$currentPage = 'profile';
include __DIR__ . '/_header.php';
?>

<style>
.seg-row { display: flex; gap: 8px; max-width: 320px; }
.seg-opt {
    flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px;
    padding: 9px 0; border: 1px solid var(--border); border-radius: 8px;
    font-size: 13px; color: var(--text-soft); cursor: pointer; background: #fbfbfd;
    transition: all .15s; user-select: none;
}
.seg-opt:hover { border-color: #d8c8ee; }
.seg-opt input { display: none; }
.seg-opt:has(input:checked) {
    border-color: var(--accent); color: var(--accent);
    background: rgba(168,85,247,.08); font-weight: 600;
}
</style>

<?php if ($msg): ?>
<div class="win-tip <?= $msgType === 'success' ? 'win-tip-success' : 'win-tip-error' ?>">
    <i class="fa fa-<?= $msgType === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i> <?= e($msg) ?>
</div>
<?php endif; ?>

<form method="post">
    <div class="win-card" style="padding:0;">
        <?php
        $privacyItems = [
            ['privacy_posts',     'file-text-o', '我的动态', '控制其他用户是否可以查看你发布的帖子', $pPosts],
            ['privacy_following', 'user-plus',   '我的关注', '控制其他用户是否可以查看你关注的人',   $pFollowing],
            ['privacy_followers', 'users',       '我的粉丝', '控制其他用户是否可以查看你的粉丝列表', $pFollowers],
            ['privacy_tiebas',    'th',          '我的贴吧', '控制其他用户是否可以查看你加入的贴吧', $pTiebas],
        ];
        foreach ($privacyItems as $i => $item):
            list($field, $icon, $title, $desc, $val) = $item;
            $isLast = ($i === count($privacyItems) - 1);
        ?>
        <div style="padding:18px 20px;<?= $isLast ? '' : 'border-bottom:1px solid var(--border);' ?>">
            <div style="font-size:14px;font-weight:600;color:var(--text);display:flex;align-items:center;gap:8px;">
                <i class="fa fa-<?= $icon ?>" style="color:var(--accent);"></i> <?= $title ?>
            </div>
            <div style="font-size:12px;color:var(--text-soft);margin:6px 0 12px;"><?= $desc ?></div>
            <div class="seg-row">
                <label class="seg-opt" for="<?= $field ?>_public">
                    <input type="radio" name="<?= $field ?>" value="public" <?= $val === 'public' ? 'checked' : '' ?> id="<?= $field ?>_public">
                    <i class="fa fa-globe"></i> 公开
                </label>
                <label class="seg-opt" for="<?= $field ?>_private">
                    <input type="radio" name="<?= $field ?>" value="private" <?= $val === 'private' ? 'checked' : '' ?> id="<?= $field ?>_private">
                    <i class="fa fa-lock"></i> 仅自己
                </label>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="win-card" style="font-size:12px;color:var(--text-soft);line-height:1.8;padding:14px 16px;">
        <i class="fa fa-info-circle" style="color:var(--accent);"></i> 设为"仅自己"后，其他用户访问你的主页时将无法看到对应内容，但你本人仍可正常查看。
    </div>

    <button type="submit" class="btn btn-primary btn-block" style="padding:13px;">
        <i class="fa fa-save"></i> 保存隐私设置
    </button>
</form>

<?php include __DIR__ . '/_footer.php'; ?>
