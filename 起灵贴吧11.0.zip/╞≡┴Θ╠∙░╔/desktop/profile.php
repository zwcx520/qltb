<?php
/**
 * Windows 版 - 个人中心
 * 功能与 pages/profile.php 完全一致：头像昵称、stat-grid 统计（帖子/关注/粉丝/贴吧）、
 * 我的动态（私密帖仅本人可见，带删除）、我的贴吧、未读消息、关注/粉丝列表、功能菜单
 */
$pageTitle = '个人中心';
$currentPage = 'profile';

if (!$user) { header('Location: index.php?page=login'); exit; }

// 用户统计
$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM posts WHERE user_id = {$user['id']}) as posts,
    (SELECT COUNT(*) FROM tieba_follows WHERE user_id = {$user['id']}) as tiebas,
    (SELECT COUNT(*) FROM user_follows WHERE follower_id = {$user['id']}) as following,
    (SELECT COUNT(*) FROM user_follows WHERE following_id = {$user['id']}) as followers
")->fetch();

// 我关注的贴吧
$myTiebas = db()->query("
    SELECT t.* FROM tieba_follows f
    JOIN tiebas t ON f.tieba_id = t.id
    WHERE f.user_id = {$user['id']}
    ORDER BY f.created_at DESC LIMIT 6
")->fetchAll();

// 我的帖子（全部，按年月日分组折叠展示）
$myPosts = db()->query("
    SELECT p.*, t.name as tieba_name FROM posts p
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.user_id = {$user['id']}
    ORDER BY p.created_at DESC
")->fetchAll();

// 按天分组（新的日期在前）
$postGroups = [];
foreach ($myPosts as $p) {
    $day = date('Y-m-d', strtotime($p['created_at']));
    $postGroups[$day][] = $p;
}

// 我的关注列表
$myFollowing = db()->query("
    SELECT u.id, u.nickname, u.avatar, u.username, u.bio
    FROM user_follows f
    JOIN users u ON f.following_id = u.id
    WHERE f.follower_id = {$user['id']}
    ORDER BY f.created_at DESC
")->fetchAll();

// 我的粉丝列表
$myFollowers = db()->query("
    SELECT u.id, u.nickname, u.avatar, u.username, u.bio,
    (SELECT 1 FROM user_follows WHERE follower_id = {$user['id']} AND following_id = u.id) as is_followed
    FROM user_follows f
    JOIN users u ON f.follower_id = u.id
    WHERE f.following_id = {$user['id']}
    ORDER BY f.created_at DESC
")->fetchAll();

// 未读消息数
$unreadCount = (int)db()->query("SELECT COUNT(*) FROM messages WHERE to_user_id = {$user['id']} AND is_read = 0")->fetchColumn();

include __DIR__ . '/_header.php';
?>

<style>
.clamp2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.profile-hero {
    background: linear-gradient(135deg, #fce7f3 0%, #f3e8ff 100%);
    border: 1px solid var(--border); border-radius: var(--radius);
    box-shadow: var(--shadow); padding: 26px 24px; margin-bottom: 16px;
}
.profile-hero .stat-item { background: rgba(255,255,255,.72); }
.follow-row { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid #f1f1f5; }
.follow-row:last-child { border-bottom: none; }
.tieba-chip { text-align: center; }
.tieba-chip .crown { position: relative; }
</style>

<!-- 顶部个人信息 -->
<div class="profile-hero">
    <div class="profile-head">
        <img src="<?= e(avatar($user)) ?>" class="avatar-lg" style="border:3px solid #fff;box-shadow:0 6px 18px rgba(0,0,0,.12);" alt="">
        <div class="profile-info">
            <div class="profile-name"><?= e($user['nickname'] ?: $user['username']) ?> <?= user_label($user) ?></div>
            <div class="profile-bio"><?= e($user['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
            <div style="font-size:12px;color:var(--text-light);margin-top:3px;">@<?= e($user['username']) ?></div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0;">
            <a href="index.php?page=files" class="btn btn-ghost btn-sm"><i class="fa fa-folder-open"></i> 我的文件</a>
            <a href="index.php?page=edit" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i> 编辑资料</a>
        </div>
    </div>

    <!-- 统计 -->
    <div class="stat-grid" style="margin-top:20px;">
        <a href="index.php?page=profile#posts" class="stat-item">
            <div class="stat-num"><?= $stats['posts'] ?></div>
            <div class="stat-label">动态</div>
        </a>
        <a href="index.php?page=profile&tab=following" class="stat-item">
            <div class="stat-num"><?= $stats['following'] ?></div>
            <div class="stat-label">关注</div>
        </a>
        <a href="index.php?page=profile&tab=followers" class="stat-item">
            <div class="stat-num"><?= $stats['followers'] ?></div>
            <div class="stat-label">粉丝</div>
        </a>
        <a href="index.php?page=profile#tiebas" class="stat-item">
            <div class="stat-num"><?= $stats['tiebas'] ?></div>
            <div class="stat-label">贴吧</div>
        </a>
    </div>
</div>

<?php
$tab = $_GET['tab'] ?? '';
if ($tab === 'following' || $tab === 'followers'):
    $list = $tab === 'following' ? $myFollowing : $myFollowers;
    $listTitle = $tab === 'following' ? '我的关注' : '我的粉丝';
    $listIcon = $tab === 'following' ? 'user-plus' : 'users';
?>
<div class="win-section-title">
    <span><i class="fa fa-<?= $listIcon ?>"></i> <?= $listTitle ?> (<?= count($list) ?>)</span>
    <a href="index.php?page=profile" class="more">返回 <i class="fa fa-angle-right"></i></a>
</div>
<div class="win-card">
<?php if (empty($list)): ?>
    <div class="empty"><i class="fa fa-user-o"></i><p>还没有<?= $tab==='following'?'关注的人':'粉丝' ?></p></div>
<?php else: ?>
    <?php foreach ($list as $u): ?>
    <div class="follow-row">
        <a href="index.php?page=user&id=<?= $u['id'] ?>">
            <img src="<?= e(avatar($u)) ?>" class="avatar" alt="">
        </a>
        <a href="index.php?page=user&id=<?= $u['id'] ?>" style="flex:1;min-width:0;">
            <div style="font-size:14px;font-weight:600;"><?= e($u['nickname'] ?: $u['username']) ?></div>
            <div class="clamp2" style="font-size:12px;color:var(--text-soft);"><?= e($u['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
        </a>
        <?php if ($tab === 'following'): ?>
            <button class="btn btn-ghost btn-sm" onclick="followUser(<?= $u['id'] ?>, this);this.closest('div').style.opacity='0.3'">
                <i class="fa fa-check"></i> 已关注
            </button>
        <?php else: ?>
            <?php $followed = !empty($u['is_followed']); ?>
            <button class="btn <?= $followed ? 'btn-ghost' : 'btn-primary' ?> btn-sm" onclick="followUser(<?= $u['id'] ?>, this)">
                <i class="fa fa-<?= $followed ? 'check' : 'plus' ?>"></i> <?= $followed ? '已关注' : '关注' ?>
            </button>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>
<?php else: ?>

<!-- 我的贴吧 -->
<div class="win-section-title" id="tiebas">
    <span><i class="fa fa-star"></i> 我的贴吧</span>
    <a href="index.php?page=discover" class="more">发现更多 <i class="fa fa-angle-right"></i></a>
</div>
<?php if (empty($myTiebas)): ?>
    <div class="win-card empty"><i class="fa fa-tree"></i><p>还没有关注的贴吧，去发现看看吧 ~</p></div>
<?php else: ?>
    <div class="grid-3" style="grid-template-columns:repeat(3,1fr);">
        <?php foreach ($myTiebas as $t): ?>
            <a href="index.php?page=tieba&id=<?= $t['id'] ?>" class="tieba-row tieba-chip">
                <div class="tieba-cover-sm crown" style="background:<?= cover($t) ?>">
                    <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
                    <?php if ($t['owner_id'] == $user['id']): ?>
                    <span style="position:absolute;top:-8px;right:-8px;font-size:14px;" title="我是吧主"><i class="fa fa-crown" style="color:#f59e0b;"></i></span>
                    <?php endif; ?>
                </div>
                <div style="min-width:0;">
                    <div class="tieba-row-name"><?= e($t['name']) ?></div>
                    <div class="tieba-row-meta"><?= $t['members'] ?> 人 · <?= $t['posts'] ?> 帖</div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- 我的动态（按年月日分组折叠） -->
<div class="win-section-title" id="posts">
    <span><i class="fa fa-file-text-o"></i> 我的动态（<?= count($myPosts) ?>）</span>
    <?php if (!empty($myPosts)): ?>
        <a href="javascript:togglePostSearch()" class="more"><i class="fa fa-search"></i> 搜索</a>
    <?php endif; ?>
</div>
<?php if (!empty($myPosts)): ?>
<!-- 动态搜索框 -->
<div id="post-search-bar" style="display:none;margin-bottom:12px;">
    <div style="position:relative;">
        <i class="fa fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-light);font-size:13px;"></i>
        <input type="text" id="post-search-input" class="form-input" style="padding-left:34px;" placeholder="搜索我的动态标题 / 内容" oninput="filterMyPosts(this.value)">
    </div>
    <div id="post-search-tip" style="display:none;font-size:12px;color:var(--text-light);margin-top:6px;padding-left:2px;"></div>
</div>
<?php endif; ?>

<?php if (empty($myPosts)): ?>
    <div class="win-card empty">
        <i class="fa fa-pencil-square-o"></i>
        <p>还没有发布过动态</p>
        <p style="font-size:12px;margin-top:6px;">点击左侧「发布帖子」按钮发布第一条动态吧 ~</p>
    </div>
<?php else: ?>
    <?php
    $gi = 0;
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    foreach ($postGroups as $day => $posts):
        $gi++;
        if ($day === $today) {
            $dayLabel = '今天 · ' . date('Y年m月d日', strtotime($day));
        } elseif ($day === $yesterday) {
            $dayLabel = '昨天 · ' . date('Y年m月d日', strtotime($day));
        } else {
            $dayLabel = date('Y年m月d日', strtotime($day));
        }
    ?>
    <div class="win-card pg-group" style="padding:0;overflow:hidden;margin-bottom:12px;">
        <!-- 日期分组头（点击折叠/展开） -->
        <div onclick="togglePostGroup(<?= $gi ?>)" style="display:flex;align-items:center;gap:10px;padding:13px 16px;cursor:pointer;user-select:none;">
            <span style="width:30px;height:30px;border-radius:8px;background:rgba(168,85,247,.1);color:#a855f7;display:flex;align-items:center;justify-content:center;font-size:13px;"><i class="fa fa-calendar"></i></span>
            <span style="font-size:14px;font-weight:600;"><?= e($dayLabel) ?></span>
            <span style="font-size:12px;color:var(--text-light);"><?= count($posts) ?> 条</span>
            <i id="pg-icon-<?= $gi ?>" class="fa fa-angle-down" style="margin-left:auto;color:var(--text-light);transition:transform .3s;<?= $gi === 1 ? 'transform:rotate(180deg);' : '' ?>"></i>
        </div>
        <!-- 分组内容（默认只展开最新一天） -->
        <div id="pg-body-<?= $gi ?>" style="display:<?= $gi === 1 ? 'block' : 'none' ?>;border-top:1px solid #f1f1f5;">
            <?php foreach ($posts as $p):
                $imgs = $p['images'] ? json_decode($p['images'], true) : [];
            ?>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="pg-item" data-search="<?= e(mb_strtolower($p['title'] . ' ' . $p['content'])) ?>" style="display:block;padding:14px 16px;border-bottom:1px solid #f6f6fa;color:inherit;">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
                    <span class="post-tieba-tag"><i class="fa fa-tree"></i> <?= e($p['tieba_name']) ?></span>
                    <?= visibility_badge($p) ?>
                    <span style="font-size:12px;color:var(--text-light);"><?= time_ago($p['created_at']) ?></span>
                    <span onclick="event.preventDefault();event.stopPropagation();deletePost(<?= $p['id'] ?>, 'index.php?page=profile')" style="margin-left:auto;color:var(--danger);font-size:12px;cursor:pointer;" title="删除帖子"><i class="fa fa-trash-o"></i></span>
                </div>
                <?php if ($p['title']): ?><div style="font-weight:700;font-size:15px;margin-bottom:4px;"><?= e($p['title']) ?></div><?php endif; ?>
                <div class="clamp2" style="font-size:13px;color:var(--text-soft);line-height:1.7;"><?= nl2br(e($p['content'])) ?></div>
                <?php if (!empty($imgs)): ?>
                    <div style="display:flex;gap:6px;margin-top:8px;">
                        <?php foreach (array_slice($imgs,0,3) as $img): ?>
                            <img src="<?= e($img) ?>" style="width:64px;height:64px;border-radius:8px;object-fit:cover;" alt="">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div style="display:flex;gap:16px;margin-top:10px;font-size:12px;color:var(--text-light);">
                    <span><i class="fa fa-eye"></i> <?= $p['views'] ?></span>
                    <span><i class="fa fa-heart-o"></i> <?= $p['likes'] ?></span>
                    <span><i class="fa fa-comment-o"></i> <?= $p['comments'] ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<script>
// 我的动态搜索：展开/收起搜索框
function togglePostSearch() {
    var bar = document.getElementById('post-search-bar');
    if (!bar) return;
    if (bar.style.display === 'none') {
        bar.style.display = 'block';
        var i = document.getElementById('post-search-input');
        if (i) i.focus();
    } else {
        bar.style.display = 'none';
        var input = document.getElementById('post-search-input');
        if (input) { input.value = ''; filterMyPosts(''); }
    }
}
// 动态搜索过滤（标题/内容，实时匹配；搜索时自动展开有结果的分组）
function filterMyPosts(q) {
    q = (q || '').trim().toLowerCase();
    var tip = document.getElementById('post-search-tip');
    var total = 0;
    var groups = document.querySelectorAll('.pg-group');
    groups.forEach(function(g, idx) {
        var body = g.querySelector('[id^="pg-body-"]');
        var icon = g.querySelector('[id^="pg-icon-"]');
        var visible = 0;
        g.querySelectorAll('.pg-item').forEach(function(it) {
            var text = (it.getAttribute('data-search') || '');
            var hit = (!q || text.indexOf(q) !== -1);
            it.style.display = hit ? 'block' : 'none';
            if (hit) visible++;
        });
        total += visible;
        if (!q) {
            // 清空搜索：恢复默认（所有分组显示，仅第一组展开）
            g.style.display = 'block';
            if (body) body.style.display = (idx === 0) ? 'block' : 'none';
            if (icon) icon.style.transform = (idx === 0) ? 'rotate(180deg)' : 'rotate(0deg)';
        } else if (visible > 0) {
            g.style.display = 'block';
            if (body) body.style.display = 'block';
            if (icon) icon.style.transform = 'rotate(180deg)';
        } else {
            g.style.display = 'none';
        }
    });
    if (tip) {
        tip.style.display = q ? 'block' : 'none';
        tip.textContent = q ? ('找到 ' + total + ' 条相关动态') : '';
    }
}
// 按日分组折叠/展开
function togglePostGroup(id) {
    var body = document.getElementById('pg-body-' + id);
    var icon = document.getElementById('pg-icon-' + id);
    if (!body) return;
    if (body.style.display === 'none') {
        body.style.display = 'block';
        if (icon) icon.style.transform = 'rotate(180deg)';
    } else {
        body.style.display = 'none';
        if (icon) icon.style.transform = 'rotate(0deg)';
    }
}
</script>

<?php endif; // end tab else ?>

<?php include __DIR__ . '/_footer.php'; ?>
