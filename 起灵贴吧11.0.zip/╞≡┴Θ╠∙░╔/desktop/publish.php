<?php
/**
 * Windows 版 - 发布页
 * 功能与 pages/publish.php 完全一致：选/锁贴吧、标题、内容、可见范围、多图上传、视频上传、表情插入
 */
$selectedTieba = intval($_GET['tieba'] ?? 0);
$targetTieba = null; // 指定贴吧模式（从贴吧详情页进入）
$myTiebas = [];      // 通用模式：只列自己创建的贴吧

if ($selectedTieba) {
    $stmt = db()->prepare("SELECT id, name, icon FROM tiebas WHERE id = ?");
    $stmt->execute([$selectedTieba]);
    $targetTieba = $stmt->fetch();
    if (!$targetTieba) $selectedTieba = 0; // 贴吧不存在则退回通用模式
}
if (!$selectedTieba) {
    $stmt = db()->prepare("SELECT id, name, icon FROM tiebas WHERE owner_id = ? ORDER BY id DESC");
    $stmt->execute([$user['id']]);
    $myTiebas = $stmt->fetchAll();
}

// 是否有可发布的贴吧
$canPublish = $selectedTieba > 0 || !empty($myTiebas);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tiebaId = intval($_POST['tieba_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $type = $_POST['type'] ?? 'text';
    // 可见范围：public 公开（默认） / private 仅自己可见
    $visibility = (($_POST['visibility'] ?? 'public') === 'private') ? 'private' : 'public';
    $uploadError = '';

    // 1) 贴吧归属校验（防止伪造POST发布到任意贴吧）
    if ($tiebaId <= 0) {
        $uploadError = $selectedTieba ? '贴吧信息缺失，请从贴吧页面重新进入' : '请选择贴吧';
    } else {
        $stmt = db()->prepare("SELECT id, owner_id FROM tiebas WHERE id = ?");
        $stmt->execute([$tiebaId]);
        $tiebaRow = $stmt->fetch();
        if (!$tiebaRow) {
            $uploadError = '贴吧不存在或已被删除';
        } elseif ($selectedTieba && $tiebaId != $selectedTieba) {
            $uploadError = '请发布到对应的贴吧';
        } elseif (!$selectedTieba && (int)$tiebaRow['owner_id'] !== (int)$user['id']) {
            $uploadError = '从这里只能发布到自己创建的贴吧；请到对应贴吧内点击「发布帖子」按钮发布';
        }
    }

    // 2) 内容校验
    if (!$uploadError && !$content && empty($_FILES['images']['name'][0]) && empty($_FILES['video']['name'])) {
        $uploadError = '说点什么吧~';
    }

    // 3) 处理上传与入库
    if (!$uploadError) {
        // 处理图片
        $images = [];
        $imgErrors = [];
        if (!empty($_FILES['images']['name'][0])) {
            foreach ($_FILES['images']['name'] as $i => $name) {
                if ($_FILES['images']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $file = [
                    'name' => $name,
                    'type' => $_FILES['images']['type'][$i],
                    'tmp_name' => $_FILES['images']['tmp_name'][$i],
                    'error' => $_FILES['images']['error'][$i],
                    'size' => $_FILES['images']['size'][$i],
                ];
                $r = handle_upload($file, ['jpg','jpeg','png','gif','webp'], 10485760);
                if ($r['ok']) $images[] = $r['url'];
                else $imgErrors[] = $name . ': ' . $r['msg'];
            }
        }

        // 处理视频
        $video = '';
        $videoError = '';
        if (!empty($_FILES['video']['name'])) {
            $r = handle_upload($_FILES['video'], ['mp4','webm','mov'], 104857600);
            if ($r['ok']) $video = $r['url'];
            else $videoError = $r['msg'];
        }

        if (!empty($imgErrors)) {
            $uploadError = '图片上传失败: ' . implode('; ', array_slice($imgErrors, 0, 2));
        } elseif ($videoError) {
            $uploadError = '视频上传失败: ' . $videoError;
        } else {
            if ($video) $type = 'video';
            elseif (!empty($images)) $type = 'image';

            $imagesJson = json_encode($images);
            $stmt = db()->prepare("INSERT INTO posts (user_id, tieba_id, title, content, images, video, type, visibility, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
            // 后台开启"需审核"时新帖进入待审核状态（status=0），审核通过后才公开
            $stmt->execute([$user['id'], $tiebaId, $title, $content, $imagesJson, $video, $type, $visibility, intval($settings['post_audit'] ?? 0) === 1 ? 0 : 1]);

            db()->exec("UPDATE tiebas SET posts = posts + 1 WHERE id = {$tiebaId}");
            db()->exec("UPDATE users SET posts = posts + 1 WHERE id = {$user['id']}");

            // 检查是否达到 100 级（2000 帖），自动升级为管理员
            check_level_up($user['id']);

            header('Location: index.php?page=post&id=' . db()->lastInsertId());
            exit;
        }
    }
}

$pageTitle = '发布帖子';
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<style>
/* 页面级样式：双栏布局 / 可见范围选择 / 表情按钮 / 视频上传 */
.pub-layout { display: grid; grid-template-columns: 1fr 300px; gap: 16px; align-items: start; }
@media (max-width: 1100px) { .pub-layout { grid-template-columns: 1fr; } }
.vis-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.vis-option { display: block; cursor: pointer; }
.vis-option input { display: none; }
.vis-card {
    display: flex; align-items: center; gap: 10px;
    border: 1px solid var(--border); border-radius: 10px; padding: 12px;
    background: #fbfbfd; transition: all .15s;
}
.vis-card:hover { border-color: #d8c8ee; }
.vis-option input:checked + .vis-card {
    border-color: var(--accent); background: rgba(168,85,247,.06);
    box-shadow: 0 0 0 3px rgba(168,85,247,.10);
}
.vis-icon {
    width: 34px; height: 34px; border-radius: 9px; flex-shrink: 0;
    background: #f3ecfd; color: var(--accent);
    display: flex; align-items: center; justify-content: center; font-size: 14px;
}
.vis-title { font-size: 13px; font-weight: 700; }
.vis-desc { font-size: 11px; color: var(--text-light); margin-top: 2px; line-height: 1.5; }
.emoji-grid { display: flex; flex-wrap: wrap; gap: 8px; }
.emoji-btn {
    width: 40px; height: 40px; border-radius: 9px; border: 1px solid var(--border);
    background: #fbfbfd; display: flex; align-items: center; justify-content: center;
    font-size: 19px; cursor: pointer; transition: all .12s;
}
.emoji-btn:hover { border-color: var(--accent); background: #f5efff; transform: translateY(-1px); }
.video-upload-label {
    display: block; border: 2px dashed #d8c8ee; border-radius: 12px; padding: 22px;
    text-align: center; cursor: pointer; color: var(--text-light); background: #faf7ff; transition: all .15s;
}
.video-upload-label:hover { border-color: var(--accent); background: #f5efff; }
.locked-tieba {
    display: flex; align-items: center; gap: 12px; padding: 14px 16px;
    background: var(--grad); color: #fff; border-radius: 10px;
    box-shadow: 0 6px 16px rgba(168,85,247,.3);
}
</style>

<div class="pub-layout">
    <!-- 左栏：发布表单 -->
    <div>
        <?php if (!empty($uploadError)): ?>
        <div class="win-tip win-tip-error"><i class="fa fa-exclamation-circle"></i> <?= e($uploadError) ?></div>
        <?php endif; ?>

        <?php if ($canPublish): ?>
        <div class="win-card">
            <div class="win-card-title"><i class="fa fa-paper-plane"></i> 发布动态</div>
            <form id="publish-form" method="post" enctype="multipart/form-data">
                <!-- 贴吧：指定模式锁定显示 / 通用模式只能选自己创建的贴吧 -->
                <?php if ($selectedTieba): ?>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-bullhorn"></i> 发布到贴吧</label>
                    <div class="locked-tieba">
                        <span style="width:38px;height:38px;border-radius:10px;background:rgba(255,255,255,.22);display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;">
                            <i class="fa fa-<?= e($targetTieba['icon'] ?: 'tree') ?>"></i>
                        </span>
                        <div style="flex:1;min-width:0;">
                            <div style="font-weight:700;font-size:14px;"><?= e($targetTieba['name']) ?></div>
                            <div style="font-size:11px;opacity:.85;margin-top:2px;">动态将直接发布到本贴吧，无需再选择</div>
                        </div>
                        <i class="fa fa-lock" style="opacity:.75;"></i>
                    </div>
                    <input type="hidden" name="tieba_id" value="<?= $selectedTieba ?>">
                </div>
                <?php else: ?>
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-tag"></i> 选择我创建的贴吧</label>
                    <select name="tieba_id" class="form-select" required>
                        <option value="">请选择要发布到的贴吧...</option>
                        <?php foreach ($myTiebas as $t): ?>
                            <option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small class="form-hint" style="display:block;line-height:1.7;">
                        <i class="fa fa-info-circle"></i> 从这里发布仅限自己创建的贴吧；想在其他贴吧发帖，请进入对应贴吧后点击「发布帖子」按钮
                    </small>
                </div>
                <?php endif; ?>

                <!-- 标题 -->
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-font"></i> 标题（可选）</label>
                    <input name="title" class="form-input" maxlength="100" placeholder="给你的树洞起个名字...">
                </div>

                <!-- 内容 -->
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-pencil"></i> 内容</label>
                    <textarea name="content" class="form-textarea" placeholder="在这里写下你的心情、故事、想说的话... 🌳" required></textarea>
                </div>

                <!-- 可见范围 -->
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-shield"></i> 谁可以看</label>
                    <div class="vis-grid">
                        <label class="vis-option">
                            <input type="radio" name="visibility" value="public" checked>
                            <span class="vis-card">
                                <span class="vis-icon"><i class="fa fa-globe"></i></span>
                                <span>
                                    <span class="vis-title">公开</span>
                                    <span class="vis-desc" style="display:block;">所有人可见，会出现在首页、贴吧和搜索中</span>
                                </span>
                            </span>
                        </label>
                        <label class="vis-option">
                            <input type="radio" name="visibility" value="private">
                            <span class="vis-card">
                                <span class="vis-icon"><i class="fa fa-lock"></i></span>
                                <span>
                                    <span class="vis-title">仅自己可见</span>
                                    <span class="vis-desc" style="display:block;">只有你自己能看到，首页、贴吧、搜索均不展示</span>
                                </span>
                            </span>
                        </label>
                    </div>
                </div>

                <!-- 图片上传 -->
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-image"></i> 图片（最多9张）</label>
                    <input type="file" name="images[]" id="image-input" accept="image/*" multiple style="display:none;">
                    <div id="image-preview" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">
                        <label for="image-input" class="upload-add-btn">
                            <i class="fa fa-plus"></i>
                            <span>添加图片</span>
                        </label>
                    </div>
                </div>

                <!-- 视频上传 -->
                <div class="form-group">
                    <label class="form-label"><i class="fa fa-video-camera"></i> 视频（可选）</label>
                    <input type="file" name="video" id="video-input" accept="video/*" style="display:none;">
                    <label for="video-input" id="video-upload-label" class="video-upload-label">
                        <i class="fa fa-film" style="font-size:24px;color:#a78bfa;"></i>
                        <div style="font-size:13px;margin-top:6px;" id="video-name">点击上传视频</div>
                    </label>
                    <div id="video-preview" style="display:none;margin-top:8px;border-radius:12px;overflow:hidden;position:relative;">
                        <video id="video-preview-el" style="width:100%;max-height:240px;object-fit:cover;background:#000;" controls></video>
                        <button type="button" id="video-remove-btn" style="position:absolute;top:8px;right:8px;width:28px;height:28px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;border:none;cursor:pointer;font-size:16px;">×</button>
                    </div>
                </div>

                <div style="display:flex;justify-content:flex-end;border-top:1px solid var(--border);padding-top:14px;">
                    <button type="submit" class="btn btn-primary" style="min-width:140px;"><i class="fa fa-paper-plane"></i> 发布</button>
                </div>

                <p style="font-size:12px;color:var(--text-light);text-align:center;margin-top:14px;">
                    <i class="fa fa-shield"></i> 发布即代表遵守社区规范，请勿发布违规内容
                </p>
            </form>
        </div>
        <?php else: ?>
        <!-- 没有创建任何贴吧时的引导 -->
        <div class="win-card empty">
            <i class="fa fa-tree"></i>
            <p style="font-size:16px;font-weight:700;color:var(--text);">你还没有创建贴吧</p>
            <p style="font-size:13px;color:var(--text-light);margin-top:10px;line-height:1.9;">
                从这里发布，仅限自己创建的贴吧哦~<br>
                想在其他贴吧发帖，请先进入对应贴吧，<br>点击「<strong style="color:var(--accent);">发布帖子</strong>」按钮就能直接发布啦
            </p>
            <a href="index.php?page=discover" class="btn btn-primary" style="margin-top:18px;">
                <i class="fa fa-compass"></i> 去创建自己的贴吧
            </a>
        </div>
        <?php endif; ?>
    </div>

    <!-- 右栏：发布说明 / 表情面板 -->
    <div>
        <?php if ($canPublish): ?>
        <div class="win-card">
            <div class="win-card-title"><i class="fa fa-smile-o"></i> 表情</div>
            <div class="emoji-grid">
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🌳'">🌳</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🌸'">🌸</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' ☀️'">☀️</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🌙'">🌙</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 💭'">💭</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🤍'">🤍</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🦋'">🦋</span>
                <span class="emoji-btn" onclick="document.querySelector('[name=content]').value+=' 🍃'">🍃</span>
            </div>
            <div class="form-hint" style="margin-top:10px;">点击表情即可插入到内容末尾</div>
        </div>
        <?php endif; ?>

        <div class="win-card">
            <div class="win-card-title"><i class="fa fa-info-circle"></i> 发布说明</div>
            <div style="font-size:13px;color:var(--text-soft);line-height:2;">
                <div><i class="fa fa-check" style="color:var(--success);"></i> 支持最多 9 张图片与 1 个视频</div>
                <div><i class="fa fa-check" style="color:var(--success);"></i> 选择「仅自己可见」后他人无法看到该动态</div>
                <div><i class="fa fa-check" style="color:var(--success);"></i> 请勿发布违法违规、色情暴力、人身攻击内容</div>
                <div><i class="fa fa-check" style="color:var(--success);"></i> 发布成功后自动跳转到动态详情页</div>
            </div>
        </div>

        <?php
        $up = upload_check();
        ?>
        <div class="win-card">
            <div class="win-card-title"><i class="fa fa-cloud-upload"></i> 上传限制</div>
            <div style="font-size:12px;color:var(--text-light);line-height:2;">
                <div>单图上限：<?= $up['upload_max_filesize'] ?></div>
                <div>单视频上限：100MB</div>
                <div>单次最多文件数：<?= $up['max_file_uploads'] ?></div>
                <div>支持格式：jpg / png / gif / webp；mp4 / webm / mov</div>
            </div>
        </div>
    </div>
</div>

<?php if ($canPublish): ?>
<script>
setupImageUpload('image-input', 'image-preview', 9);

// 视频预览与删除
const videoInput = document.getElementById('video-input');
const videoPreview = document.getElementById('video-preview');
const videoPreviewEl = document.getElementById('video-preview-el');
const videoRemoveBtn = document.getElementById('video-remove-btn');
const videoUploadLabel = document.getElementById('video-upload-label');
const videoName = document.getElementById('video-name');

videoInput.addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const url = URL.createObjectURL(this.files[0]);
        videoPreviewEl.src = url;
        videoPreview.style.display = 'block';
        videoUploadLabel.style.display = 'none';
        videoName.textContent = this.files[0].name;
    }
});
videoRemoveBtn.addEventListener('click', function() {
    videoInput.value = '';
    videoPreviewEl.src = '';
    videoPreview.style.display = 'none';
    videoUploadLabel.style.display = 'block';
    videoName.textContent = '点击上传视频';
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
