<?php
/**
 * Windows 版 - 注册页
 * 功能与 pages/register.php 完全一致：allow_register 开关、字段校验、创建账号
 */

$error = '';
$registerOpen = intval($settings['allow_register'] ?? 1) === 1;

// 注册关闭时，拒绝所有 POST 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$registerOpen) {
    $error = '站长已关闭注册功能';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (strlen($username) < 3) $error = '用户名至少3个字符';
    elseif (strlen($password) < 6) $error = '密码至少6个字符';
    elseif ($password !== $confirm) $error = '两次密码不一致';
    else {
        $stmt = db()->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) $error = '用户名已被使用';
        else {
            $hash = hash_password($password);
            $stmt = db()->prepare("INSERT INTO users (username, password, nickname, email, role, created_at) VALUES (?, ?, ?, ?, 'user', NOW())");
            $stmt->execute([$username, $hash, $nickname ?: $username, $email]);
            $_SESSION['uid'] = db()->lastInsertId();
            header('Location: index.php');
            exit;
        }
    }
}

$pageTitle = '注册';
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<div class="win-center">
    <div class="auth-card" style="max-width:620px;">
        <div style="display:flex;align-items:center;justify-content:center;gap:28px;flex-wrap:wrap;text-align:left;">
            <!-- 图标 + 下方提示文字：位于注册框左侧，垂直居中 -->
            <div style="flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:10px;">
                <div style="width:96px;height:96px;border-radius:50%;background:linear-gradient(135deg,#a855f7,#ec4899);display:flex;align-items:center;justify-content:center;box-shadow:0 10px 26px rgba(168,85,247,.4);color:#fff;font-size:38px;">
                    <i class="fa fa-star"></i>
                </div>
                <h1 class="auth-title" style="font-size:20px;">加入<?= e($settings['site_name'] ?? '') ?: '加入贴吧' ?></h1>
                <div style="font-size:12px;color:var(--text-soft);min-height:16px;width:150px;text-align:center;line-height:1.5;">在这里，每一份情绪都被温柔以待 🌸</div>
            </div>

            <!-- 注册表单区 -->
            <div style="flex:1;min-width:260px;">
                

                <?php if ($error): ?>
                    <div class="win-tip win-tip-error" style="text-align:left;margin-top:14px;">
                        <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
                    </div>
                <?php endif; ?>

                <?php if (!$registerOpen): ?>
                    <!-- 注册已关闭 -->
                    <div class="win-card" style="margin-top:16px;padding:32px 20px;">
                        <div style="width:60px;height:60px;margin:0 auto;border-radius:50%;background:#fee2e2;color:#dc2626;display:flex;align-items:center;justify-content:center;font-size:22px;">
                            <i class="fa fa-lock"></i>
                        </div>
                        <h3 style="font-size:16px;font-weight:600;margin-top:14px;color:var(--text);">注册功能已关闭</h3>
                        <p style="font-size:13px;color:var(--text-soft);margin-top:8px;line-height:1.6;">管理员已暂时关闭新用户注册<br>如有疑问请联系站方</p>
                        <a href="index.php?page=login" class="btn btn-primary btn-block" style="margin-top:18px;">
                            <i class="fa fa-sign-in"></i> 去登录
                        </a>
                    </div>
                <?php else: ?>
                <form method="post" class="win-card" style="text-align:left;margin-top:16px;">
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-user" style="color:var(--accent);margin-right:4px;"></i> 用户名</label>
                        <input name="username" class="form-input" placeholder="3-20个字符" required minlength="3" maxlength="20">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-smile-o" style="color:var(--accent);margin-right:4px;"></i> 昵称</label>
                        <input name="nickname" class="form-input" placeholder="给自己起个好听的名字">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-envelope" style="color:var(--accent);margin-right:4px;"></i> 邮箱（可选）</label>
                        <input name="email" type="email" class="form-input" placeholder="用于找回密码">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-lock" style="color:var(--accent);margin-right:4px;"></i> 密码</label>
                        <input name="password" type="password" class="form-input" placeholder="至少6个字符" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label class="form-label"><i class="fa fa-lock" style="color:var(--accent);margin-right:4px;"></i> 确认密码</label>
                        <input name="confirm" type="password" class="form-input" placeholder="再次输入密码" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" style="padding:13px;font-size:14px;margin-top:4px;">
                        <i class="fa fa-heart"></i> 注 册
                    </button>
                </form>
                <?php endif; ?>

                <div style="margin-top:16px;">
                    <p style="font-size:13px;color:var(--text-soft);">
                        已有账号？
                        <a href="index.php?page=login" style="color:var(--primary);font-weight:600;">去登录</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
