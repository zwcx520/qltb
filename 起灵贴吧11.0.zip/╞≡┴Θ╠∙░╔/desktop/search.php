<?php
/**
 * Windows 版 - 搜索
 * 功能与 pages/search.php 完全一致：帖子/贴吧/用户三分类 Tab、模糊查询、帖子结果私密帖仅作者可见过滤
 */
$pageTitle = '搜索';
$currentPage = 'search';

$kw = trim($_GET['kw'] ?? '');
$type = $_GET['type'] ?? 'post';

$results = [];
$hotKeywords = ['心情', '深夜', '治愈', '日常', '树洞', '温柔', '孤独', '希望'];

if ($kw) {
    if ($type === 'tieba') {
        $stmt = db()->prepare("SELECT * FROM tiebas WHERE name LIKE ? OR description LIKE ? ORDER BY members DESC LIMIT 20");
        $stmt->execute(["%{$kw}%", "%{$kw}%"]);
        $results = $stmt->fetchAll();
    } elseif ($type === 'user') {
        $stmt = db()->prepare("SELECT * FROM users WHERE nickname LIKE ? OR username LIKE ? LIMIT 20");
        $stmt->execute(["%{$kw}%", "%{$kw}%"]);
        $results = $stmt->fetchAll();
    } else {
        // 帖子搜索：私密帖仅作者本人可搜到
        $visWhere = $user ? " AND (p.visibility = 'public' OR p.user_id = ?)" : " AND p.visibility = 'public'";
        $stmt = db()->prepare("
            SELECT p.*, u.nickname, u.avatar, u.role, u.posts, t.name as tieba_name
            FROM posts p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN tiebas t ON p.tieba_id = t.id
            WHERE (p.title LIKE ? OR p.content LIKE ?){$visWhere}
            ORDER BY p.created_at DESC LIMIT 20
        ");
        $params = ["%{$kw}%", "%{$kw}%"];
        if ($user) $params[] = $user['id'];
        $stmt->execute($params);
        $results = $stmt->fetchAll();
    }
}

include __DIR__ . '/_header.php';
?>

<style>
.clamp2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.search-tabs { display: flex; gap: 4px; background: #ececf3; padding: 4px; border-radius: 10px; margin-bottom: 16px; }
.search-tabs .msg-tab { flex: 1; }
</style>

<!-- 搜索框 -->
<div class="win-card" style="margin-bottom:16px;">
    <form action="index.php" method="get" style="display:flex;gap:10px;align-items:center;">
        <input type="hidden" name="page" value="search">
        <input type="hidden" name="type" value="<?= e($type) ?>">
        <div class="win-search" style="max-width:none;flex:1;">
            <i class="fa fa-search"></i>
            <input type="text" name="kw" value="<?= e($kw) ?>" placeholder="搜索贴吧、帖子、用户..." autofocus>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> 搜索</button>
        <?php if ($kw): ?><a href="index.php?page=search" class="btn btn-ghost" title="清空搜索"><i class="fa fa-times"></i></a><?php endif; ?>
    </form>
</div>

<!-- 三分类 Tab -->
<div class="search-tabs">
    <?php foreach (['post'=>'帖子','tieba'=>'贴吧','user'=>'用户'] as $k => $v): ?>
        <a href="index.php?page=search&type=<?= $k ?>&kw=<?= urlencode($kw) ?>" class="msg-tab <?= $type===$k?'active':'' ?>"><?= $v ?></a>
    <?php endforeach; ?>
</div>

<?php if (!$kw): ?>
    <!-- 热门搜索 -->
    <div class="win-section-title"><span><i class="fa fa-fire"></i> 热门搜索</span></div>
    <div class="cat-grid">
        <?php foreach ($hotKeywords as $k): ?>
            <a href="index.php?page=search&kw=<?= urlencode($k) ?>" class="cat-chip"><i class="fa fa-search"></i> <?= e($k) ?></a>
        <?php endforeach; ?>
    </div>
<?php elseif (empty($results)): ?>
    <div class="win-card empty">
        <i class="fa fa-search"></i>
        <p>没有找到"<?= e($kw) ?>"相关内容</p>
        <p style="font-size:12px;margin-top:6px;">换个关键词试试吧 ~</p>
    </div>
<?php else: ?>
    <div style="font-size:13px;color:var(--text-soft);margin-bottom:10px;">共找到 <?= count($results) ?> 条结果</div>

    <?php if ($type === 'post'): foreach ($results as $r):
        $imgs = $r['images'] ? json_decode($r['images'], true) : [];
    ?>
        <a href="index.php?page=post&id=<?= $r['id'] ?>" class="post-card" style="display:block;">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
                <img src="<?= e(avatar(['id'=>$r['user_id'],'avatar'=>$r['avatar'],'nickname'=>$r['nickname']])) ?>" class="avatar" alt="">
                <span style="font-size:13px;font-weight:600;"><?= e($r['nickname']) ?></span>
                <?= user_label($r) ?>
                <span class="tag" style="background:rgba(168,85,247,.09);color:var(--accent);"><?= e($r['tieba_name']) ?></span>
                <?= visibility_badge($r) ?>
            </div>
            <?php if ($r['title']): ?><div style="font-weight:700;font-size:15px;margin-bottom:4px;"><?= e($r['title']) ?></div><?php endif; ?>
            <div class="clamp2" style="font-size:13px;color:var(--text-soft);line-height:1.7;"><?= e($r['content']) ?></div>
            <?php if (!empty($imgs)): ?>
                <div style="display:flex;gap:6px;margin-top:8px;">
                    <?php foreach (array_slice($imgs,0,3) as $img): ?>
                        <img src="<?= e($img) ?>" style="width:64px;height:64px;border-radius:8px;object-fit:cover;" alt="">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </a>
    <?php endforeach; elseif ($type === 'tieba'): foreach ($results as $r): ?>
        <a href="index.php?page=tieba&id=<?= $r['id'] ?>" class="tieba-row" style="margin-bottom:10px;">
            <div class="tieba-cover-sm" style="background:<?= cover($r) ?>"><i class="fa fa-<?= e($r['icon'] ?: 'tree') ?>"></i></div>
            <div style="min-width:0;">
                <div class="tieba-row-name"><?= e($r['name']) ?></div>
                <div class="tieba-row-desc"><?= e($r['description']) ?></div>
                <div class="tieba-row-meta"><i class="fa fa-users"></i> <?= $r['members'] ?> 成员</div>
            </div>
        </a>
    <?php endforeach; else: foreach ($results as $r): ?>
        <a href="index.php?page=user&id=<?= $r['id'] ?>" class="tieba-row" style="margin-bottom:10px;">
            <img src="<?= e(avatar($r)) ?>" class="tieba-cover-sm" style="border-radius:50%;" alt="">
            <div style="min-width:0;">
                <div class="tieba-row-name"><?= e($r['nickname'] ?: $r['username']) ?></div>
                <div class="tieba-row-desc"><?= e($r['bio'] ?: '@'.$r['username']) ?></div>
                <div class="tieba-row-meta"><i class="fa fa-file-text-o"></i> <?= $r['posts'] ?> 帖子</div>
            </div>
        </a>
    <?php endforeach; endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
