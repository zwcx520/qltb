<?php
/**
 * Windows 版 - 贴吧详情页
 * 功能与 pages/tieba.php 完全一致：大封面（吧主可更换/移除）、吧主信息、关注/取关、排序 Tab、帖子列表（公开帖+本人私密帖）
 */
$tiebaId = intval($_GET['id'] ?? 0);
$tieba = db()->prepare("SELECT * FROM tiebas WHERE id = ?");
$tieba->execute([$tiebaId]);
$tieba = $tieba->fetch();

if (!$tieba) { header('Location: index.php?page=discover'); exit; }

// 查询吧主信息
$owner = null;
if (!empty($tieba['owner_id'])) {
    $stmt = db()->prepare("SELECT id, nickname, username, avatar FROM users WHERE id = ?");
    $stmt->execute([$tieba['owner_id']]);
    $owner = $stmt->fetch();
}
$isOwner = ($user && $owner && $user['id'] == $owner['id']);

// 吧主更换封面
$coverMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['act'] ?? '') === 'change_cover' && $isOwner) {
    if (!empty($_FILES['cover']['name'])) {
        $r = handle_upload($_FILES['cover'], ['jpg','jpeg','png','gif','webp'], 5242880);
        if ($r['ok']) {
            // 删除旧封面
            if (!empty($tieba['cover'])) delete_uploaded_file($tieba['cover']);
            db()->prepare("UPDATE tiebas SET cover = ? WHERE id = ?")->execute([$r['url'], $tiebaId]);
            // 重新查询
            $tieba = db()->prepare("SELECT * FROM tiebas WHERE id = ?");
            $tieba->execute([$tiebaId]);
            $tieba = $tieba->fetch();
            $coverMsg = '封面更换成功';
        } else {
            $coverMsg = '封面上传失败: ' . $r['msg'];
        }
    } elseif (isset($_POST['remove_cover'])) {
        // 移除封面，恢复图标
        if (!empty($tieba['cover'])) delete_uploaded_file($tieba['cover']);
        db()->prepare("UPDATE tiebas SET cover = '' WHERE id = ?")->execute([$tiebaId]);
        $tieba['cover'] = '';
        $coverMsg = '封面已移除';
    }
}

$sort = $_GET['sort'] ?? 'new';
$order = $sort === 'hot' ? 'p.likes DESC, p.comments DESC' : 'p.is_top DESC, p.created_at DESC';

$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 10;
$offset = ($pageNum - 1) * $perPage;

$total = db()->query("SELECT COUNT(*) FROM posts WHERE tieba_id = {$tiebaId} AND status = 1 AND " . ($user ? "(visibility = 'public' OR user_id = " . intval($user['id']) . ")" : "visibility = 'public'"))->fetchColumn();
$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.role, u.posts
    FROM posts p LEFT JOIN users u ON p.user_id = u.id
    WHERE p.tieba_id = ? AND p.status = 1 AND " . ($user ? "(p.visibility = 'public' OR p.user_id = " . intval($user['id']) . ")" : "p.visibility = 'public'") . "
    ORDER BY {$order}
    LIMIT {$offset}, {$perPage}
");
$stmt->execute([$tiebaId]);
$posts = $stmt->fetchAll();

$followed = is_followed($tiebaId);

$pageTitle = $tieba['name'];
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<!-- 贴吧大封面 -->
<div class="tieba-hero" style="background:<?= cover($tieba) ?>;">
    <a href="index.php?page=discover" class="btn btn-ghost btn-sm" style="position:absolute;top:16px;left:20px;z-index:2;background:rgba(255,255,255,.88);border:none;color:var(--text);">
        <i class="fa fa-angle-left"></i> 返回发现
    </a>
    <?php if ($isOwner): ?>
    <form method="post" enctype="multipart/form-data" id="coverForm" style="position:absolute;top:16px;right:20px;z-index:2;display:flex;gap:8px;">
        <input type="hidden" name="act" value="change_cover">
        <input type="file" name="cover" id="tieba-cover-input" accept="image/*" style="display:none;">
        <button type="button" onclick="document.getElementById('tieba-cover-input').click()" class="btn btn-sm" style="background:rgba(0,0,0,.45);color:#fff;border:none;" title="更换封面">
            <i class="fa fa-camera"></i> 更换封面
        </button>
        <?php if (!empty($tieba['cover'])): ?>
        <button type="submit" name="remove_cover" value="1" class="btn btn-sm" style="background:rgba(0,0,0,.45);color:#fff;border:none;" title="移除封面" onclick="return confirm('确定移除封面，恢复默认图标？');">
            <i class="fa fa-times"></i> 移除封面
        </button>
        <?php endif; ?>
    </form>
    <?php endif; ?>
    <div class="tieba-hero-icon"><i class="fa fa-<?= e($tieba['icon'] ?: 'tree') ?>"></i></div>
    <div>
        <h2 style="font-size:26px;font-weight:800;letter-spacing:.5px;text-shadow:0 2px 8px rgba(0,0,0,.3);">
            <i class="fa fa-<?= e($tieba['icon'] ?: 'tree') ?>"></i> <?= e($tieba['name']) ?>
        </h2>
        <div style="font-size:13px;opacity:.95;margin-top:6px;"><?= e($tieba['description']) ?></div>
        <div style="margin-top:10px;">
            <span class="tieba-stat"><i class="fa fa-users"></i> <?= $tieba['members'] ?> 成员</span>
            <span class="tieba-stat"><i class="fa fa-file-text-o"></i> <?= $tieba['posts'] ?> 帖子</span>
        </div>
    </div>
</div>

<?php if ($coverMsg): ?>
<div class="win-tip <?= strpos($coverMsg,'失败')!==false?'win-tip-error':'win-tip-success' ?>">
    <i class="fa fa-<?= strpos($coverMsg,'失败')!==false?'exclamation-circle':'check-circle' ?>"></i> <?= e($coverMsg) ?>
</div>
<?php endif; ?>

<!-- 统计 / 吧主 / 关注 -->
<div class="win-card" style="display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:16px 20px;">
    <div style="display:flex;gap:26px;">
        <div style="text-align:center;">
            <div style="font-size:20px;font-weight:800;color:var(--accent);"><?= $tieba['members'] ?></div>
            <div style="font-size:12px;color:var(--text-light);">成员</div>
        </div>
        <div style="text-align:center;">
            <div style="font-size:20px;font-weight:800;color:var(--accent);"><?= $tieba['posts'] ?></div>
            <div style="font-size:12px;color:var(--text-light);">帖子</div>
        </div>
    </div>
    <?php if ($owner): ?>
    <div style="display:flex;align-items:center;gap:8px;padding:7px 14px;background:#faf9fd;border:1px solid var(--border);border-radius:20px;">
        <i class="fa fa-crown" style="color:#f59e0b;"></i>
        <span style="font-size:12px;color:var(--text-soft);">吧主</span>
        <a href="index.php?page=user&id=<?= $owner['id'] ?>" style="display:flex;align-items:center;gap:6px;">
            <img src="<?= e(avatar($owner)) ?>" style="width:22px;height:22px;border-radius:50%;object-fit:cover;" alt="">
            <span style="font-size:13px;color:var(--accent);font-weight:600;"><?= e($owner['nickname'] ?: $owner['username']) ?></span>
        </a>
        <?php if ($isOwner): ?>
        <span class="tag" style="background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#fff;"><i class="fa fa-crown"></i> 我是吧主</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <div style="margin-left:auto;display:flex;gap:10px;">
        <?php if ($user): ?>
            <button class="btn <?= $followed ? 'btn-ghost' : 'btn-primary' ?>" onclick="followTieba(<?= $tiebaId ?>, this)">
                <i class="fa fa-<?= $followed ? 'check' : 'plus' ?>"></i> <?= $followed ? '已关注' : '关注' ?>
            </button>
        <?php else: ?>
            <a href="index.php?page=login" class="btn btn-primary"><i class="fa fa-plus"></i> 关注</a>
        <?php endif; ?>
        <a href="index.php?page=publish&tieba=<?= $tiebaId ?>" class="btn btn-ghost"><i class="fa fa-pencil"></i> 发布帖子</a>
    </div>
</div>

<!-- 排序 Tab -->
<div class="msg-tabs" style="max-width:260px;">
    <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=new" class="msg-tab <?= $sort==='new'?'active':'' ?>"><i class="fa fa-clock-o"></i> 最新</a>
    <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=hot" class="msg-tab <?= $sort==='hot'?'active':'' ?>"><i class="fa fa-fire"></i> 热门</a>
</div>

<!-- 帖子列表 -->
<?php if (empty($posts)): ?>
    <div class="win-card empty">
        <i class="fa fa-leaf"></i>
        <p>这个贴吧还没有帖子</p>
        <?php if ($user): ?>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">点击上方「发布帖子」发布第一条帖子吧 ~</p>
        <?php else: ?>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">
            <a href="index.php?page=login" style="color:var(--accent);font-weight:600;">登录</a> 后发布第一条帖子吧 ~
        </p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
        $imgClass = count($imgs) === 1 ? 'single' : (count($imgs) === 2 ? 'double' : (count($imgs) >= 3 ? 'triple' : ''));
        $liked = is_liked($p['id']);
    ?>
    <div class="post-card">
        <div class="post-header">
            <a href="index.php?page=user&id=<?= $p['user_id'] ?>">
                <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar" alt="">
            </a>
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname']) ?> <?= user_label($p) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?></div>
            </div>
            <?php if ($p['is_top']): ?><span class="tag tag-top">置顶</span><?php endif; ?>
            <?= visibility_badge($p) ?>
        </div>
        <?php if ($p['title']): ?>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-title"><?= e($p['title']) ?></a>
        <?php endif; ?>
        <?php if ($p['content']): ?>
            <div class="post-content"><?= nl2br(e($p['content'])) ?></div>
        <?php endif; ?>
        <?php if (!empty($imgs)): ?>
            <div class="post-images <?= $imgClass ?>">
                <?php foreach (array_slice($imgs,0,9) as $img): ?>
                    <img src="<?= e($img) ?>" onclick="previewImage('<?= e($img) ?>')" alt="">
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($p['video']): ?>
            <div class="post-video">
                <video src="<?= e($p['video']) ?>" preload="metadata"></video>
                <div class="video-play"><i class="fa fa-play"></i></div>
            </div>
        <?php endif; ?>
        <div class="post-actions">
            <div class="post-action <?= $liked?'liked':'' ?>" onclick="likePost(<?= $p['id'] ?>, this)">
                <i class="fa <?= $liked?'fa-heart':'fa-heart-o' ?>"></i><span class="count"><?= $p['likes'] ?></span>
            </div>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-action"><i class="fa fa-comment-o"></i><span><?= $p['comments'] ?></span></a>
            <div class="post-action" onclick="toast('已分享~')"><i class="fa fa-share-alt"></i><span><?= $p['shares'] ?></span></div>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- 分页 -->
    <?php $totalPage = ceil($total / $perPage); if ($totalPage > 1): ?>
    <div style="display:flex;justify-content:center;gap:8px;padding:18px 0;">
        <?php if ($pageNum > 1): ?>
            <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=<?= $sort ?>&p=<?= $pageNum-1 ?>" class="btn btn-ghost"><i class="fa fa-angle-left"></i> 上一页</a>
        <?php endif; ?>
        <span class="btn btn-ghost"><?= $pageNum ?> / <?= $totalPage ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="index.php?page=tieba&id=<?= $tiebaId ?>&sort=<?= $sort ?>&p=<?= $pageNum+1 ?>" class="btn btn-ghost">下一页 <i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php if ($isOwner): ?>
<script>
// 选择封面图后自动提交
document.getElementById('tieba-cover-input').addEventListener('change', function(){
    if (this.files && this.files[0]) {
        document.getElementById('coverForm').submit();
    }
});
</script>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
