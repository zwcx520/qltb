<?php
/**
 * Windows 版 - 贴吧内容管理（吧主管理自己创建的贴吧内的帖子）
 * 功能与 pages/tieba_manage.php 完全一致：置顶/取消置顶/删除帖子（事务清理与源文件一致），仅吧主本人可操作
 */
$tiebaId = intval($_GET['id'] ?? 0);

// 查询贴吧
$stmt = db()->prepare("SELECT * FROM tiebas WHERE id = ?");
$stmt->execute([$tiebaId]);
$tieba = $stmt->fetch();

// 贴吧不存在或当前用户不是吧主 → 直接回我的贴吧
if (!$tieba || !$user || $tieba['owner_id'] != $user['id']) {
    header('Location: index.php?page=my_tiebas');
    exit;
}

// 处理 POST 操作：置顶/取消置顶、删除帖子（仅本吧吧主）
$opMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    $postId = intval($_POST['post_id'] ?? 0);

    if ($postId > 0) {
        // 校验该帖子确实属于本贴吧；他人的私密帖吧主不可见也不可操作
        $chk = db()->prepare("SELECT id, images, video, user_id FROM posts WHERE id = ? AND tieba_id = ? AND (visibility = 'public' OR user_id = ?)");
        $chk->execute([$postId, $tiebaId, $user['id']]);
        $post = $chk->fetch();

        if ($post) {
            if ($act === 'top') {
                // 切换置顶
                db()->prepare("UPDATE posts SET is_top = 1 - is_top WHERE id = ?")->execute([$postId]);
                $opMsg = '置顶状态已更新';
            } elseif ($act === 'delete') {
                // 删除帖子：连带文件、关联数据、计数（与 delete_post.php 一致的清理逻辑）
                try {
                    db()->beginTransaction();
                    if (!empty($post['images'])) {
                        $imgs = json_decode($post['images'], true);
                        if (is_array($imgs)) foreach ($imgs as $img) delete_uploaded_file($img);
                    }
                    if (!empty($post['video'])) delete_uploaded_file($post['video']);

                    db()->prepare("DELETE FROM comments WHERE post_id = ?")->execute([$postId]);
                    db()->prepare("DELETE FROM post_likes WHERE post_id = ?")->execute([$postId]);
                    db()->prepare("DELETE FROM post_favorites WHERE post_id = ?")->execute([$postId]);
                    db()->prepare("DELETE FROM messages WHERE post_id = ?")->execute([$postId]);
                    db()->exec("UPDATE tiebas SET posts = GREATEST(posts - 1, 0) WHERE id = {$tiebaId}");
                    db()->exec("UPDATE users SET posts = GREATEST(posts - 1, 0) WHERE id = {$post['user_id']}");
                    db()->prepare("DELETE FROM posts WHERE id = ?")->execute([$postId]);
                    db()->commit();
                    $opMsg = '帖子已删除';
                } catch (Exception $e) {
                    db()->rollBack();
                    $opMsg = '删除失败';
                }
            }
        }
    }
}

// 帖子列表（含待审核 status=0 的，吧主应能管理全部；但他人的私密帖不展示给吧主）
$total = db()->query("SELECT COUNT(*) FROM posts WHERE tieba_id = {$tiebaId} AND (visibility = 'public' OR user_id = " . intval($user['id']) . ")")->fetchColumn();
$pageNum = max(1, intval($_GET['p'] ?? 1));
$perPage = 15;
$offset = ($pageNum - 1) * $perPage;

$stmt = db()->prepare("
    SELECT p.*, u.nickname, u.avatar as u_avatar, u.username, u.role, u.posts
    FROM posts p LEFT JOIN users u ON p.user_id = u.id
    WHERE p.tieba_id = ? AND (p.visibility = 'public' OR p.user_id = ?)
    ORDER BY p.is_top DESC, p.created_at DESC
    LIMIT {$offset}, {$perPage}
");
$stmt->execute([$tiebaId, $user['id']]);
$posts = $stmt->fetchAll();
$totalPage = ceil($total / $perPage);

$pageTitle = '管理内容 - ' . $tieba['name'];
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<!-- 页头 -->
<div class="win-section-title" style="margin-top:0;">
    <span>
        <i class="fa fa-cog"></i> <?= e($tieba['name']) ?>
        <span style="font-size:12px;font-weight:400;color:var(--text-light);margin-left:6px;">管理内容 · 共 <?= $total ?> 帖</span>
    </span>
    <a href="index.php?page=tieba&id=<?= $tiebaId ?>" class="more"><i class="fa fa-eye"></i> 查看贴吧</a>
</div>

<?php if ($opMsg): ?>
<div class="win-tip win-tip-success"><i class="fa fa-check-circle"></i> <?= e($opMsg) ?></div>
<?php endif; ?>

<!-- 权限说明 -->
<div style="background:rgba(251,191,36,.12);color:#92400e;border:1px solid rgba(251,191,36,.3);border-radius:10px;padding:10px 14px;font-size:13px;display:flex;align-items:flex-start;gap:8px;margin-bottom:16px;">
    <i class="fa fa-info-circle" style="margin-top:2px;"></i>
    <span>作为吧主，你可以管理本贴吧内的帖子（置顶/删除），但不能修改或删除贴吧本身信息。</span>
</div>

<?php if (empty($posts)): ?>
    <div class="win-card empty">
        <i class="fa fa-leaf"></i>
        <p>这个贴吧还没有帖子</p>
    </div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
    ?>
    <div class="post-card">
        <div class="post-header">
            <a href="index.php?page=user&id=<?= $p['user_id'] ?>">
                <img src="<?= e(avatar(['id'=>$p['user_id'],'avatar'=>$p['u_avatar'],'nickname'=>$p['nickname']])) ?>" class="post-avatar" alt="">
            </a>
            <div class="post-user">
                <div class="post-nick"><?= e($p['nickname'] ?: $p['username']) ?> <?= user_label($p) ?></div>
                <div class="post-time"><?= time_ago($p['created_at']) ?></div>
            </div>
            <?php if ($p['is_top']): ?><span class="tag tag-top">置顶</span><?php endif; ?>
            <?= visibility_badge($p) ?>
            <?php if ($p['status'] == 0): ?><span class="tag" style="background:#fef3c7;color:#92400e;">待审核</span><?php endif; ?>
        </div>
        <a href="index.php?page=post&id=<?= $p['id'] ?>">
            <?php if ($p['title']): ?><div class="post-title"><?= e($p['title']) ?></div><?php endif; ?>
            <div class="post-content"><?= nl2br(e($p['content'])) ?></div>
            <?php if (!empty($imgs)): ?>
                <div class="post-images <?= count($imgs)===1?'single':(count($imgs)===2?'double':'triple') ?>">
                    <?php foreach (array_slice($imgs,0,3) as $img): ?>
                        <img src="<?= e($img) ?>" alt="">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </a>
        <div style="display:flex;gap:10px;align-items:center;margin-top:12px;padding-top:12px;border-top:1px dashed var(--border);flex-wrap:wrap;">
            <span style="font-size:12px;color:var(--text-light);flex:1;min-width:140px;">
                <i class="fa fa-eye"></i> <?= $p['views'] ?> ·
                <i class="fa fa-heart-o"></i> <?= $p['likes'] ?> ·
                <i class="fa fa-comment-o"></i> <?= $p['comments'] ?>
            </span>
            <!-- 置顶/取消置顶 -->
            <form method="post" style="display:inline;">
                <input type="hidden" name="act" value="top">
                <input type="hidden" name="post_id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-ghost btn-sm">
                    <i class="fa fa-<?= $p['is_top']?'star':'star-o' ?>"></i>
                    <?= $p['is_top']?'取消置顶':'置顶' ?>
                </button>
            </form>
            <!-- 删除帖子 -->
            <form method="post" style="display:inline;" onsubmit="return confirm('确定删除这条帖子？帖子图片/视频和评论将一并删除，且无法恢复。')">
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="post_id" value="<?= $p['id'] ?>">
                <button type="submit" class="btn btn-sm btn-danger">
                    <i class="fa fa-trash-o"></i> 删除
                </button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- 分页 -->
    <?php if ($totalPage > 1): ?>
    <div style="display:flex;justify-content:center;gap:8px;padding:18px 0;">
        <?php if ($pageNum > 1): ?>
            <a href="index.php?page=tieba_manage&id=<?= $tiebaId ?>&p=<?= $pageNum-1 ?>" class="btn btn-ghost"><i class="fa fa-angle-left"></i> 上一页</a>
        <?php endif; ?>
        <span class="btn btn-ghost"><?= $pageNum ?> / <?= $totalPage ?></span>
        <?php if ($pageNum < $totalPage): ?>
            <a href="index.php?page=tieba_manage&id=<?= $tiebaId ?>&p=<?= $pageNum+1 ?>" class="btn btn-ghost">下一页 <i class="fa fa-angle-right"></i></a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
