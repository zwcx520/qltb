<?php
/**
 * Windows 版 - 用户主页
 * 功能与 pages/user.php 完全一致：头像昵称签名、关注/取关按钮（followUser）、
 * privacy_posts/privacy_following/privacy_followers/privacy_tiebas 隐私过滤、动态列表、本人访问时跳编辑入口
 */
$uid = intval($_GET['id'] ?? 0);
$target = db()->prepare("SELECT * FROM users WHERE id = ?");
$target->execute([$uid]);
$target = $target->fetch();

if (!$target) { header('Location: index.php'); exit; }

// 是否本人查看（本人可见自己的私密帖）
$isOwner = ($user && $user['id'] == $target['id']);
// 帖子可见性条件：本人看自己 -> 全部；其他任何人（含游客）-> 仅公开帖
$postVisSql = $isOwner ? '1=1' : "visibility = 'public'";

$pageTitle = $target['nickname'] ?: $target['username'];
$currentPage = '';

// 统计（非本人查看时，动态数不统计私密帖）
$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM posts WHERE user_id = {$target['id']} AND {$postVisSql}) as posts,
    (SELECT COUNT(*) FROM user_follows WHERE follower_id = {$target['id']}) as following,
    (SELECT COUNT(*) FROM user_follows WHERE following_id = {$target['id']}) as followers,
    (SELECT COUNT(*) FROM tieba_follows WHERE user_id = {$target['id']}) as tiebas
")->fetch();

// 是否关注
$isFollowing = false;
if ($user) {
    $stmt = db()->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
    $stmt->execute([$user['id'], $target['id']]);
    $isFollowing = (bool)$stmt->fetch();
}

// 隐私设置
$canSeePosts     = $isOwner || ($target['privacy_posts'] ?? 'public') === 'public';
$canSeeFollowing = $isOwner || ($target['privacy_following'] ?? 'public') === 'public';
$canSeeFollowers = $isOwner || ($target['privacy_followers'] ?? 'public') === 'public';
$canSeeTiebas    = $isOwner || ($target['privacy_tiebas'] ?? 'public') === 'public';

// 用户帖子（仅在有权限时查询；私密帖仅作者本人可见）
$posts = [];
if ($canSeePosts) {
    $posts = db()->query("
        SELECT p.*, t.name as tieba_name FROM posts p
        LEFT JOIN tiebas t ON p.tieba_id = t.id
        WHERE p.user_id = {$target['id']} AND p.status = 1 AND {$postVisSql}
        ORDER BY p.created_at DESC LIMIT 20
    ")->fetchAll();
}

include __DIR__ . '/_header.php';
?>

<style>
.clamp2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.user-head {
    background: linear-gradient(135deg, #f3e8ff 0%, #fce7f3 100%);
    border: 1px solid var(--border); border-radius: var(--radius);
    box-shadow: var(--shadow); padding: 28px 24px; margin-bottom: 16px;
}
.user-stats { margin-top: 20px; }
.user-stats .stat-item { background: rgba(255,255,255,.72); }
</style>

<!-- 个人信息头 -->
<div class="user-head">
    <div class="profile-head">
        <img src="<?= e(avatar($target)) ?>" class="avatar-lg" style="border:4px solid #fff;box-shadow:0 8px 24px rgba(0,0,0,.12);" alt="">
        <div class="profile-info">
            <div class="profile-name"><?= e($target['nickname'] ?: $target['username']) ?> <?= user_label($target) ?></div>
            <div class="profile-bio"><?= e($target['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
            <div style="font-size:12px;color:var(--text-light);margin-top:4px;">@<?= e($target['username']) ?></div>
        </div>
        <div style="flex-shrink:0;">
            <?php if ($user && $user['id'] != $target['id']): ?>
                <button class="btn <?= $isFollowing ? 'btn-ghost' : 'btn-primary' ?>" onclick="followUser(<?= $target['id'] ?>, this)">
                    <i class="fa fa-<?= $isFollowing ? 'check' : 'plus' ?>"></i> <?= $isFollowing ? '已关注' : '关注' ?>
                </button>
            <?php elseif ($user && $user['id'] == $target['id']): ?>
                <a href="index.php?page=edit" class="btn btn-primary"><i class="fa fa-pencil"></i> 编辑资料</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- 统计（受隐私设置控制） -->
    <div class="stat-grid user-stats">
        <div class="stat-item">
            <div class="stat-num"><?php if ($canSeePosts): ?><?= $stats['posts'] ?><?php else: ?><i class="fa fa-lock" style="font-size:16px;-webkit-text-fill-color:var(--text-light);"></i><?php endif; ?></div>
            <div class="stat-label">动态</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php if ($canSeeFollowing): ?><?= $stats['following'] ?><?php else: ?><i class="fa fa-lock" style="font-size:16px;-webkit-text-fill-color:var(--text-light);"></i><?php endif; ?></div>
            <div class="stat-label">关注</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php if ($canSeeFollowers): ?><?= $stats['followers'] ?><?php else: ?><i class="fa fa-lock" style="font-size:16px;-webkit-text-fill-color:var(--text-light);"></i><?php endif; ?></div>
            <div class="stat-label">粉丝</div>
        </div>
        <div class="stat-item">
            <div class="stat-num"><?php if ($canSeeTiebas): ?><?= $stats['tiebas'] ?><?php else: ?><i class="fa fa-lock" style="font-size:16px;-webkit-text-fill-color:var(--text-light);"></i><?php endif; ?></div>
            <div class="stat-label">贴吧</div>
        </div>
    </div>
</div>

<!-- 帖子 -->
<div class="win-section-title"><span><i class="fa fa-file-text-o"></i> Ta的动态</span></div>

<?php if (!$canSeePosts): ?>
    <div class="win-card empty">
        <i class="fa fa-lock"></i>
        <p>TA的动态已设为私密</p>
        <p style="font-size:12px;margin-top:6px;">仅TA本人可查看</p>
    </div>
<?php elseif (empty($posts)): ?>
    <div class="win-card empty"><i class="fa fa-leaf"></i><p>还没有发布过动态</p></div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
    ?>
    <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-card" style="display:block;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
            <span class="post-tieba-tag"><i class="fa fa-tree"></i> <?= e($p['tieba_name']) ?></span>
            <?= visibility_badge($p) ?>
            <span style="font-size:12px;color:var(--text-light);"><?= time_ago($p['created_at']) ?></span>
        </div>
        <?php if ($p['title']): ?><div style="font-weight:700;font-size:15px;margin-bottom:4px;"><?= e($p['title']) ?></div><?php endif; ?>
        <div class="clamp2" style="font-size:13px;color:var(--text-soft);line-height:1.7;"><?= e($p['content']) ?></div>
        <?php if (!empty($imgs)): ?>
            <div style="display:flex;gap:6px;margin-top:8px;">
                <?php foreach (array_slice($imgs,0,3) as $img): ?>
                    <img src="<?= e($img) ?>" style="width:64px;height:64px;border-radius:8px;object-fit:cover;" alt="">
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <div style="display:flex;gap:16px;margin-top:10px;font-size:12px;color:var(--text-light);">
            <span><i class="fa fa-eye"></i> <?= $p['views'] ?></span>
            <span><i class="fa fa-heart-o"></i> <?= $p['likes'] ?></span>
            <span><i class="fa fa-comment-o"></i> <?= $p['comments'] ?></span>
        </div>
    </a>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/_footer.php'; ?>
