<?php
/**
 * 底部导航
 */
$currentPage = $currentPage ?? 'home';
$u = $user ?? null;
// 未读消息数
$unreadMsg = 0;
if ($u) {
    $unreadMsg = (int)db()->query("SELECT COUNT(*) FROM messages WHERE to_user_id = {$u['id']} AND is_read = 0")->fetchColumn();
}
?>
<!-- 底部导航 -->
<nav class="app-nav">
    <a href="index.php?page=home" class="nav-item <?= $currentPage==='home'?'active':'' ?>">
        <i class="fa fa-home"></i>
        <span>首页</span>
    </a>
    <a href="index.php?page=discover" class="nav-item <?= $currentPage==='discover'?'active':'' ?>">
        <i class="fa fa-compass"></i>
        <span>发现</span>
    </a>
    <a href="index.php?page=filehub" class="nav-item <?= $currentPage==='filehub'?'active':'' ?>">
        <i class="fa fa-folder-open-o"></i>
        <span>文件</span>
    </a>
    <a href="index.php?page=publish" class="nav-publish" title="发布">
        <i class="fa fa-plus"></i>
    </a>
    <a href="index.php?page=message" class="nav-item <?= $currentPage==='message'?'active':'' ?>" style="position:relative;">
        <i class="fa fa-commenting-o"></i>
        <span>消息</span>
        <?php if ($unreadMsg > 0): ?>
            <span class="msg-badge"><?= $unreadMsg > 99 ? '99+' : $unreadMsg ?></span>
        <?php endif; ?>
    </a>
    <a href="index.php?page=profile" class="nav-item <?= $currentPage==='profile'?'active':'' ?>">
        <i class="fa fa-user-o"></i>
        <span>我的</span>
    </a>
</nav>

<?php if (trim($settings['icp'] ?? '') !== ''): ?>
<!-- 页脚备案信息 -->
<div style="text-align:center;padding:12px 0 80px;font-size:11px;color:var(--text-light,#9a9aa5);">
    <?= e($settings['icp']) ?> · <?= e(($settings['site_name'] ?? '') ?: '起灵贴吧') ?>
</div>
<?php endif; ?>

</body>
</html>
