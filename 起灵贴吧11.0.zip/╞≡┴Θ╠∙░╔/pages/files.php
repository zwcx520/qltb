<?php
/**
 * 我的文件库（APP UI）
 * 上传任意格式文件（单个 ≤100MB），存放在 assets/uploads/files/<用户名>/
 * 文件详情页可改名、写说明、设置/取消提取密码、复制分享链接
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$msg = '';
$msgType = 'success';

// 上传体积超过 post_max_size 时 PHP 会清空 $_POST/$_FILES，这里给出明确提示
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && empty($_FILES) && intval($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $msg = '上传内容超过服务器限制（post_max_size 当前为 ' . ini_get('post_max_size') . '），请调大后再试';
    $msgType = 'error';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'upload') {
        $files = $_FILES['files'] ?? null;
        if (!$files || !is_array($files['name'] ?? null)) {
            $msg = '请选择要上传的文件';
            $msgType = 'error';
        } else {
            $okCount = 0;
            $errors = [];
            foreach ($files['name'] as $i => $name) {
                if ($name === '' || $files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $one = [
                    'name'     => $name,
                    'type'     => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error'    => $files['error'][$i],
                    'size'     => $files['size'][$i],
                ];
                $r = handle_file_upload($one, $user['username']);
                if ($r['ok']) {
                    $title = mb_substr($name, 0, 200);
                    db()->prepare("INSERT INTO user_files (user_id, name, file, filesize, ext, created_at) VALUES (?, ?, ?, ?, ?, NOW())")
                        ->execute([$user['id'], $title, $r['url'], $r['size'], $r['ext']]);
                    $okCount++;
                } else {
                    $errors[] = $name . '：' . $r['msg'];
                }
            }
            if ($okCount > 0) $msg = '成功上传 ' . $okCount . ' 个文件';
            if ($errors) {
                $msg = ($okCount > 0 ? $msg . '；' : '') . implode('；', array_slice($errors, 0, 3));
                $msgType = 'error';
            }
            if ($okCount === 0 && !$errors) {
                $msg = '请选择要上传的文件';
                $msgType = 'error';
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $stmt = db()->prepare("SELECT * FROM user_files WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            $msg = '文件不存在或无权删除';
            $msgType = 'error';
        } else {
            db()->prepare("DELETE FROM user_files WHERE id = ? AND user_id = ?")->execute([$id, $user['id']]);
            delete_uploaded_file($row['file']);
            $dir = __DIR__ . '/../assets/uploads/files/' . files_folder_name($user['username']);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
            $msg = '已删除该文件';
        }
    }
}

$fileList = user_file_list($user['id']);
$totalSize = 0;
foreach ($fileList as $f) $totalSize += intval($f['filesize']);

$pageTitle = '我的文件';
$bodyClass = 'no-nav';
include __DIR__ . '/../includes/header.php';
?>

<!-- 顶部栏 -->
<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:white;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;">
    <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-angle-left"></i></a>
    <div style="font-size:17px;font-weight:600;flex:1;">我的文件</div>
    <span style="font-size:12px;color:var(--text-light);"><?= count($fileList) ?> 个 · <?= human_size($totalSize) ?></span>
</div>

<?php if ($msg): ?>
    <div style="padding:12px 16px;color:white;text-align:center;font-size:13px;<?= $msgType === 'error' ? 'background:#ef4444' : 'background:#10b981' ?>">
        <i class="fa fa-<?= $msgType === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<!-- 上传文件 -->
<div style="padding:16px;">
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="action" value="upload">
        <label for="files-input" style="cursor:pointer;display:block;padding:22px 16px;text-align:center;border:2px dashed rgba(168,85,247,0.35);border-radius:16px;background:rgba(255,255,255,0.7);">
            <i class="fa fa-cloud-upload" style="font-size:26px;color:var(--primary);"></i>
            <div style="font-size:14px;font-weight:600;margin-top:6px;">点击选择文件（可多选）</div>
            <div style="font-size:12px;color:var(--text-light);margin-top:4px;">支持任意格式，单个文件最大 100MB</div>
        </label>
        <input type="file" id="files-input" name="files[]" multiple style="display:none;">
        <div id="files-selected" style="font-size:12px;color:var(--text-light);margin-top:8px;"></div>
        <button type="submit" class="btn btn-primary btn-block" style="padding:12px;margin-top:10px;">
            <i class="fa fa-upload"></i> 开始上传
        </button>
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">
            文件存放在以你的用户名命名的文件夹中；服务器当前限制：<?= e(ini_get('upload_max_filesize')) ?> / 表单 <?= e(ini_get('post_max_size')) ?>
        </div>
    </form>
</div>

<!-- 文件列表 -->
<?php if (empty($fileList)): ?>
    <div class="empty">
        <i class="fa fa-folder-open-o"></i>
        <p>还没有上传任何文件</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">上传后可设置提取密码，并把详情页链接分享给其他人</p>
    </div>
<?php else: ?>
    <div style="padding:0 16px 20px;display:flex;flex-direction:column;gap:10px;">
        <?php foreach ($fileList as $f): ?>
        <div class="post-card" style="padding:12px;">
            <div style="display:flex;align-items:center;gap:12px;">
                <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#ec4899,#a855f7);color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fa <?= e(file_icon($f['ext'])) ?>"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        <?= e($f['name']) ?>
                        <?php if (!empty($f['password'])): ?>
                            <span style="font-size:10px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:1px 6px;margin-left:4px;"><i class="fa fa-lock"></i> 密码</span>
                        <?php endif; ?>
                    </div>
                    <div style="font-size:11px;color:var(--text-light);margin-top:3px;">
                        <?= human_size($f['filesize']) ?> · <?= time_ago($f['created_at']) ?> · <i class="fa fa-download"></i> <?= intval($f['downloads']) ?>
                    </div>
                </div>
                <a href="index.php?page=file&id=<?= $f['id'] ?>" class="btn btn-ghost btn-sm" style="flex-shrink:0;">详情</a>
            </div>
            <div style="display:flex;gap:8px;margin-top:10px;justify-content:flex-end;">
                <form method="post" style="display:inline;" onsubmit="return confirm('确定删除该文件吗？文件也会从服务器删除。');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= $f['id'] ?>">
                    <button type="submit" class="btn btn-sm" style="background:#fdecec;color:#b3261e;border:1px solid #f5b5b5;">
                        <i class="fa fa-trash"></i> 删除
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
document.getElementById('files-input').addEventListener('change', function() {
    const box = document.getElementById('files-selected');
    if (!this.files || !this.files.length) { box.textContent = ''; return; }
    let total = 0, names = [];
    for (const f of this.files) { total += f.size; names.push(f.name); }
    box.innerHTML = '<i class="fa fa-check-circle" style="color:#10b981;"></i> 已选择 ' + this.files.length + ' 个文件（共 ' + (total / 1048576).toFixed(1) + ' MB）：' + names.join('、');
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
