            </div><!-- /.win-page -->
        </main>
        <?php if (trim($settings['icp'] ?? '') !== ''): ?>
        <!-- 页脚备案信息：作为主区域底部的一行，不覆盖侧边栏与内容 -->
        <div class="win-icp">
            <?= e($settings['icp']) ?> · <?= e(($settings['site_name'] ?? '') ?: '起灵贴吧') ?>
        </div>
        <?php endif; ?>
    </div><!-- /.win-main -->
</div><!-- /.win-shell -->

<script>
// 用户菜单开关
function toggleUserMenu(ev) {
    ev.stopPropagation();
    closeAllMenus('win-user-menu');
    document.getElementById('win-user-menu').classList.toggle('open');
}
// 统一菜单管理：互斥打开（打开一个先关其他）
function closeAllMenus(exceptId) {
    document.querySelectorAll('.win-menu.open').forEach(function (m) {
        if (m.id !== exceptId) m.classList.remove('open');
    });
}
// 点击菜单以外任意处：关闭全部下拉菜单
document.addEventListener('click', function (e) {
    if (!e.target.closest('.win-menu')) {
        document.querySelectorAll('.win-menu.open').forEach(function (m) { m.classList.remove('open'); });
    }
});
// 内容区上下滚动时自动收起所有下拉菜单，避免悬浮菜单与内容重叠
var winContentEl = document.querySelector('.win-content');
if (winContentEl) winContentEl.addEventListener('scroll', function () {
    document.querySelectorAll('.win-menu.open').forEach(function (m) { m.classList.remove('open'); });
});
// 公告跑马灯：文字不超过可视宽度时静态显示；超过时以恒定速度（约50px/秒）无缝滚动
(function () {
    var runs = document.querySelectorAll('.notice-run, .filehub-notice-run');
    for (var i = 0; i < runs.length; i++) {
        var run = runs[i];
        var track = run.parentNode;
        var trackW = track.clientWidth;
        var single = run.firstElementChild ? run.firstElementChild.getBoundingClientRect().width : 0;
        if (!trackW || !single) continue;
        if (single <= trackW) {
            run.classList.add('is-static');
        } else {
            run.style.animationDuration = Math.max(12, Math.round(single / 50)) + 's';
            run.classList.add('is-scrolling');
        }
    }
})();
</script>
</body>
</html>
