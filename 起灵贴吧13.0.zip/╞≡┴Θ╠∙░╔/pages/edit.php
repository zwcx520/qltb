<?php
/**
 * 编辑资料页
 */
if (!$user) { header('Location: index.php?page=login'); exit; }

$pageTitle = '编辑资料';
$currentPage = 'profile';
include __DIR__ . '/../includes/header.php';

$msg = '';
$msgType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'music_upload') {
        // 上传背景音乐（仅 mp3，可多选）
        $files = $_FILES['music'] ?? null;
        if (!$files || !is_array($files['name'] ?? null)) {
            $msg = '请选择要上传的音乐文件';
            $msgType = 'error';
        } else {
            $okCount = 0;
            $errors = [];
            foreach ($files['name'] as $i => $name) {
                if ($name === '' || $files['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $one = [
                    'name'     => $name,
                    'type'     => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error'    => $files['error'][$i],
                    'size'     => $files['size'][$i],
                ];
                $r = handle_music_upload($one, $user['username']);
                if ($r['ok']) {
                    $title = mb_substr(pathinfo($name, PATHINFO_FILENAME), 0, 100);
                    db()->prepare("INSERT INTO user_music (user_id, title, file, filesize, created_at) VALUES (?, ?, ?, ?, NOW())")
                        ->execute([$user['id'], $title, $r['url'], intval($files['size'][$i])]);
                    $okCount++;
                } else {
                    $errors[] = $name . '：' . $r['msg'];
                }
            }
            if ($okCount > 0) {
                $msg = '成功上传 ' . $okCount . ' 首音乐';
            }
            if ($errors) {
                $msg = ($okCount > 0 ? $msg . '；' : '') . implode('；', array_slice($errors, 0, 3));
                $msgType = 'error';
            }
            if ($okCount === 0 && !$errors) {
                $msg = '请选择要上传的音乐文件';
                $msgType = 'error';
            }
        }
    } elseif ($action === 'music_delete') {
        // 删除背景音乐（仅能删除自己的）
        $id = intval($_POST['id'] ?? 0);
        $stmt = db()->prepare("SELECT * FROM user_music WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            $msg = '音乐不存在或无权删除';
            $msgType = 'error';
        } else {
            db()->prepare("DELETE FROM user_music WHERE id = ? AND user_id = ?")->execute([$id, $user['id']]);
            delete_uploaded_file($row['file']);
            // 目录已空时一并移除用户音乐文件夹
            $dir = __DIR__ . '/../assets/uploads/music/' . music_folder_name($user['username']);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
            $msg = '已删除该音乐';
        }
    } elseif ($action === 'change_password') {
        // 修改密码
        $oldPwd  = $_POST['old_password'] ?? '';
        $newPwd  = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($oldPwd === '' || $newPwd === '' || $confirm === '') {
            $msg = '请填写完整的密码信息';
            $msgType = 'error';
        } elseif (!verify_password($oldPwd, $user['password'])) {
            $msg = '当前密码错误，请重新输入';
            $msgType = 'error';
        } elseif (strlen($newPwd) < 6) {
            $msg = '新密码至少6个字符';
            $msgType = 'error';
        } elseif ($newPwd !== $confirm) {
            $msg = '两次输入的新密码不一致';
            $msgType = 'error';
        } elseif ($oldPwd === $newPwd) {
            $msg = '新密码不能与当前密码相同';
            $msgType = 'error';
        } else {
            $stmt = db()->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([hash_password($newPwd), $user['id']]);
            $msg = '密码修改成功，下次登录请使用新密码';
        }
    } else {
        // 保存资料
        $nickname = trim($_POST['nickname'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $email = trim($_POST['email'] ?? '');

        // 头像上传
        $avatar = $user['avatar'];
        if (!empty($_FILES['avatar']['name'])) {
            $r = handle_upload($_FILES['avatar'], ['jpg','jpeg','png','gif','webp'], 5242880);
            if ($r['ok']) {
                // 上传成功，删除旧头像文件（覆盖原图片）
                if (!empty($user['avatar'])) {
                    delete_uploaded_file($user['avatar']);
                }
                $avatar = $r['url'];
            } else {
                $msg = '头像上传失败: ' . $r['msg'];
                $msgType = 'error';
            }
        }

        // 主页背景图上传
        $profileBg = $user['profile_bg'] ?? '';
        if (!empty($_FILES['profile_bg']['name'])) {
            $r = handle_upload($_FILES['profile_bg'], ['jpg','jpeg','png','gif','webp'], 5242880);
            if ($r['ok']) {
                // 上传成功，删除旧背景图文件
                if (!empty($profileBg)) {
                    delete_uploaded_file($profileBg);
                }
                $profileBg = $r['url'];
            } else {
                $msg = '背景图上传失败: ' . $r['msg'];
                $msgType = 'error';
            }
        }

        if ($msgType === 'success') {
            $stmt = db()->prepare("UPDATE users SET nickname = ?, bio = ?, email = ?, avatar = ?, profile_bg = ? WHERE id = ?");
            $stmt->execute([$nickname, $bio, $email, $avatar, $profileBg, $user['id']]);
            $msg = '保存成功';
            $user = current_user(); // 刷新
        }
    }
}

$musicList = user_music_list($user['id']);
?>

<div class="app-header">
    <div class="header-inner">
        <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-angle-left"></i></a>
        <h1 class="app-title" style="font-size:17px;">编辑资料</h1>
        <a href="index.php?page=profile" class="icon-btn"><i class="fa fa-check text-primary"></i></a>
    </div>
</div>

<?php if ($msg): ?>
    <div style="padding:12px 16px;color:white;text-align:center;font-size:13px;border-radius:0;<?= $msgType==='error'?'background:#ef4444':'background:#10b981' ?>">
        <i class="fa fa-<?= $msgType==='error'?'exclamation-circle':'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" style="padding:16px;">
    <input type="hidden" name="action" value="profile">
    <!-- 头像 -->
    <div class="form-group" style="text-align:center;">
        <label class="form-label">头像</label>
        <label for="avatar-input" style="cursor:pointer;display:inline-block;position:relative;">
            <img id="avatar-preview" src="<?= e(avatar($user)) ?>" class="avatar-lg" style="border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
            <div style="position:absolute;bottom:0;right:0;width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#ec4899,#a855f7);color:white;display:flex;align-items:center;justify-content:center;font-size:14px;border:2px solid white;">
                <i class="fa fa-camera"></i>
            </div>
        </label>
        <input type="file" id="avatar-input" name="avatar" accept="image/*" style="display:none;">
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">点击头像更换，支持 JPG/PNG/GIF，最大 5MB</div>
    </div>

    <!-- 主页背景图 -->
    <div class="form-group">
        <label class="form-label"><i class="fa fa-image text-primary"></i> 主页背景图</label>
        <label for="profile-bg-input" style="cursor:pointer;display:block;position:relative;height:110px;border-radius:16px;overflow:hidden;background:linear-gradient(135deg,#fce7f3,#ddd6fe);">
            <img id="profile-bg-preview" src="<?= !empty($user['profile_bg']) ? e($user['profile_bg']) : '' ?>" alt="" style="width:100%;height:100%;object-fit:cover;display:<?= !empty($user['profile_bg']) ? 'block' : 'none' ?>;">
            <div id="profile-bg-empty" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:var(--text-light);font-size:12px;<?= !empty($user['profile_bg']) ? 'display:none;' : '' ?>">
                <i class="fa fa-cloud-upload" style="font-size:22px;"></i>
                <span>点击上传背景图</span>
            </div>
        </label>
        <input type="file" id="profile-bg-input" name="profile_bg" accept="image/*" style="display:none;">
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">显示在「我的」页面顶部，头像会遮盖其下缘；支持 JPG/PNG/GIF，最大 5MB</div>
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-user text-primary"></i> 用户名</label>
        <input class="form-input" value="<?= e($user['username']) ?>" disabled style="opacity:0.6;">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-smile-o text-primary"></i> 昵称</label>
        <input name="nickname" class="form-input" value="<?= e($user['nickname']) ?>" maxlength="50">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-envelope text-primary"></i> 邮箱</label>
        <input name="email" type="email" class="form-input" value="<?= e($user['email']) ?>">
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-quote-left text-primary"></i> 个性签名</label>
        <textarea name="bio" class="form-textarea" maxlength="200" placeholder="一句话介绍自己..."><?= e($user['bio']) ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary btn-block" style="padding:14px;margin-top:8px;">
        <i class="fa fa-save"></i> 保存修改
    </button>
</form>

<!-- 我的音乐库：背景音乐（仅 MP3，每人独立文件夹） -->
<div style="display:flex;align-items:center;gap:10px;padding:8px 16px 0;color:var(--text-light);font-size:13px;">
    <div style="flex:1;height:1px;background:rgba(0,0,0,0.06);"></div>
    <span><i class="fa fa-music"></i> 我的音乐库</span>
    <div style="flex:1;height:1px;background:rgba(0,0,0,0.06);"></div>
</div>

<div style="padding:16px;">
    <?php if (empty($musicList)): ?>
        <div class="empty" style="padding:20px 0;">
            <i class="fa fa-music"></i>
            <p>还没有音乐</p>
            <p style="font-size:12px;color:var(--text-light);margin-top:6px;">上传 MP3 后会出现在你的主页右上角的音乐播放器</p>
        </div>
    <?php else: ?>
        <?php foreach ($musicList as $m): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:10px;background:white;border-radius:14px;margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,0.04);">
            <div style="width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,#ec4899,#a855f7);color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                <i class="fa fa-music"></i>
            </div>
            <div style="flex:1;min-width:0;">
                <div style="font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($m['title']) ?></div>
                <div style="font-size:11px;color:var(--text-light);"><?= round($m['filesize'] / 1048576, 1) ?> MB · <?= time_ago($m['created_at']) ?></div>
            </div>
            <button type="button" class="icon-btn" onclick="previewMusic(this, '<?= e($m['file']) ?>')" title="试听" style="flex-shrink:0;">
                <i class="fa fa-play"></i>
            </button>
            <form method="post" style="display:inline;flex-shrink:0;" onsubmit="return confirm('确定删除这首音乐吗？');">
                <input type="hidden" name="action" value="music_delete">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button type="submit" class="icon-btn" title="删除" style="color:#ef4444;"><i class="fa fa-trash"></i></button>
            </form>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" style="margin-top:10px;">
        <input type="hidden" name="action" value="music_upload">
        <label for="music-input" class="btn btn-ghost btn-block" style="padding:12px;cursor:pointer;">
            <i class="fa fa-cloud-upload"></i> 选择 MP3 音乐（可多选）
        </label>
        <input type="file" id="music-input" name="music[]" accept=".mp3,audio/mpeg" multiple style="display:none;">
        <div id="music-file-list" style="font-size:12px;color:var(--text-light);margin-top:8px;"></div>
        <button type="submit" class="btn btn-primary btn-block" style="padding:12px;margin-top:8px;">
            <i class="fa fa-upload"></i> 上传音乐
        </button>
        <div style="font-size:12px;color:var(--text-light);margin-top:8px;">仅支持 MP3 格式，单个文件最大 30MB；文件存放在以你的用户名命名的文件夹中</div>
    </form>
</div>

<!-- 账号安全：修改密码 -->
<div style="display:flex;align-items:center;gap:10px;padding:8px 16px 0;color:var(--text-light);font-size:13px;">
    <div style="flex:1;height:1px;background:rgba(0,0,0,0.06);"></div>
    <span><i class="fa fa-shield"></i> 账号安全</span>
    <div style="flex:1;height:1px;background:rgba(0,0,0,0.06);"></div>
</div>

<form method="post" style="padding:16px;">
    <input type="hidden" name="action" value="change_password">

    <div class="form-group">
        <label class="form-label"><i class="fa fa-lock text-primary"></i> 当前密码</label>
        <input name="old_password" type="password" class="form-input" placeholder="请输入当前密码" autocomplete="current-password" required>
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-key text-primary"></i> 新密码</label>
        <input name="new_password" type="password" class="form-input" placeholder="至少6个字符" autocomplete="new-password" minlength="6" required>
    </div>

    <div class="form-group">
        <label class="form-label"><i class="fa fa-check-circle text-primary"></i> 确认新密码</label>
        <input name="confirm_password" type="password" class="form-input" placeholder="再次输入新密码" autocomplete="new-password" minlength="6" required>
    </div>

    <button type="submit" class="btn btn-ghost btn-block" style="padding:14px;margin-top:8px;">
        <i class="fa fa-shield"></i> 修改密码
    </button>
</form>

<script>
// 头像即时预览
document.getElementById('avatar-input').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('avatar-preview').src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
    }
});

// 主页背景图即时预览
document.getElementById('profile-bg-input').addEventListener('change', function() {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.getElementById('profile-bg-preview');
            img.src = e.target.result;
            img.style.display = 'block';
            document.getElementById('profile-bg-empty').style.display = 'none';
        };
        reader.readAsDataURL(this.files[0]);
    }
});

// 音乐试听（同一时间只播放一首）
let musicPreviewAudio = null;
let musicPreviewBtn = null;
function previewMusic(btn, url) {
    if (musicPreviewAudio && musicPreviewBtn === btn && !musicPreviewAudio.paused) {
        musicPreviewAudio.pause();
        btn.innerHTML = '<i class="fa fa-play"></i>';
        return;
    }
    if (musicPreviewAudio) {
        musicPreviewAudio.pause();
        if (musicPreviewBtn) musicPreviewBtn.innerHTML = '<i class="fa fa-play"></i>';
    }
    musicPreviewAudio = new Audio(url);
    musicPreviewBtn = btn;
    musicPreviewAudio.play();
    btn.innerHTML = '<i class="fa fa-pause"></i>';
    musicPreviewAudio.onended = function() {
        btn.innerHTML = '<i class="fa fa-play"></i>';
    };
}

// 选择音乐文件后显示待上传列表
document.getElementById('music-input').addEventListener('change', function() {
    const box = document.getElementById('music-file-list');
    if (!this.files || !this.files.length) { box.textContent = ''; return; }
    let total = 0, names = [];
    for (const f of this.files) {
        total += f.size;
        names.push(f.name);
    }
    box.innerHTML = '<i class="fa fa-check-circle" style="color:#10b981;"></i> 已选择 ' + this.files.length + ' 个文件（共 ' + (total / 1048576).toFixed(1) + ' MB）：' + names.join('、');
});
</script>

