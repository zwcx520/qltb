<?php
/**
 * 文件详情页（APP UI，独立页面）
 * - 展示文件信息与发布者信息
 * - 访客：点击「立即下载」，设置了提取密码的文件需先输入密码
 * - 本人：额外可修改名称/说明、设置/取消提取密码、删除文件
 */
$id = intval($_GET['id'] ?? 0);

$stmt = db()->prepare("SELECT f.*, u.username, u.nickname, u.avatar, u.bio, u.role, u.posts FROM user_files f
    JOIN users u ON f.user_id = u.id WHERE f.id = ?");
$stmt->execute([$id]);
$file = $stmt->fetch();

$msg = '';
$msgType = 'success';
$isOwner = false;

if ($file) {
    $isOwner = $user && ($user['id'] == $file['user_id']);
    $unlocked = file_unlock_valid($file['id']);
    $needPassword = ($file['password'] !== '') && !$isOwner && !$unlocked;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        if ($action === 'delete' && $isOwner) {
            db()->prepare("DELETE FROM user_files WHERE id = ? AND user_id = ?")->execute([$file['id'], $user['id']]);
            delete_uploaded_file($file['file']);
            $dir = __DIR__ . '/../assets/uploads/files/' . files_folder_name($user['username']);
            if (is_dir($dir) && count(glob($dir . '/*') ?: []) === 0) {
                @rmdir($dir);
            }
            header('Location: index.php?page=files');
            exit;
        }

        if ($action === 'save' && $isOwner) {
            $name = trim($_POST['name'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $newPassword = (string)($_POST['password'] ?? '');
            $removePassword = !empty($_POST['remove_password']);

            $pwdHash = $file['password'];
            if ($removePassword) {
                $pwdHash = '';
            } elseif ($newPassword !== '') {
                if (strlen($newPassword) < 4) {
                    $msg = '提取密码至少 4 个字符';
                    $msgType = 'error';
                } else {
                    $pwdHash = password_hash($newPassword, PASSWORD_DEFAULT);
                }
            }

            if ($msgType !== 'error') {
                if ($name === '') $name = $file['name'];
                db()->prepare("UPDATE user_files SET name = ?, description = ?, password = ? WHERE id = ? AND user_id = ?")
                    ->execute([mb_substr($name, 0, 200), mb_substr($description, 0, 255), $pwdHash, $file['id'], $user['id']]);
                $file['name'] = mb_substr($name, 0, 200);
                $file['description'] = mb_substr($description, 0, 255);
                $file['password'] = $pwdHash;
                $msg = '设置已保存';
            }
        }

        if ($action === 'unlock' && !$isOwner && $file['password'] !== '') {
            $pwd = (string)($_POST['password'] ?? '');
            if ($pwd === '') {
                $msg = '请输入提取密码';
                $msgType = 'error';
            } elseif (!password_verify($pwd, $file['password'])) {
                $msg = '提取密码错误，请重试';
                $msgType = 'error';
            } else {
                file_unlock_mark($file['id']);
                header('Location: index.php?page=file&id=' . $file['id']);
                exit;
            }
        }

        // 状态可能已更新
        $unlocked = file_unlock_valid($file['id']);
        $needPassword = ($file['password'] !== '') && !$isOwner && !$unlocked;
    }
}

$pageTitle = $file ? $file['name'] : '文件详情';
$bodyClass = 'no-nav';
include __DIR__ . '/../includes/header.php';
?>

<!-- 顶部栏 -->
<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;background:white;border-bottom:1px solid var(--border);position:sticky;top:0;z-index:10;">
    <a href="<?= $isOwner ? 'index.php?page=files' : 'index.php' ?>" class="icon-btn"><i class="fa fa-angle-left"></i></a>
    <div style="font-size:17px;font-weight:600;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">文件详情</div>
</div>

<?php if (!$file): ?>
    <div class="empty">
        <i class="fa fa-folder-open-o"></i>
        <p>文件不存在或已被删除</p>
        <a href="index.php" class="btn btn-ghost btn-sm" style="margin-top:14px;">返回首页</a>
    </div>
<?php else: ?>

<?php if ($msg): ?>
    <div style="padding:12px 16px;color:white;text-align:center;font-size:13px;<?= $msgType === 'error' ? 'background:#ef4444' : 'background:#10b981' ?>">
        <i class="fa fa-<?= $msgType === 'error' ? 'exclamation-circle' : 'check-circle' ?>"></i> <?= e($msg) ?>
    </div>
<?php endif; ?>

<!-- 文件信息 -->
<div style="padding:16px;">
    <div style="background:rgba(255,255,255,.78);border:1px solid rgba(255,255,255,.9);border-radius:18px;padding:18px 16px;backdrop-filter:blur(12px);box-shadow:0 8px 24px rgba(168,85,247,.08);">
        <div style="display:flex;align-items:center;gap:14px;">
            <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,#ec4899,#a855f7);color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">
                <i class="fa <?= e(file_icon($file['ext'])) ?>"></i>
            </div>
            <div style="flex:1;min-width:0;">
                <div style="font-size:16px;font-weight:700;color:var(--text);word-break:break-all;"><?= e($file['name']) ?></div>
                <div style="font-size:12px;color:var(--text-light);margin-top:5px;">
                    <?= human_size($file['filesize']) ?> · <i class="fa fa-download"></i> <?= intval($file['downloads']) ?> 次下载 · <?= time_ago($file['created_at']) ?>
                    <?php if (!empty($file['password'])): ?>
                        <span style="font-size:11px;color:#a855f7;background:rgba(168,85,247,.12);border-radius:999px;padding:2px 8px;margin-left:4px;"><i class="fa fa-lock"></i> 需要密码</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if (!empty($file['description'])): ?>
            <div style="margin-top:12px;padding:10px 12px;background:rgba(0,0,0,.03);border-radius:12px;font-size:12.5px;color:var(--text-soft);line-height:1.7;word-break:break-word;">
                <?= e($file['description']) ?>
            </div>
        <?php endif; ?>

        <!-- 发布者信息（并入文件信息卡） -->
        <div style="margin-top:14px;padding-top:14px;border-top:1px solid rgba(0,0,0,.06);">
            <div style="font-size:12px;color:var(--text-light);margin-bottom:10px;"><i class="fa fa-user-circle-o"></i> 发布者</div>
            <div style="display:flex;align-items:center;gap:12px;">
                <img src="<?= e(avatar(['id' => $file['user_id'], 'avatar' => $file['avatar'], 'username' => $file['username']])) ?>" style="width:40px;height:40px;border-radius:50%;object-fit:cover;flex-shrink:0;">
                <div style="flex:1;min-width:0;">
                    <div style="font-size:13px;font-weight:600;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                        <?= e($file['nickname'] ?: $file['username']) ?>
                        <?= user_label(['role' => $file['role'], 'posts' => $file['posts']]) ?>
                    </div>
                    <div style="font-size:11px;color:var(--text-light);margin-top:2px;">@<?= e($file['username']) ?> · <?= intval($file['posts']) ?> 条动态</div>
                </div>
                <a href="index.php?page=user&id=<?= $file['user_id'] ?>" class="btn btn-ghost btn-sm" style="flex-shrink:0;">主页</a>
            </div>
            <div style="margin-top:10px;font-size:12px;color:var(--text-soft);line-height:1.6;word-break:break-word;">
                <?= e($file['bio'] ?: 'TA 还没有填写简介') ?>
            </div>
        </div>
    </div>
</div>

<!-- 下载区域 -->
<div style="padding:0 16px 16px;">
    <?php if (!$isOwner && !empty($file['password'])): ?>
        <!-- 密码视图：未验证或倒计时过期后显示，直接点下载再输入密码 -->
        <div id="dl-pwd" style="<?= $needPassword ? '' : 'display:none' ?>">
            <button type="button" class="btn btn-primary btn-block" style="padding:14px;" onclick="document.getElementById('pwd-box').style.display='block';this.style.display='none';">
                <i class="fa fa-download"></i> 立即下载
            </button>
            <div id="pwd-box" style="display:none;background:white;border-radius:18px;padding:18px 16px;box-shadow:0 4px 16px rgba(0,0,0,.05);">
                <div style="font-size:14px;font-weight:600;margin-bottom:4px;"><i class="fa fa-lock" style="color:#a855f7;"></i> 该文件已加密</div>
                <div style="font-size:12px;color:var(--text-light);margin-bottom:12px;">请输入分享者提供的提取密码，验证通过后即可下载。</div>
                <form method="post">
                    <input type="hidden" name="action" value="unlock">
                    <input type="password" name="password" class="form-input" placeholder="请输入提取密码" required>
                    <button type="submit" class="btn btn-primary btn-block" style="margin-top:10px;padding:12px;">
                        <i class="fa fa-unlock-alt"></i> 验证密码并下载
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- 下载视图：无密码 / 本人 / 验证有效期内 -->
    <div id="dl-ready" style="<?= $needPassword ? 'display:none' : '' ?>">
        <a href="index.php?page=download&id=<?= $file['id'] ?>" id="download-btn" class="btn btn-primary btn-block" style="padding:14px;">
            <i class="fa fa-download"></i> 立即下载
        </a>
        <div id="download-url" style="font-size:12px;color:var(--text-light);text-align:center;margin-top:8px;word-break:break-all;">
            下载链接：<?= e(site_base_url() . '/index.php?page=download&id=' . $file['id']) ?>
        </div>
        <?php if (!$isOwner && !empty($file['password'])): ?>
            <div id="unlock-hint" data-remain="<?= max(0, file_unlock_ttl() - (time() - (int)($_SESSION['file_unlock'][(int)$file['id']] ?? 0))) ?>" style="font-size:12px;color:#a855f7;text-align:center;margin-top:4px;">
                <i class="fa fa-check-circle"></i> 密码验证通过，<span id="unlock-remain">30</span> 秒内可直接下载
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($isOwner): ?>
<!-- 文件设置（仅本人） -->
<div style="display:flex;align-items:center;gap:10px;margin:4px 16px 12px;color:var(--text-light);font-size:13px;">
    <div style="flex:1;height:1px;background:rgba(0,0,0,.06);"></div>
    <span><i class="fa fa-cog"></i> 文件设置</span>
    <div style="flex:1;height:1px;background:rgba(0,0,0,.06);"></div>
</div>

<div style="padding:0 16px 20px;">
    <form method="post" style="background:white;border-radius:18px;padding:16px;box-shadow:0 4px 16px rgba(0,0,0,.05);">
        <input type="hidden" name="action" value="save">
        <div class="form-group">
            <label class="form-label"><i class="fa fa-file-text-o text-primary"></i> 文件名称</label>
            <input name="name" class="form-input" value="<?= e($file['name']) ?>" maxlength="200">
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-quote-left text-primary"></i> 文件说明</label>
            <textarea name="description" class="form-textarea" maxlength="255" placeholder="可填写文件内容、解压密码等信息..."><?= e($file['description']) ?></textarea>
        </div>
        <div class="form-group">
            <label class="form-label"><i class="fa fa-lock text-primary"></i> 提取密码</label>
            <input name="password" type="text" class="form-input" placeholder="<?= !empty($file['password']) ? '已设置密码，留空则不修改' : '留空表示不需要密码' ?>" autocomplete="off">
            <div style="font-size:12px;color:var(--text-light);margin-top:6px;">至少 4 个字符；设置后其他访客需输入密码才能获取下载链接。</div>
            <?php if (!empty($file['password'])): ?>
                <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:var(--text-soft);margin-top:8px;">
                    <input type="checkbox" name="remove_password" value="1"> 取消密码（任何人都可直接下载）
                </label>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary btn-block" style="padding:12px;">
            <i class="fa fa-save"></i> 保存设置
        </button>
    </form>

    <form method="post" style="margin-top:12px;" onsubmit="return confirm('确定删除该文件吗？删除后将无法下载。');">
        <input type="hidden" name="action" value="delete">
        <button type="submit" class="btn btn-block" style="padding:12px;background:#fdecec;color:#b3261e;border:1px solid #f5b5b5;">
            <i class="fa fa-trash"></i> 删除文件
        </button>
    </form>
</div>
<?php endif; ?>

<?php endif; ?>

<script>
(function(){
    var hint = document.getElementById('unlock-hint');
    if (!hint) return;
    var remain = parseInt(hint.getAttribute('data-remain'), 10) || 0;
    var span = document.getElementById('unlock-remain');
    if (span) span.textContent = remain;
    var t = setInterval(function(){
        remain--;
        if (remain <= 0) {
            clearInterval(t);
            hint.style.display = 'none';
            var pwd = document.getElementById('dl-pwd');
            var ready = document.getElementById('dl-ready');
            if (pwd) {
                if (ready) ready.style.display = 'none';
                pwd.style.display = 'block';
            }
            return;
        }
        if (span) span.textContent = remain;
    }, 1000);
})();
</script>

