<?php
/**
 * 个人中心
 */
$pageTitle = '我的';
$currentPage = 'profile';
include __DIR__ . '/../includes/header.php';

if (!$user) { header('Location: index.php?page=login'); exit; }

// 用户统计
$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM posts WHERE user_id = {$user['id']}) as posts,
    (SELECT COUNT(*) FROM tieba_follows WHERE user_id = {$user['id']}) as tiebas,
    (SELECT COUNT(*) FROM user_follows WHERE follower_id = {$user['id']}) as following,
    (SELECT COUNT(*) FROM user_follows WHERE following_id = {$user['id']}) as followers
")->fetch();

// 我关注的贴吧
$myTiebas = db()->query("
    SELECT t.* FROM tieba_follows f
    JOIN tiebas t ON f.tieba_id = t.id
    WHERE f.user_id = {$user['id']}
    ORDER BY f.created_at DESC LIMIT 6
")->fetchAll();

// 我的帖子（全部，按年月日分组折叠展示）
$myPosts = db()->query("
    SELECT p.*, t.name as tieba_name FROM posts p
    LEFT JOIN tiebas t ON p.tieba_id = t.id
    WHERE p.user_id = {$user['id']}
    ORDER BY p.created_at DESC
")->fetchAll();

// 按天分组（新的日期在前）
$postGroups = [];
foreach ($myPosts as $p) {
    $day = date('Y-m-d', strtotime($p['created_at']));
    $postGroups[$day][] = $p;
}

// 我的关注列表
$myFollowing = db()->query("
    SELECT u.id, u.nickname, u.avatar, u.username, u.bio
    FROM user_follows f
    JOIN users u ON f.following_id = u.id
    WHERE f.follower_id = {$user['id']}
    ORDER BY f.created_at DESC
")->fetchAll();

// 我的粉丝列表
$myFollowers = db()->query("
    SELECT u.id, u.nickname, u.avatar, u.username, u.bio,
    (SELECT 1 FROM user_follows WHERE follower_id = {$user['id']} AND following_id = u.id) as is_followed
    FROM user_follows f
    JOIN users u ON f.follower_id = u.id
    WHERE f.following_id = {$user['id']}
    ORDER BY f.created_at DESC
")->fetchAll();

// 未读消息数
$unreadCount = db()->query("SELECT COUNT(*) FROM messages WHERE to_user_id = {$user['id']} AND is_read = 0")->fetchColumn();
?>

<!-- 顶部个人信息 -->
<div style="background:white;">
    <!-- 背景图区域（编辑资料中上传；仅头像遮盖其下缘，文字不压背景图） -->
    <?php if (!empty($user['profile_bg'])): ?>
    <div style="height:150px;background:url('<?= e($user['profile_bg']) ?>') center/cover no-repeat;position:relative;">
    <?php else: ?>
    <div style="height:110px;background:linear-gradient(135deg,#fce7f3 0%,#ddd6fe 100%);position:relative;">
    <?php endif; ?>
        <!-- 编辑/更多按钮悬浮在背景图右上角 -->
        <div style="position:absolute;top:12px;right:12px;display:flex;gap:8px;">
            <a href="index.php?page=edit" class="icon-btn" style="background:rgba(255,255,255,.92);" title="编辑资料"><i class="fa fa-pencil"></i></a>
            <button class="icon-btn" style="background:rgba(255,255,255,.92);" onclick="toggleMenu()" title="更多功能">
                <i class="fa fa-bars" id="menuToggleIcon"></i>
            </button>
        </div>
    </div>
    <div style="padding:0 16px;position:relative;">
        <!-- 头像遮盖背景图下缘；昵称+账户名在头像右侧，整体位于背景图下缘之下（底对齐） -->
        <div style="display:flex;align-items:flex-end;gap:14px;margin-top:-36px;">
            <img src="<?= e(avatar($user)) ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.15);position:relative;background:white;flex-shrink:0;display:block;">
            <div style="flex:1;min-width:0;padding-bottom:2px;">
                <div style="font-size:16px;font-weight:700;color:var(--text);line-height:1.3;"><?= e($user['nickname'] ?: $user['username']) ?> <?= user_label($user) ?></div>
                <div style="font-size:11px;color:var(--text-light);margin-top:3px;">@<?= e($user['username']) ?></div>
            </div>
            <!-- 文件系统入口（头像用户名右侧） -->
            <a href="index.php?page=files" class="btn btn-ghost btn-sm" title="我的文件" style="flex-shrink:0;padding:6px 12px;font-size:12px;border-radius:999px;margin-bottom:4px;">
                <i class="fa fa-folder-open"></i> 文件
            </a>
        </div>
        <!-- 简介：透明玻璃卡片，放头像下方 -->
        <div style="margin-top:8px;padding:10px 14px;background:rgba(255,255,255,0.55);border:1px solid rgba(255,255,255,0.75);border-radius:14px;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);box-shadow:0 4px 16px rgba(168,85,247,0.07);">
            <div style="font-size:12px;color:var(--text-soft);line-height:1.6;"><?= e($user['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
        </div>
    </div>
    <!-- 折叠功能菜单 -->
    <div id="foldMenu" style="max-height:0;overflow:hidden;transition:max-height 0.4s ease;margin:015px 16px;background:var(--bg-soft,#f7f7fb);border-radius:16px;">
        <div style="padding:8px;">
            <?php
                $foldMenus = [
                    ['edit', 'pencil', '编辑资料', 'var(--primary)'],
                    ['privacy', 'lock', '隐私设置', '#a855f7'],
                    ['message', 'bell', '消息通知', 'var(--secondary)'],
                    ['my_tiebas', 'star', '我的贴吧', '#f59e0b'],
                    ['', 'star', '我的收藏', '#fbbf24'],
                    ['rules', 'shield', '社区规范', '#34d399'],
                    ['about', 'info-circle', '关于我们', '#60a5fa'],
                ];
                foreach ($foldMenus as $m):
                    $link = !empty($m[0]) ? 'index.php?page='.$m[0] : '#';
            ?>
            <a href="<?= $link ?>" style="display:flex;align-items:center;padding:12px 14px;border-radius:12px;">
                <span style="width:30px;height:30px;border-radius:10px;background:<?= $m[3] ?>22;color:<?= $m[3] ?>;display:flex;align-items:center;justify-content:center;margin-right:12px;">
                    <i class="fa fa-<?= $m[1] ?>"></i>
                </span>
                <span style="flex:1;font-size:14px;"><?= $m[2] ?></span>
                <i class="fa fa-angle-right text-light"></i>
            </a>
            <?php endforeach; ?>

            <a href="index.php?page=cancel" style="display:flex;align-items:center;padding:12px 14px;border-radius:12px;">
                <span style="width:30px;height:30px;border-radius:10px;background:#ef444422;color:#ef4444;display:flex;align-items:center;justify-content:center;margin-right:12px;">
                    <i class="fa fa-user-times"></i>
                </span>
                <span style="flex:1;font-size:14px;color:#ef4444;">注销账号</span>
                <i class="fa fa-angle-right text-light"></i>
            </a>

            <a onclick="logout()" style="display:flex;align-items:center;padding:12px 14px;border-radius:12px;cursor:pointer;">
                <span style="width:30px;height:30px;border-radius:10px;background:#ef444422;color:#ef4444;display:flex;align-items:center;justify-content:center;margin-right:12px;">
                    <i class="fa fa-sign-out"></i>
                </span>
                <span style="flex:1;font-size:14px;color:#ef4444;">退出登录</span>
            </a>
        </div>
    </div>
    <!-- 统计 -->
    <div style="display:flex;justify-content:space-around;margin:25px 16px 14px;background:rgba(255,255,255,0.6);border-radius:16px;padding:14px;backdrop-filter:blur(10px);">
        <a href="index.php?page=profile#posts" style="text-align:center;">
            <div style="font-size:20px;font-weight:700;color:var(--primary);"><?= $stats['posts'] ?></div>
            <div style="font-size:11px;color:var(--text-soft);">动态</div>
        </a>
        <a href="index.php?page=profile&tab=following" style="text-align:center;">
            <div style="font-size:20px;font-weight:700;color:var(--primary);"><?= $stats['following'] ?></div>
            <div style="font-size:11px;color:var(--text-soft);">关注</div>
        </a>
        <a href="index.php?page=profile&tab=followers" style="text-align:center;">
            <div style="font-size:20px;font-weight:700;color:var(--primary);"><?= $stats['followers'] ?></div>
            <div style="font-size:11px;color:var(--text-soft);">粉丝</div>
        </a>
        <a href="index.php?page=profile#tiebas" style="text-align:center;">
            <div style="font-size:20px;font-weight:700;color:var(--primary);"><?= $stats['tiebas'] ?></div>
            <div style="font-size:11px;color:var(--text-soft);">贴吧</div>
        </a>
    </div>
</div>

<?php
$tab = $_GET['tab'] ?? '';
if ($tab === 'following' || $tab === 'followers'):
    $list = $tab === 'following' ? $myFollowing : $myFollowers;
    $listTitle = $tab === 'following' ? '我的关注' : '我的粉丝';
    $listIcon = $tab === 'following' ? 'user-plus' : 'users';
?>
<div class="section-title">
    <span><i class="fa fa-<?= $listIcon ?> text-primary mr-1"></i><?= $listTitle ?> (<?= count($list) ?>)</span>
    <a href="index.php?page=profile" class="more">返回</a>
</div>
<?php if (empty($list)): ?>
    <div class="empty"><i class="fa fa-user-o"></i><p>还没有<?= $tab==='following'?'关注的人':'粉丝' ?></p></div>
<?php else: ?>
    <?php foreach ($list as $u): ?>
    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);">
        <a href="index.php?page=user&id=<?= $u['id'] ?>">
            <img src="<?= e(avatar($u)) ?>" class="avatar-md">
        </a>
        <a href="index.php?page=user&id=<?= $u['id'] ?>" style="flex:1;min-width:0;">
            <div style="font-size:14px;font-weight:600;"><?= e($u['nickname'] ?: $u['username']) ?></div>
            <div style="font-size:12px;color:var(--text-soft);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($u['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
        </a>
        <?php if ($tab === 'following'): ?>
            <button class="btn btn-ghost btn-sm" onclick="followUser(<?= $u['id'] ?>, this);this.closest('div').style.opacity='0.3'">
                <i class="fa fa-check"></i> 已关注
            </button>
        <?php else: ?>
            <?php $followed = !empty($u['is_followed']); ?>
            <button class="btn <?= $followed ? 'btn-ghost' : 'btn-primary' ?> btn-sm" onclick="followUser(<?= $u['id'] ?>, this)">
                <i class="fa fa-<?= $followed ? 'check' : 'plus' ?>"></i> <?= $followed ? '已关注' : '关注' ?>
            </button>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php else: ?>

<!-- 关注的贴吧 -->
<div class="section-title">
    <span><i class="fa fa-star text-primary mr-1"></i>我的贴吧</span>
    <a href="index.php?page=discover" class="more">发现更多</a>
</div>
<?php if (empty($myTiebas)): ?>
    <div style="padding:0 16px;text-align:center;color:var(--text-light);font-size:13px;">
        还没有关注的贴吧，去发现看看吧 ~
    </div>
<?php else: ?>
    <div style="display:flex;gap:12px;overflow-x:auto;padding:0 16px;scrollbar-width:none;">
        <?php foreach ($myTiebas as $t): ?>
            <a href="index.php?page=tieba&id=<?= $t['id'] ?>" style="flex-shrink:0;width:80px;text-align:center;position:relative;">
                <div class="tieba-cover" style="width:56px;height:56px;margin:0 auto;background:<?= cover($t) ?>">
                    <i class="fa fa-<?= e($t['icon'] ?: 'tree') ?>"></i>
                </div>
                <?php if ($t['owner_id'] == $user['id']): ?>
                <span style="position:absolute;top:-2px;right:8px;font-size:14px;" title="我是吧主"><i class="fa fa-crown" style="color:#f59e0b;text-shadow:0 1px 2px rgba(0,0,0,0.1);"></i></span>
                <?php endif; ?>
                <div class="text-xs mt-1" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= e($t['name']) ?></div>
            </a>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- 我的帖子（按年月日分组折叠） -->
<div class="section-title" id="posts">
    <span><i class="fa fa-file-text-o text-primary mr-1"></i>我的动态（<?= count($myPosts) ?>）</span>
    <?php if (!empty($myPosts)): ?>
        <a href="javascript:togglePostSearch()" class="more"><i class="fa fa-search"></i> 搜索</a>
    <?php endif; ?>
</div>
<?php if (!empty($myPosts)): ?>
<!-- 动态搜索框 -->
<div id="post-search-bar" style="display:none;padding:0 16px 10px;">
    <div style="position:relative;">
        <i class="fa fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-light);font-size:13px;"></i>
        <input type="text" id="post-search-input" class="form-input" style="padding-left:34px;" placeholder="搜索我的动态标题 / 内容" oninput="filterMyPosts(this.value)">
    </div>
    <div id="post-search-tip" style="display:none;font-size:12px;color:var(--text-light);margin-top:6px;padding-left:2px;"></div>
</div>
<?php endif; ?>

<?php if (empty($myPosts)): ?>
    <div class="empty">
        <i class="fa fa-pencil-square-o"></i>
        <p>还没有发布过动态</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:8px;">点击底部 + 按钮发布第一条动态吧 ~</p>
    </div>
<?php else: ?>
    <?php
    $gi = 0;
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    foreach ($postGroups as $day => $posts):
        $gi++;
        if ($day === $today) {
            $dayLabel = '今天 · ' . date('Y年m月d日', strtotime($day));
        } elseif ($day === $yesterday) {
            $dayLabel = '昨天 · ' . date('Y年m月d日', strtotime($day));
        } else {
            $dayLabel = date('Y年m月d日', strtotime($day));
        }
    ?>
    <div class="pg-group" style="margin:0 16px 10px;background:white;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.04);">
        <!-- 日期分组头（点击折叠/展开） -->
        <div onclick="togglePostGroup(<?= $gi ?>)" style="display:flex;align-items:center;gap:8px;padding:12px 14px;cursor:pointer;user-select:none;">
            <span style="width:28px;height:28px;border-radius:8px;background:rgba(168,85,247,.1);color:#a855f7;display:flex;align-items:center;justify-content:center;font-size:12px;"><i class="fa fa-calendar"></i></span>
            <span style="font-size:13px;font-weight:600;"><?= e($dayLabel) ?></span>
            <span style="font-size:11px;color:var(--text-light);"><?= count($posts) ?> 条</span>
            <i id="pg-icon-<?= $gi ?>" class="fa fa-angle-down" style="margin-left:auto;color:var(--text-light);transition:transform .3s;<?= $gi === 1 ? 'transform:rotate(180deg);' : '' ?>"></i>
        </div>
        <!-- 分组内容（默认只展开最新一天） -->
        <div id="pg-body-<?= $gi ?>" style="display:<?= $gi === 1 ? 'block' : 'none' ?>;border-top:1px solid rgba(0,0,0,.05);">
            <?php foreach ($posts as $p):
                $imgs = $p['images'] ? json_decode($p['images'], true) : [];
            ?>
            <a href="index.php?page=post&id=<?= $p['id'] ?>" class="pg-item" data-search="<?= e(mb_strtolower($p['title'] . ' ' . $p['content'])) ?>" style="display:block;padding:12px 14px;border-bottom:1px solid rgba(0,0,0,.04);color:inherit;">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
                    <span class="post-tieba-tag"><i class="fa fa-tree"></i> <?= e($p['tieba_name']) ?></span>
                    <?= visibility_badge($p) ?>
                    <span class="text-xs text-light"><?= time_ago($p['created_at']) ?></span>
                    <span class="del-post-btn" onclick="event.preventDefault();event.stopPropagation();deletePost(<?= $p['id'] ?>, 'index.php?page=profile')" style="margin-left:auto;color:#ef4444;font-size:12px;cursor:pointer;"><i class="fa fa-trash-o"></i></span>
                </div>
                <?php if ($p['title']): ?><div style="font-weight:600;font-size:14px;margin-bottom:4px;"><?= e($p['title']) ?></div><?php endif; ?>
                <div class="text-sm text-soft" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?= e($p['content']) ?></div>
                <?php if (!empty($imgs)): ?>
                    <div style="display:flex;gap:4px;margin-top:6px;">
                        <?php foreach (array_slice($imgs,0,3) as $img): ?>
                            <img src="<?= e($img) ?>" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div style="display:flex;gap:16px;margin-top:6px;font-size:12px;color:var(--text-light);">
                    <span><i class="fa fa-eye"></i> <?= $p['views'] ?></span>
                    <span><i class="fa fa-heart-o"></i> <?= $p['likes'] ?></span>
                    <span><i class="fa fa-comment-o"></i> <?= $p['comments'] ?></span>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php endif; // end tab else ?>

<script>
// 我的动态搜索：展开/收起搜索框
function togglePostSearch() {
    var bar = document.getElementById('post-search-bar');
    if (!bar) return;
    if (bar.style.display === 'none') {
        bar.style.display = 'block';
        var i = document.getElementById('post-search-input');
        if (i) i.focus();
    } else {
        bar.style.display = 'none';
        var input = document.getElementById('post-search-input');
        if (input) { input.value = ''; filterMyPosts(''); }
    }
}
// 动态搜索过滤（标题/内容，实时匹配；搜索时自动展开有结果的分组）
function filterMyPosts(q) {
    q = (q || '').trim().toLowerCase();
    var tip = document.getElementById('post-search-tip');
    var total = 0;
    var groups = document.querySelectorAll('.pg-group');
    groups.forEach(function(g, idx) {
        var body = g.querySelector('[id^="pg-body-"]');
        var icon = g.querySelector('[id^="pg-icon-"]');
        var visible = 0;
        g.querySelectorAll('.pg-item').forEach(function(it) {
            var text = (it.getAttribute('data-search') || '');
            var hit = (!q || text.indexOf(q) !== -1);
            it.style.display = hit ? 'block' : 'none';
            if (hit) visible++;
        });
        total += visible;
        if (!q) {
            // 清空搜索：恢复默认（所有分组显示，仅第一组展开）
            g.style.display = 'block';
            if (body) body.style.display = (idx === 0) ? 'block' : 'none';
            if (icon) icon.style.transform = (idx === 0) ? 'rotate(180deg)' : 'rotate(0deg)';
        } else if (visible > 0) {
            g.style.display = 'block';
            if (body) body.style.display = 'block';
            if (icon) icon.style.transform = 'rotate(180deg)';
        } else {
            g.style.display = 'none';
        }
    });
    if (tip) {
        tip.style.display = q ? 'block' : 'none';
        tip.textContent = q ? ('找到 ' + total + ' 条相关动态') : '';
    }
}
// 按日分组折叠/展开
function togglePostGroup(id) {
    var body = document.getElementById('pg-body-' + id);
    var icon = document.getElementById('pg-icon-' + id);
    if (!body) return;
    if (body.style.display === 'none') {
        body.style.display = 'block';
        if (icon) icon.style.transform = 'rotate(180deg)';
    } else {
        body.style.display = 'none';
        if (icon) icon.style.transform = 'rotate(0deg)';
    }
}
function toggleMenu() {
    var menu = document.getElementById('foldMenu');
    var icon = document.getElementById('menuToggleIcon');
    if (menu.style.maxHeight && menu.style.maxHeight !== '0px') {
        menu.style.maxHeight = '0px';
        icon.className = 'fa fa-bars';
    } else {
        menu.style.maxHeight = menu.scrollHeight + 'px';
        icon.className = 'fa fa-times';
    }
}
</script>

