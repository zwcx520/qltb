<?php
return [
    'host'     => '127.0.0.1',
    'port'     => '3306',
    'dbname'   => 'qiling_tieba',
    'username' => 'lcy',
    'password' => 'lcy',
    'charset'  => 'utf8mb4',
];
