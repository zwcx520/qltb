<?php
/**
 * 全站统一增量迁移（前台 index.php 与后台 admin.php 共用，保证三端 schema 一致）
 * 每次进入系统自动执行，已存在的字段会被 try-catch 跳过，兼容旧库无需重装
 */
if (!defined('IN_APP')) exit;

// 自动迁移：用户隐私字段 + 贴吧吧主字段（兼容已安装系统）
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_posts ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_following ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_followers ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE users ADD COLUMN privacy_tiebas ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE tiebas ADD COLUMN owner_id INT UNSIGNED NOT NULL DEFAULT 0"); } catch (Exception $e) {}
// 公告字段
try { db()->exec("ALTER TABLE settings ADD COLUMN announcement TEXT"); } catch (Exception $e) {}
// 首页Banner背景图
try { db()->exec("ALTER TABLE settings ADD COLUMN banner_image VARCHAR(255) DEFAULT ''"); } catch (Exception $e) {}
// Banner欢迎语（标题/副标题）
try { db()->exec("ALTER TABLE settings ADD COLUMN banner_title VARCHAR(100) DEFAULT ''"); } catch (Exception $e) {}
try { db()->exec("ALTER TABLE settings ADD COLUMN banner_subtitle VARCHAR(255) DEFAULT ''"); } catch (Exception $e) {}
// 用户主页背景图（「我的」页面顶部，头像遮盖其下缘）
try { db()->exec("ALTER TABLE users ADD COLUMN profile_bg VARCHAR(255) DEFAULT ''"); } catch (Exception $e) {}
// 用户背景音乐库（新表，不修改任何已有表结构）
try {
    db()->exec("CREATE TABLE IF NOT EXISTS `user_music` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NOT NULL,
        `title` VARCHAR(100) NOT NULL DEFAULT '',
        `file` VARCHAR(255) NOT NULL DEFAULT '',
        `filesize` INT UNSIGNED DEFAULT 0,
        `created_at` DATETIME DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}
// 用户文件分享库（新表，不修改任何已有表结构）
try {
    db()->exec("CREATE TABLE IF NOT EXISTS `user_files` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NOT NULL,
        `name` VARCHAR(200) NOT NULL DEFAULT '',
        `file` VARCHAR(255) NOT NULL DEFAULT '',
        `filesize` BIGINT UNSIGNED DEFAULT 0,
        `ext` VARCHAR(20) DEFAULT '',
        `password` VARCHAR(255) DEFAULT '',
        `description` VARCHAR(255) DEFAULT '',
        `downloads` INT UNSIGNED DEFAULT 0,
        `created_at` DATETIME DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}
// 联系站长消息类型
try { db()->exec("ALTER TABLE messages MODIFY COLUMN type ENUM('like','comment','follow','system','chat','contact') DEFAULT 'system'"); } catch (Exception $e) {}
// 帖子可见范围字段（public公开 / private仅自己可见）
try { db()->exec("ALTER TABLE posts ADD COLUMN visibility ENUM('public','private') NOT NULL DEFAULT 'public'"); } catch (Exception $e) {}
// 用户等级字段
try { db()->exec("ALTER TABLE users ADD COLUMN level INT NOT NULL DEFAULT 0"); } catch (Exception $e) {}
// 用户角色枚举扩展：增加 super_admin（站长）
try { db()->exec("ALTER TABLE users MODIFY COLUMN role ENUM('user','admin','super_admin') DEFAULT 'user'"); } catch (Exception $e) {}
// 把系统中最早的 admin 升级为站长（super_admin），仅在没有站长时执行一次
try {
    $hasSuper = db()->query("SELECT 1 FROM users WHERE role='super_admin' LIMIT 1")->fetchColumn();
    if (!$hasSuper) {
        $firstAdmin = db()->query("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1")->fetchColumn();
        if ($firstAdmin) {
            db()->exec("UPDATE users SET role='super_admin' WHERE id=" . intval($firstAdmin));
        }
    }
} catch (Exception $e) {}
