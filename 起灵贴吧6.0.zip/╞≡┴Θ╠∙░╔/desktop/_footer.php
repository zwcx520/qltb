            </div><!-- /.win-page -->
        </main>
    </div><!-- /.win-main -->
</div><!-- /.win-shell -->

<?php if (trim($settings['icp'] ?? '') !== ''): ?>
<!-- 页脚备案信息 -->
<div style="position:fixed;bottom:0;left:0;right:0;z-index:900;text-align:center;padding:6px 0;font-size:11px;color:var(--text-light,#9a9aa5);background:rgba(255,255,255,.75);backdrop-filter:blur(12px);border-top:1px solid var(--border,#e6e6ee);">
    <?= e($settings['icp']) ?> · <?= e(($settings['site_name'] ?? '') ?: '起灵贴吧') ?>
</div>
<?php endif; ?>

<script>
// 用户菜单开关
function toggleUserMenu(ev) {
    ev.stopPropagation();
    document.getElementById('win-user-menu').classList.toggle('open');
}
document.addEventListener('click', function (e) {
    var m = document.getElementById('win-user-menu');
    if (m && !e.target.closest('.win-avatar-wrap')) m.classList.remove('open');
});
</script>
</body>
</html>
