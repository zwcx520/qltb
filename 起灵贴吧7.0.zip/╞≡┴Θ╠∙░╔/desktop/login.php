<?php
/**
 * Windows 版 - 登录页
 * 功能与 pages/login.php 完全一致：登录校验、用户头像动态预览
 */

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $u = $stmt->fetch();
    if ($u && verify_password($password, $u['password'])) {
        $_SESSION['uid'] = $u['id'];
        db()->exec("UPDATE users SET last_login = NOW() WHERE id = {$u['id']}");
        header('Location: index.php');
        exit;
    } else {
        $error = '用户名或密码错误';
    }
}

$pageTitle = '登录';
$currentPage = '';
include __DIR__ . '/_header.php';
?>

<div class="win-center">
    <div class="auth-card">
        <!-- 头像 / LOGO 区域 -->
        <div id="loginAvatarBox" style="width:86px;height:86px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,#a855f7,#ec4899);display:flex;align-items:center;justify-content:center;box-shadow:0 10px 26px rgba(168,85,247,.4);transition:all .3s ease;overflow:hidden;">
            <img id="loginAvatarDefault" src="https://picsum.photos/100/100?random=2" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none'">
            <img id="loginAvatarImg" src="" style="display:none;width:100%;height:100%;object-fit:cover;">
        </div>
        <h1 class="auth-title" style="margin-top:14px;"><?= e($settings['site_name'] ?? '') ?: '登入贴吧' ?></h1>
        <div id="loginAvatarTip" style="font-size:12px;color:var(--text-soft);margin-top:6px;min-height:16px;">欢迎回来，继续你的树洞之旅 </div>

        <?php if ($error): ?>
            <div class="win-tip win-tip-error" style="text-align:left;">
                <i class="fa fa-exclamation-circle"></i> <?= e($error) ?>
            </div>
        <?php endif; ?>

        <form method="post" class="win-card" style="text-align:left;margin-top:14px;">
            <div class="form-group">
                <label class="form-label"><i class="fa fa-user" style="color:var(--accent);margin-right:4px;"></i> 用户名</label>
                <input name="username" id="loginUsername" class="form-input" placeholder="请输入用户名" required autocomplete="username">
            </div>
            <div class="form-group">
                <label class="form-label"><i class="fa fa-lock" style="color:var(--accent);margin-right:4px;"></i> 密码</label>
                <input name="password" type="password" class="form-input" placeholder="请输入密码" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block" style="padding:13px;font-size:14px;margin-top:4px;">
                <i class="fa fa-sign-in"></i> 登 录
            </button>
        </form>

        <div style="margin-top:16px;">
            <?php if (intval($settings['allow_register'] ?? 1) === 1): ?>
            <p style="font-size:13px;color:var(--text-soft);">
                还没有账号？
                <a href="index.php?page=register" style="color:var(--primary);font-weight:600;">立即注册</a>
            </p>
            <?php endif; ?>
            <a href="index.php?page=contact" style="display:inline-block;margin-top:10px;font-size:12px;color:var(--text-light);">
                <i class="fa fa-envelope"></i> 联系站长
            </a>
        </div>
    </div>
</div>

<script>
(function(){
    var usernameInput = document.getElementById('loginUsername');
    var avatarBox = document.getElementById('loginAvatarBox');
    var avatarDefault = document.getElementById('loginAvatarDefault');
    var avatarImg = document.getElementById('loginAvatarImg');
    var avatarTip = document.getElementById('loginAvatarTip');
    var lastQuery = '';

    function showDefaultAvatar() {
        avatarImg.style.display = 'none';
        avatarDefault.style.display = 'block';
        avatarBox.style.background = 'linear-gradient(135deg,#a855f7,#ec4899)';
        avatarTip.textContent = '欢迎回来，继续你的树洞之旅 ';
    }

    function fetchAvatar(username) {
        if (!username || username === lastQuery) return;
        lastQuery = username;
        // 显示加载态
        avatarDefault.style.display = 'none';
        avatarImg.style.display = 'none';
        avatarBox.style.background = 'linear-gradient(135deg,#f3f4f6,#e5e7eb)';
        avatarTip.innerHTML = '<i class="fa fa-spinner fa-spin"></i> 正在查找用户...';

        fetch('api/get_avatar.php?username=' + encodeURIComponent(username))
        .then(function(r){ return r.json(); })
        .then(function(d){
            if (username !== lastQuery) return; // 防止旧请求覆盖新结果
            if (d.code === 0) {
                avatarImg.src = d.avatar;
                avatarImg.style.display = 'block';
                avatarBox.style.background = 'linear-gradient(135deg,#a855f7,#ec4899)';
                avatarTip.innerHTML = '<i class="fa fa-check-circle" style="color:#10b981;"></i> 欢迎，尊敬的：' + d.nickname;
            } else {
                showDefaultAvatar();
                avatarTip.innerHTML = '<i class="fa fa-question-circle" style="color:#9ca3af;"></i> 平台没有该用户';
            }
        })
        .catch(function(){
            if (username === lastQuery) showDefaultAvatar();
        });
    }

    var timer = null;
    usernameInput.addEventListener('input', function(){
        var val = this.value.trim();
        if (!val) {
            lastQuery = '';
            showDefaultAvatar();
            return;
        }
        clearTimeout(timer);
        timer = setTimeout(function(){ fetchAvatar(val); }, 400);
    });

    usernameInput.addEventListener('blur', function(){
        var val = this.value.trim();
        if (val) fetchAvatar(val);
    });
})();
</script>

<?php include __DIR__ . '/_footer.php'; ?>
