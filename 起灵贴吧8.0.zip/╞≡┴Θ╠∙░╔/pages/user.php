<?php
/**
 * 用户主页
 */
$uid = intval($_GET['id'] ?? 0);
$target = db()->prepare("SELECT * FROM users WHERE id = ?");
$target->execute([$uid]);
$target = $target->fetch();

if (!$target) { header('Location: index.php'); exit; }

// 是否本人查看（本人可见自己的私密帖）
$isOwner = ($user && $user['id'] == $target['id']);
// 帖子可见性条件：本人看自己 -> 全部；其他任何人（含游客）-> 仅公开帖
$postVisSql = $isOwner ? '1=1' : "visibility = 'public'";

$pageTitle = $target['nickname'] ?: $target['username'];
$currentPage = 'home';
include __DIR__ . '/../includes/header.php';

// 统计（非本人查看时，动态数不统计私密帖）
$stats = db()->query("SELECT
    (SELECT COUNT(*) FROM posts WHERE user_id = {$target['id']} AND {$postVisSql}) as posts,
    (SELECT COUNT(*) FROM user_follows WHERE follower_id = {$target['id']}) as following,
    (SELECT COUNT(*) FROM user_follows WHERE following_id = {$target['id']}) as followers,
    (SELECT COUNT(*) FROM tieba_follows WHERE user_id = {$target['id']}) as tiebas
")->fetch();

// 是否关注
$isFollowing = false;
if ($user) {
    $stmt = db()->prepare("SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ?");
    $stmt->execute([$user['id'], $target['id']]);
    $isFollowing = (bool)$stmt->fetch();
}

// 隐私设置
$canSeePosts     = $isOwner || ($target['privacy_posts'] ?? 'public') === 'public';
$canSeeFollowing = $isOwner || ($target['privacy_following'] ?? 'public') === 'public';
$canSeeFollowers = $isOwner || ($target['privacy_followers'] ?? 'public') === 'public';
$canSeeTiebas    = $isOwner || ($target['privacy_tiebas'] ?? 'public') === 'public';

// 用户帖子（仅在有权限时查询；私密帖仅作者本人可见）
$posts = [];
if ($canSeePosts) {
    $posts = db()->query("
        SELECT p.*, t.name as tieba_name FROM posts p
        LEFT JOIN tiebas t ON p.tieba_id = t.id
        WHERE p.user_id = {$target['id']} AND p.status = 1 AND {$postVisSql}
        ORDER BY p.created_at DESC LIMIT 20
    ")->fetchAll();
}
?>

<!-- 个人信息头 -->
<div style="background:white;">
    <!-- 背景图区域（本人可在编辑资料中上传；仅头像遮盖其下缘，文字不压背景图） -->
    <?php if (!empty($target['profile_bg'])): ?>
    <div style="height:150px;background:url('<?= e($target['profile_bg']) ?>') center/cover no-repeat;position:relative;">
    <?php else: ?>
    <div style="height:110px;background:linear-gradient(135deg,#ddd6fe 0%,#fce7f3 100%);position:relative;">
    <?php endif; ?>
        <a href="index.php" class="icon-btn" style="position:absolute;top:12px;left:12px;background:rgba(255,255,255,0.92);"><i class="fa fa-angle-left"></i></a>
    </div>
    <div style="padding:0 16px;position:relative;">
        <!-- 头像遮盖背景图下缘；昵称+账户名在头像右侧，整体位于背景图下缘之下（底对齐） -->
        <div style="display:flex;align-items:flex-end;gap:14px;margin-top:-36px;">
            <img src="<?= e(avatar($target)) ?>" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.15);position:relative;background:white;flex-shrink:0;display:block;">
            <div style="flex:1;min-width:0;padding-bottom:2px;">
                <div style="font-size:16px;font-weight:700;color:var(--text);line-height:1.3;"><?= e($target['nickname'] ?: $target['username']) ?> <?= user_label($target) ?></div>
                <div style="font-size:11px;color:var(--text-light);margin-top:3px;">@<?= e($target['username']) ?></div>
            </div>
        </div>
        <!-- 简介：透明玻璃卡片，放头像下方 -->
        <div style="margin-top:8px;padding:10px 14px;background:rgba(255,255,255,0.55);border:1px solid rgba(255,255,255,0.75);border-radius:14px;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);box-shadow:0 4px 16px rgba(168,85,247,0.07);">
            <div style="font-size:12px;color:var(--text-soft);line-height:1.6;"><?= e($target['bio'] ?: '这个人很懒，什么都没留下~') ?></div>
        </div>
        <!-- 关注 / 编辑资料按钮（非本人主页一律显示关注按钮；未登录点击跳转登录） -->
        <?php if (!$isOwner): ?>
            <button class="btn <?= $isFollowing ? 'btn-ghost' : 'btn-primary' ?> btn-block" style="margin-top:10px;" onclick="<?= $user ? 'followUser(' . (int)$target['id'] . ', this)' : "location.href='index.php?page=login'" ?>">
                <i class="fa fa-<?= $isFollowing ? 'check' : 'plus' ?>"></i> <?= $isFollowing ? '已关注' : '关注' ?>
            </button>
        <?php else: ?>
            <a href="index.php?page=edit" class="btn btn-ghost btn-block" style="margin-top:10px;"><i class="fa fa-pencil"></i> 编辑资料</a>
        <?php endif; ?>
    </div>

    <!-- 统计 -->
    <div style="display:flex;justify-content:space-around;margin:25px 16px 16px;background:rgba(255,255,255,0.6);border-radius:16px;padding:14px;backdrop-filter:blur(10px);">
        <div style="text-align:center;"><div style="font-size:18px;font-weight:700;color:var(--primary);"><?= $canSeePosts ? $stats['posts'] : '<i class="fa fa-lock" style="font-size:16px;"></i>' ?></div><div class="text-xs text-light">动态</div></div>
        <div style="text-align:center;"><div style="font-size:18px;font-weight:700;color:var(--primary);"><?= $canSeeFollowing ? $stats['following'] : '<i class="fa fa-lock" style="font-size:16px;"></i>' ?></div><div class="text-xs text-light">关注</div></div>
        <div style="text-align:center;"><div style="font-size:18px;font-weight:700;color:var(--primary);"><?= $canSeeFollowers ? $stats['followers'] : '<i class="fa fa-lock" style="font-size:16px;"></i>' ?></div><div class="text-xs text-light">粉丝</div></div>
        <div style="text-align:center;"><div style="font-size:18px;font-weight:700;color:var(--primary);"><?= $canSeeTiebas ? $stats['tiebas'] : '<i class="fa fa-lock" style="font-size:16px;"></i>' ?></div><div class="text-xs text-light">贴吧</div></div>
    </div>
</div>

<!-- 帖子 -->
<div class="section-title"><span><i class="fa fa-file-text-o text-primary mr-1"></i>Ta的动态</span></div>

<?php if (!$canSeePosts): ?>
    <div class="empty">
        <i class="fa fa-lock"></i>
        <p>TA的动态已设为私密</p>
        <p style="font-size:13px;color:var(--text-light);margin-top:6px;">仅TA本人可查看</p>
    </div>
<?php elseif (empty($posts)): ?>
    <div class="empty"><i class="fa fa-leaf"></i><p>还没有发布过动态</p></div>
<?php else: ?>
    <?php foreach ($posts as $p):
        $imgs = $p['images'] ? json_decode($p['images'], true) : [];
    ?>
    <a href="index.php?page=post&id=<?= $p['id'] ?>" class="post-card" style="display:block;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
            <span class="post-tieba-tag"><i class="fa fa-tree"></i> <?= e($p['tieba_name']) ?></span>
        <?= visibility_badge($p) ?>
        <span class="text-xs text-light"><?= time_ago($p['created_at']) ?></span>
        </div>
        <?php if ($p['title']): ?><div style="font-weight:600;margin-bottom:4px;"><?= e($p['title']) ?></div><?php endif; ?>
        <div class="text-sm text-soft" style="display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?= e($p['content']) ?></div>
        <?php if (!empty($imgs)): ?>
            <div style="display:flex;gap:4px;margin-top:6px;">
                <?php foreach (array_slice($imgs,0,3) as $img): ?>
                    <img src="<?= e($img) ?>" style="width:60px;height:60px;border-radius:8px;object-fit:cover;">
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <div style="display:flex;gap:16px;margin-top:8px;font-size:12px;color:var(--text-light);">
            <span><i class="fa fa-eye"></i> <?= $p['views'] ?></span>
            <span><i class="fa fa-heart-o"></i> <?= $p['likes'] ?></span>
            <span><i class="fa fa-comment-o"></i> <?= $p['comments'] ?></span>
        </div>
    </a>
    <?php endforeach; ?>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
