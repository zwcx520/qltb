<?php
/**
 * Windows 版公共头部（左侧边栏 + 顶栏）
 * 使用前需设置：$pageTitle（页面标题）、$currentPage（home/discover/search/message/profile）
 * 作用域内可用：$user（当前用户或 null）、$settings、$page、$id、$act
 */
if (!defined('IN_APP')) exit;
$pageTitle = $pageTitle ?? '首页';
$currentPage = $currentPage ?? 'home';
$siteName = ($settings['site_name'] ?? '') ?: '起灵贴吧';
$siteLogo = trim($settings['site_logo'] ?? '');
$unreadMsg = 0;
if ($user) {
    $unreadMsg = (int)db()->query("SELECT COUNT(*) FROM messages WHERE to_user_id = {$user['id']} AND is_read = 0")->fetchColumn();
}
$winNavs = [
    'home'     => ['首页', 'fa-home'],
    'discover' => ['发现', 'fa-compass'],
    'search'   => ['搜索', 'fa-search'],
    'message'  => ['消息', 'fa-commenting-o'],
    'profile'  => ['我的', 'fa-user-o'],
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> - <?= e($siteName) ?></title>
    <meta name="description" content="<?= e($settings['site_desc'] ?? '') ?>">
    <meta name="keywords" content="<?= e($settings['site_keywords'] ?? '') ?>">
    <link href="assets/lib/fontawesome/css/all.min.css" rel="stylesheet">
    <link href="assets/lib/fontawesome/css/v4-shims.min.css" rel="stylesheet">
    <link rel="stylesheet" href="desktop/style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?: '1' ?>">
    <script src="assets/js/app.js?v=<?= @filemtime(__DIR__ . '/../assets/js/app.js') ?: '1' ?>"></script>
</head>
<body class="win-body">
<div class="win-shell">
    <!-- 左侧边栏 -->
    <aside class="win-sidebar">
        <a class="win-brand" href="index.php?page=home" title="<?= e($siteName) ?>">
            <?php if ($siteLogo): ?>
                <img src="<?= e($siteLogo) ?>" class="win-brand-logo" alt="" onerror="this.style.display='none'">
            <?php else: ?>
                <span class="win-brand-logo win-brand-fallback"><i class="fa fa-tree"></i></span>
            <?php endif; ?>
            <span class="win-brand-name"><?= e($siteName) ?></span>
        </a>

        <a href="index.php?page=publish" class="win-publish"><i class="fa fa-plus"></i> 发布帖子</a>

        <nav class="win-nav">
            <?php foreach ($winNavs as $key => [$label, $icon]): ?>
                <a href="index.php?page=<?= $key ?>" class="win-nav-item <?= $currentPage === $key ? 'active' : '' ?>">
                    <i class="fa <?= $icon ?>"></i><span><?= $label ?></span>
                    <?php if ($key === 'message' && $unreadMsg > 0): ?>
                        <span class="win-badge"><?= $unreadMsg > 99 ? '99+' : $unreadMsg ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="win-side-foot">
            <?php if (is_admin()): ?>
                <a href="admin.php" target="_blank" class="win-menu-item"><i class="fa fa-shield"></i> <span>管理后台</span></a>
            <?php endif; ?>
            <?php if ($user): ?>
                <a href="index.php?page=profile" class="win-usercard" title="个人中心">
                    <img src="<?= e(avatar($user)) ?>" class="win-usercard-avatar" alt="">
                    <div class="win-usercard-info">
                        <div class="win-usercard-name"><?= e($user['nickname'] ?: $user['username']) ?></div>
                        <div><?= user_label($user) ?></div>
                    </div>
                </a>
            <?php endif; ?>
        </div>
    </aside>

    <!-- 右侧主区域 -->
    <div class="win-main">
        <header class="win-topbar">
            <form action="index.php" method="get" class="win-search" onsubmit="if(!this.kw.value.trim())return false;">
                <i class="fa fa-search"></i>
                <input type="hidden" name="page" value="search">
                <input type="text" name="kw" placeholder="搜索帖子、贴吧、用户..." value="<?= e($_GET['kw'] ?? '') ?>">
            </form>
            <div class="win-top-actions">
                <a href="index.php?page=message" class="win-iconbtn" title="消息通知">
                    <i class="fa fa-bell-o"></i>
                    <?php if ($unreadMsg > 0): ?><span class="win-badge"><?= $unreadMsg > 99 ? '99+' : $unreadMsg ?></span><?php endif; ?>
                </a>
                <?php if ($user): ?>
                    <div class="win-avatar-wrap">
                        <button type="button" class="win-avatar-btn" onclick="toggleUserMenu(event)" title="账号菜单">
                            <img src="<?= e(avatar($user)) ?>" alt="">
                        </button>
                        <div class="win-menu" id="win-user-menu">
                            <a href="index.php?page=profile" class="win-menu-item"><i class="fa fa-user-o"></i> 个人中心</a>
                            <a href="index.php?page=user&id=<?= $user['id'] ?>" class="win-menu-item"><i class="fa fa-id-card-o"></i> 我的主页</a>
                            <a href="index.php?page=edit" class="win-menu-item"><i class="fa fa-pencil"></i> 编辑资料</a>
                            <a href="index.php?page=privacy" class="win-menu-item"><i class="fa fa-lock"></i> 隐私设置</a>
                            <a href="index.php?page=my_tiebas" class="win-menu-item"><i class="fa fa-flag-o"></i> 我的贴吧</a>
                            <?php if (is_admin()): ?><a href="admin.php" target="_blank" class="win-menu-item"><i class="fa fa-shield"></i> 管理后台</a><?php endif; ?>
                            <a href="javascript:logout()" class="win-menu-item win-menu-danger"><i class="fa fa-sign-out"></i> 退出登录</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="index.php?page=login" class="btn btn-ghost btn-sm">登录</a>
                    <a href="index.php?page=register" class="btn btn-primary btn-sm">注册</a>
                <?php endif; ?>
            </div>
        </header>
        <main class="win-content">
            <div class="win-page">
