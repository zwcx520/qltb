<?php
/**
 * 起灵贴吧 - 前台入口 (SPA单页程序)
 */
define('IN_APP', true);
require __DIR__ . '/includes/functions.php';

// 未安装则跳转安装
if (!is_installed()) {
    header('Location: install.php');
    exit;
}

start_session();
$user = current_user();

// 确保上传目录可写
$uploadDir = __DIR__ . '/assets/uploads';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0777, true);
}

// 获取设置
$settings = db()->query("SELECT * FROM settings LIMIT 1")->fetch() ?: ['site_name' => '起灵贴吧', 'site_desc' => '温暖的情绪树洞'];

// 自动创建收藏表（兼容已安装系统）
db()->exec("CREATE TABLE IF NOT EXISTS post_favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at DATETIME,
    UNIQUE KEY uniq_fav (post_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 确保 posts 表有 favorites 字段
try {
    db()->exec("ALTER TABLE posts ADD COLUMN favorites INT NOT NULL DEFAULT 0");
} catch (Exception $e) { /* 字段已存在，忽略 */ }

// 全站统一增量迁移（与后台 admin.php 共用 includes/migrations.php，保证三端 schema 一致）
require __DIR__ . '/includes/migrations.php';

// 路由参数
$page = $_GET['page'] ?? 'home';
$id   = $_GET['id'] ?? 0;
$act  = $_GET['act'] ?? '';

// 引入页面
$allowed = ['home','discover','publish','message','profile','tieba','post','search','login','register','user','edit','privacy','contact','contact_chat','about','rules','my_tiebas','tieba_manage','cancel'];
if (!in_array($page, $allowed)) $page = 'home';

// 需要登录的页面
$needLogin = ['publish','message','edit','privacy','my_tiebas','tieba_manage','cancel'];
if (in_array($page, $needLogin) && !$user) {
    header('Location: index.php?page=login');
    exit;
}

// 设备分流：手机访问 APP UI（pages/），电脑访问 Windows 版 UI（desktop/）
// Windows 版未实现的页面自动回退到 APP 页面，保证功能永远可用
$ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
$isMobile = (strpos($ua, 'mobile') !== false) || (strpos($ua, 'android') !== false)
    || (strpos($ua, 'iphone') !== false) || (strpos($ua, 'ipad') !== false)
    || (strpos($ua, 'ipod') !== false) || (strpos($ua, 'windows phone') !== false);
$desktopFile = __DIR__ . '/desktop/' . $page . '.php';
if (!$isMobile && is_file($desktopFile)) {
    include $desktopFile;
} else {
    include __DIR__ . '/pages/' . $page . '.php';
}
